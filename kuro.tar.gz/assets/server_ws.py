import asyncio
import websockets
import json

clients = set()

async def handler(websocket):
    clients.add(websocket)
    print("プレイヤーが接続しました！")
    try:
        async for message in websocket:
            for client in clients:
                if client != websocket:
                    await client.send(message)
    except:
        pass
    finally:
        clients.remove(websocket)
        print("プレイヤーが退出しました。")

async def main():
    async with websockets.serve(handler, "127.0.0.1", 8080):
        print("WebSocketサーバー起動完了！ (Port: 8080)")
        await asyncio.Future()

if __name__ == "__main__":
    asyncio.run(main())