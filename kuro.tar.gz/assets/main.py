import asyncio
import pygame
import random
import math
import sys
import os
import json

# --- 定数設定 ---
PHI = (1 + math.sqrt(5)) / 2
GRID_SIZE = 40
MAP_WIDTH, MAP_HEIGHT = 15, 10

MAP_PIXEL_W = MAP_WIDTH * GRID_SIZE
MAP_PIXEL_H = MAP_HEIGHT * GRID_SIZE
LOG_H = 160
SIDE_W = 250
WIDTH = MAP_PIXEL_W + SIDE_W
HEIGHT = MAP_PIXEL_H + LOG_H

ENCOUNTER_RATE = 0.10
ENCOUNTER_COOLDOWN_STEPS = 3
ENEMY_TEX_SIZE = 150

FPS = 60

# 色定義
BLACK, WHITE = (10, 10, 10), (240, 240, 240)
GRAY, DK_GRAY, LT_GRAY = (80, 80, 80), (40, 40, 40), (160, 160, 160)
RED, DK_RED = (220, 50, 50), (120, 20, 20)
BLUE, CYAN = (50, 100, 250), (50, 220, 255)
GREEN, DK_GREEN = (50, 200, 50), (20, 100, 20)
YELLOW, GOLD = (255, 215, 0), (218, 165, 32)
SILVER, BROWN, PURPLE = (192, 192, 192), (139, 69, 19), (147, 112, 219)

# --- 音声管理クラス ---
class AudioManager:
    def __init__(self):
        pygame.mixer.init()
        self.sounds = {}
        se_files = {
            "cursor": "cursor.wav", "decide": "decide.wav", "attack": "attack.wav",
            "magic": "magic.wav", "damage": "damage.wav", "levelup": "levelup.wav"
        }
        for name, filename in se_files.items():
            if os.path.exists(filename): self.sounds[name] = pygame.mixer.Sound(filename)
            else: self.sounds[name] = None
        if os.path.exists("bgm.mp3"):
            pygame.mixer.music.load("bgm.mp3")
            pygame.mixer.music.play(-1)

    def play(self, name):
        if name in self.sounds and self.sounds[name]:
            self.sounds[name].play()

# --- テクスチャ生成関数 ---
def create_textures():
    textures = {}
    
    floor = pygame.Surface((GRID_SIZE, GRID_SIZE))
    floor.fill((150, 150, 150))
    for _ in range(20):
        rx, ry = random.randint(2, GRID_SIZE-4), random.randint(2, GRID_SIZE-4)
        c = random.choice([(130, 130, 130), (170, 170, 170)])
        pygame.draw.rect(floor, c, (rx, ry, 4, 4))
    pygame.draw.rect(floor, (200, 200, 200), (0, 0, GRID_SIZE, GRID_SIZE), 2)
    textures['floor'] = floor
    
    wall = pygame.Surface((GRID_SIZE, GRID_SIZE))
    wall.fill((50, 50, 50))
    for i in range(2):
        for j in range(2):
            x, y = j*20, i*20
            if i == 1: x = (j*20+10)%40-10
            pygame.draw.rect(wall, (70, 70, 70), (x, y, 20, 20))
            pygame.draw.rect(wall, (30, 30, 30), (x, y, 20, 20), 1)
    textures['wall'] = wall
    
    stairs = pygame.Surface((GRID_SIZE, GRID_SIZE))
    for i in range(5):
        h = GRID_SIZE // 5
        c = max(20, 160 - i*30)
        pygame.draw.rect(stairs, (0, c, 0), (0, i*h, GRID_SIZE, h))
        pygame.draw.line(stairs, (0, min(255, c+50), 0), (0, i*h), (GRID_SIZE, i*h), 2)
    textures['stairs'] = stairs
    
    chest = pygame.Surface((GRID_SIZE, GRID_SIZE), pygame.SRCALPHA)
    pygame.draw.rect(chest, BROWN, (6, 10, GRID_SIZE-12, GRID_SIZE-16), border_radius=3)
    pygame.draw.rect(chest, GOLD, (6, 10, GRID_SIZE-12, GRID_SIZE-16), 2, border_radius=3)
    pygame.draw.rect(chest, GOLD, (GRID_SIZE//2-4, 18, 8, 6))
    textures['chest'] = chest

    hole = floor.copy()
    for i in range(12):
        c = max(0, 120 - i*10)
        pygame.draw.circle(hole, (c, c, c), (GRID_SIZE//2, GRID_SIZE//2), GRID_SIZE//2 - i)
    textures['hole'] = hole
    
    spike = floor.copy()
    pygame.draw.rect(spike, (80, 80, 80), (4, 4, GRID_SIZE-8, GRID_SIZE-8), border_radius=4)
    for px, py in [(12,12), (28,12), (12,28), (28,28)]:
        pygame.draw.polygon(spike, (200, 30, 30), [(px, py-14), (px-6, py+4), (px+6, py+4)])
        pygame.draw.line(spike, WHITE, (px, py-14), (px+3, py+2), 1)
    textures['spike'] = spike

    player = pygame.Surface((GRID_SIZE, GRID_SIZE), pygame.SRCALPHA)
    pygame.draw.circle(player, SILVER, (20, 15), 10)
    pygame.draw.rect(player, SILVER, (12, 15, 16, 18), border_radius=3)
    pygame.draw.rect(player, CYAN, (17, 12, 8, 3))
    pygame.draw.circle(player, BLUE, (10, 25), 8)
    textures['player'] = player

    def draw_mech(color, eye_color, shape="normal"):
        surf = pygame.Surface((ENEMY_TEX_SIZE, ENEMY_TEX_SIZE), pygame.SRCALPHA)
        if shape == "tank":
            pygame.draw.rect(surf, color, (40, 40, 70, 80), border_radius=15)
            pygame.draw.circle(surf, eye_color, (75, 65), 15)
        elif shape == "attacker":
            pygame.draw.polygon(surf, color, [(75, 10), (120, 120), (30, 120)])
            pygame.draw.line(surf, eye_color, (50, 50), (100, 50), 8)
        elif shape == "speed":
            pygame.draw.ellipse(surf, color, (50, 20, 50, 110))
            pygame.draw.circle(surf, eye_color, (75, 45), 6)
        elif shape == "sniper":
            pygame.draw.rect(surf, color, (65, 50, 20, 80))
            pygame.draw.rect(surf, SILVER, (70, 10, 10, 50))
            pygame.draw.circle(surf, eye_color, (75, 55), 5)
        elif shape == "jammer":
            pygame.draw.circle(surf, color, (75, 75), 45)
            pygame.draw.circle(surf, eye_color, (75, 75), 20, 3)
            pygame.draw.arc(surf, eye_color, (20, 20, 110, 110), 0, 3.14, 2)
        elif shape == "berserker":
            pygame.draw.rect(surf, BLACK, (45, 40, 60, 80))
            pygame.draw.rect(surf, color, (45, 40, 60, 80), 3)
            pygame.draw.circle(surf, RED, (75, 70), 25)
        else:
            pygame.draw.rect(surf, color, (50, 50, 50, 70), border_radius=8)
            pygame.draw.circle(surf, eye_color, (75, 70), 10)
        return surf

    textures['enemy_normal'] = draw_mech(GRAY, RED, "normal")
    textures['enemy_tank'] = draw_mech((70, 90, 60), YELLOW, "tank")
    textures['enemy_attacker'] = draw_mech((150, 50, 50), CYAN, "attacker")
    textures['enemy_speed'] = draw_mech((60, 80, 160), WHITE, "speed")
    textures['enemy_sniper'] = draw_mech((50, 100, 50), GREEN, "sniper")
    textures['enemy_jammer'] = draw_mech(PURPLE, WHITE, "jammer")
    textures['enemy_berserker'] = draw_mech(RED, RED, "berserker")
    textures['enemy_mimic'] = draw_mech(BROWN, RED, "normal")

    boss = pygame.Surface((ENEMY_TEX_SIZE, ENEMY_TEX_SIZE), pygame.SRCALPHA)
    pygame.draw.polygon(boss, DK_RED, [(75, 5), (145, 100), (110, 145), (40, 145), (5, 100)])
    pygame.draw.circle(boss, YELLOW, (75, 80), 25)
    textures['boss'] = boss
    
    boss_p2 = boss.copy()
    pygame.draw.circle(boss_p2, YELLOW, (75,80), 60, 4)
    textures['boss_p2'] = boss_p2

    return textures

# --- クラス定義 ---
class Player:
    def __init__(self):
        self.x, self.y = 1, 1
        self.dx, self.dy = 0, 1
        self.level, self.exp = 1, 0
        self.hp, self.max_hp = 60, 60
        self.mp, self.max_mp = 20, 20
        self.base_atk, self.base_def, self.base_agi = 12, 5, 10
        self.parts, self.stat_pts = 0, 0
        self.weapon_lv, self.gear_lv, self.hp_lv, self.mp_lv, self.magic_lv = 1, 1, 1, 1, 1
        self.hp_potions, self.mp_potions, self.ultimate_cd = 0, 0, 0
        self.action_gauge, self.steps_since_encounter, self.active_def = 0, ENCOUNTER_COOLDOWN_STEPS, 0
        self.spells = [{"name": "ヒール", "cost": 5, "type": "heal", "power": 30}]

    @property
    def atk(self): return self.base_atk + (self.weapon_lv * 4)
    @property
    def agi(self): return self.base_agi + (self.gear_lv * 3)
    @property
    def defense(self): return self.base_def + self.active_def

    def level_up(self):
        self.level += 1
        self.max_hp += 8
        self.max_mp += 3
        self.hp, self.mp = self.max_hp, self.max_mp
        learned = None
        if self.level == 5: learned = "ファイア"
        elif self.level == 10: learned = "プロテクト"
        elif self.level == 15: learned = "サンダー"
        elif self.level == 20: learned = "フルヒール"
        if learned:
            powers = {"ファイア": 45, "プロテクト": 12, "サンダー": 80, "フルヒール": 999}
            types = {"ファイア": "attack", "プロテクト": "defense", "サンダー": "attack", "フルヒール": "heal"}
            costs = {"ファイア": 8, "プロテクト": 10, "サンダー": 15, "フルヒール": 20}
            self.spells.append({"name": learned, "cost": costs[learned], "type": types[learned], "power": powers[learned]})
        return learned

class Enemy:
    def __init__(self, floor, is_boss=False, is_mimic=False):
        self.is_boss, self.is_mimic, self.phase_2 = is_boss, is_mimic, False
        scale = 1.5 ** (floor - 1)
        b_hp, b_atk, b_agi = (120, 15, 12+floor*0.5) if is_boss else (30, 8, 12+floor*0.5)
        self.type_str = "normal"
        
        if is_boss:
            self.name, self.drop_parts = f"階層 {floor} の守護者", random.randint(5, 10)
        elif is_mimic:
            self.type_str, self.name = "mimic", "ミミック"
            b_hp *= 2.0; b_atk *= 1.5; b_agi *= 1.2
            self.drop_parts = random.randint(1,5)
        else:
            r = random.random()
            if r < 0.15:
                self.type_str, self.name = "tank", "重装機械兵"
                b_hp *= 2.5; b_atk *= 0.6; b_agi *= 0.5
            elif r < 0.30:
                self.type_str, self.name = "attacker", "強襲機械兵"
                b_hp *= 0.6; b_atk *= 2.0
            elif r < 0.45:
                self.type_str, self.name = "speed", "高速機械兵"
                b_hp *= 0.4; b_atk *= 0.7; b_agi *= 3.0
            elif r < 0.60:
                self.type_str, self.name = "sniper", "高精度機械兵"
                b_hp *= 0.4; b_atk *= 2.5; b_agi *= 0.8
            elif r < 0.75:
                self.type_str, self.name = "jammer", "電磁攪乱兵"
                b_hp *= 1.2; b_atk *= 0.5; b_agi *= 2.5
            elif r < 0.90:
                self.type_str, self.name = "berserker", "狂化機械兵"
                b_hp *= 1.0; b_atk *= 1.8; b_agi *= 1.2
            else:
                self.type_str, self.name = "normal", "標準機械兵"
                
            pr = random.random()
            self.drop_parts = 3 if pr < 0.1 else (2 if pr < 0.4 else 1)
            
        self.max_hp = int(b_hp * scale)
        self.hp = self.max_hp
        self.atk = int(b_atk * scale)
        self.agi = int(b_agi)
        self.exp_yield = int((40 if is_mimic else (60 if is_boss else 15)) * scale)
        self.action_gauge = 0
        self.recommended_level = int(floor * 1.5) + 3

class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("クロ奪還 v3.5 - Complete Edition")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont("msgothic", 20)
        self.font_s = pygame.font.SysFont("msgothic", 16)
        self.font_l = pygame.font.SysFont("msgothic", 28)
        self.font_xl = pygame.font.SysFont("msgothic", 40)
        
        self.audio = AudioManager()
        self.textures = create_textures()
        self.player = Player()
        
        self.floor = 1
        self.state = "MAP"
        self.cursor = 0
        self.guide_cursor = 0
        self.msg = ["クロを救うため、ダンジョンに潜入した。"]
        self.spike_timer = 0
        self.has_encountered = False
        self.fighting_boss = False
        
        # チュートリアル用変数
        self.tutorial_done = False
        self.tutorial_step = 0
        self.tutorial_texts = [
            "……聞こえるか。君の相棒『クロ』は、",
            "この機械ダンジョンの地下100階層に囚われている。",
            "ダンジョン内は常に危険が伴う。",
            "[W,A,S,D] または [矢印キー] で移動してくれ。",
            "赤く点滅する『トゲ』や暗い『落とし穴』には気をつけろ。",
            "踏むとHPを削られるぞ。",
            "緑色の『階段』を目指し、最下層へ向かえ。",
            "各階層の階段には『守護者(ボス)』が立ち塞がる。",
            "敵が落とす『部品』は、[E / Esc]でメニューを開き",
            "クラフトから自身の永続強化に使える。",
            "それでは健闘を祈る……。クロを必ず救い出してくれ！"
        ]
        
        # セーブデータの読み込み
        if not self.load_game():
            # 新規ゲームの場合はチュートリアルから開始
            self.generate_map()
            self.state = "TUTORIAL"

    def change_state(self, new_state):
        self.state = new_state
        self.cursor = 0

    # ==== セーブ＆ロード機能 ====
    def save_game(self):
        # GAMEOVER状態などはセーブしない
        if self.state in ["GAMEOVER", "TUTORIAL"]: return
        
        data = {
            "floor": self.floor,
            "map_data": self.map_data,
            "stairs": self.stairs,
            "tutorial_done": self.tutorial_done,
            "player": {
                "x": self.player.x, "y": self.player.y, "dx": self.player.dx, "dy": self.player.dy,
                "level": self.player.level, "exp": self.player.exp,
                "hp": self.player.hp, "max_hp": self.player.max_hp,
                "mp": self.player.mp, "max_mp": self.player.max_mp,
                "base_atk": self.player.base_atk, "base_def": self.player.base_def, "base_agi": self.player.base_agi,
                "parts": self.player.parts, "stat_pts": self.player.stat_pts,
                "weapon_lv": self.player.weapon_lv, "gear_lv": self.player.gear_lv, 
                "hp_lv": self.player.hp_lv, "mp_lv": self.player.mp_lv, "magic_lv": self.player.magic_lv,
                "hp_potions": self.player.hp_potions, "mp_potions": self.player.mp_potions,
                "ultimate_cd": self.player.ultimate_cd, "spells": self.player.spells
            }
        }
        try:
            with open("save_data.json", "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print("セーブに失敗しました:", e)

    def load_game(self):
        if not os.path.exists("save_data.json"): return False
        try:
            with open("save_data.json", "r", encoding="utf-8") as f:
                data = json.load(f)
            self.floor = data["floor"]
            self.map_data = data["map_data"]
            self.stairs = tuple(data["stairs"])
            self.tutorial_done = data.get("tutorial_done", False)
            
            p_data = data["player"]
            self.player.x, self.player.y = p_data["x"], p_data["y"]
            self.player.dx, self.player.dy = p_data["dx"], p_data["dy"]
            self.player.level, self.player.exp = p_data["level"], p_data["exp"]
            self.player.hp, self.player.max_hp = p_data["hp"], p_data["max_hp"]
            self.player.mp, self.player.max_mp = p_data["mp"], p_data["max_mp"]
            self.player.base_atk, self.player.base_def, self.player.base_agi = p_data["base_atk"], p_data["base_def"], p_data["base_agi"]
            self.player.parts, self.player.stat_pts = p_data["parts"], p_data["stat_pts"]
            self.player.weapon_lv, self.player.gear_lv = p_data["weapon_lv"], p_data["gear_lv"]
            self.player.hp_lv, self.player.mp_lv, self.player.magic_lv = p_data["hp_lv"], p_data["mp_lv"], p_data["magic_lv"]
            self.player.hp_potions, self.player.mp_potions = p_data["hp_potions"], p_data["mp_potions"]
            self.player.ultimate_cd = p_data["ultimate_cd"]
            self.player.spells = p_data["spells"]
            
            self.add_msg("オートセーブからデータを復元しました。")
            return True
        except Exception as e:
            print("ロードに失敗しました:", e)
            return False

    def reset_save_data(self):
        if os.path.exists("save_data.json"):
            os.remove("save_data.json")
        # 完全に初期化
        self.__init__()

    # ==== マップ生成 ====
    def generate_map(self):
        self.stairs = (MAP_WIDTH-2, MAP_HEIGHT-2)
        while True:
            self.map_data = [[0 for _ in range(MAP_WIDTH)] for _ in range(MAP_HEIGHT)]
            for y in range(1, MAP_HEIGHT-1):
                for x in range(1, MAP_WIDTH-1):
                    r = random.random()
                    if r < 0.65: self.map_data[y][x] = 1 # 床
                    elif r < 0.75: self.map_data[y][x] = 0 # 壁
                    elif r < 0.90: self.map_data[y][x] = 5 # トゲ
                    else: self.map_data[y][x] = 4 # 穴
                    
            self.map_data[1][1] = 1
            self.map_data[self.stairs[1]][self.stairs[0]] = 2
            
            v = [[False]*MAP_WIDTH for _ in range(MAP_HEIGHT)]
            q = [(1,1)]
            v[1][1] = True
            r_ok = False
            while q:
                cx, cy = q.pop(0)
                if (cx, cy) == self.stairs:
                    r_ok = True
                    break
                for dx, dy in [(0,1),(0,-1),(1,0),(-1,0)]:
                    nx, ny = cx+dx, cy+dy
                    if 0 <= nx < MAP_WIDTH and 0 <= ny < MAP_HEIGHT:
                        if not v[ny][nx] and self.map_data[ny][nx] != 0:
                            v[ny][nx] = True
                            q.append((nx,ny))
            if r_ok:
                break
                
        if random.random() < 0.5:
            cells = []
            for y in range(1, MAP_HEIGHT-1):
                for x in range(1, MAP_WIDTH-1):
                    if self.map_data[y][x] == 1 and (x,y) != (1,1) and (x,y) != self.stairs:
                        cells.append((x,y))
            if cells:
                cx, cy = random.choice(cells)
                self.map_data[cy][cx] = 3
                
        self.has_encountered = False
        self.save_game() # マップ生成時にオートセーブ

    def add_msg(self, m):
        self.msg.append(m)
        if len(self.msg) > 6:
            self.msg.pop(0)

    def draw_ui(self):
        pygame.draw.rect(self.screen, DK_GRAY, (0, MAP_PIXEL_H, MAP_PIXEL_W, LOG_H))
        pygame.draw.rect(self.screen, GRAY, (0, MAP_PIXEL_H, MAP_PIXEL_W, LOG_H), 3)
        for i, m in enumerate(self.msg):
            self.screen.blit(self.font.render(m, True, WHITE), (15, MAP_PIXEL_H + 15 + i*22))
            
        pygame.draw.rect(self.screen, BLACK, (MAP_PIXEL_W, 0, SIDE_W, HEIGHT))
        pygame.draw.rect(self.screen, GRAY, (MAP_PIXEL_W, 0, SIDE_W, HEIGHT), 3)
        
        px = MAP_PIXEL_W + 15
        p = self.player
        
        self.screen.blit(self.font_l.render(f"地下 {self.floor} 階", True, YELLOW), (px, 20))
        
        rec_lv = int(self.floor * 1.5) + 3
        c_lv = GREEN if p.level >= rec_lv else RED
        self.screen.blit(self.font.render(f"Lv {p.level}", True, WHITE), (px, 60))
        self.screen.blit(self.font_s.render(f"(推奨: {rec_lv})", True, c_lv), (px+80, 64))
        
        self.screen.blit(self.font_s.render(f"HP: {p.hp}/{p.max_hp}", True, WHITE), (px, 90))
        pygame.draw.rect(self.screen, GRAY, (px, 110, SIDE_W-30, 10))
        if p.max_hp > 0:
            pygame.draw.rect(self.screen, RED, (px, 110, (SIDE_W-30) * max(0, p.hp) / p.max_hp, 10))
            
        self.screen.blit(self.font_s.render(f"MP: {p.mp}/{p.max_mp}", True, WHITE), (px, 130))
        pygame.draw.rect(self.screen, GRAY, (px, 150, SIDE_W-30, 10))
        if p.max_mp > 0:
            pygame.draw.rect(self.screen, BLUE, (px, 150, (SIDE_W-30) * max(0, p.mp) / p.max_mp, 10))
            
        self.screen.blit(self.font_s.render("ATB GAUGE", True, YELLOW), (px, 180))
        pygame.draw.rect(self.screen, GRAY, (px, 200, SIDE_W-30, 5))
        pygame.draw.rect(self.screen, YELLOW, (px, 200, (SIDE_W-30) * min(1.0, p.action_gauge/1000), 5))
        
        self.screen.blit(self.font.render(f"攻撃力: {p.atk}", True, WHITE), (px, 230))
        self.screen.blit(self.font.render(f"防御力: {p.defense}", True, WHITE), (px, 260))
        self.screen.blit(self.font.render(f"素早さ: {p.agi}", True, WHITE), (px, 290))
        
        self.screen.blit(self.font.render(f"未振分Pt: {p.stat_pts}", True, YELLOW), (px, 320))
        self.screen.blit(self.font.render(f"所持部品: {p.parts} 個", True, GREEN), (px, 350))

    def run(self):
        while True:
            self.screen.fill(BLACK)
            evs = pygame.event.get()
            
            for e in evs:
                if e.type == pygame.QUIT:
                    self.save_game() # 終了時に念のためセーブ
                    pygame.quit()
                    sys.exit()
                    
                if e.type == pygame.KEYDOWN:
                    # ---- チュートリアル ----
                    if self.state == "TUTORIAL":
                        if e.key in [pygame.K_ESCAPE, pygame.K_e]: # スキップ
                            self.audio.play("decide")
                            self.tutorial_done = True
                            self.change_state("MAP")
                            self.save_game()
                        elif e.key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                            self.audio.play("decide")
                            self.tutorial_step += 1
                            if self.tutorial_step >= len(self.tutorial_texts):
                                self.tutorial_done = True
                                self.change_state("MAP")
                                self.save_game()

                    # ---- 初期化の確認 ----
                    elif self.state == "MENU_INIT":
                        if e.key in [pygame.K_ESCAPE, pygame.K_e]:
                            self.change_state("MENU_MAIN")
                        elif e.key in [pygame.K_LEFT, pygame.K_RIGHT, pygame.K_a, pygame.K_d]:
                            self.audio.play("cursor")
                            self.cursor = 1 - self.cursor # 0:はい, 1:いいえ のトグル
                        elif e.key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                            self.audio.play("decide")
                            if self.cursor == 0: # はい
                                self.reset_save_data()
                            else: # いいえ
                                self.change_state("MENU_MAIN")

                    # ---- Esc / キャンセル処理 ----
                    elif e.key in [pygame.K_ESCAPE, pygame.K_e]:
                        if self.state == "MAP":
                            self.change_state("MENU_MAIN")
                        elif self.state == "MENU_MAIN":
                            self.change_state("MAP")
                            self.save_game() # メニューを閉じるときにセーブ
                        elif self.state in ["MENU_STATUS", "MENU_CRAFT", "MENU_LEVELUP", "MENU_MAGIC", "MENU_GUIDE", "MENU_ITEM"]:
                            self.change_state("MENU_MAIN")
                        elif self.state == "BATTLE_LEVELUP":
                            self.change_state("MAP")
                            self.save_game()
                        elif self.state in ["BATTLE_MAGIC", "BATTLE_ITEM"]:
                            self.change_state("BATTLE_MAIN")

                    # ---- コンティニュー ----
                    elif self.state == "GAMEOVER" and e.key == pygame.K_c:
                        self.audio.play("decide")
                        self.player.hp = 1
                        self.player.action_gauge = 0
                        self.player.active_def = 0
                        self.generate_map() # 新しいマップを作る（オートセーブされる）
                        self.player.x, self.player.y = 1, 1
                        self.change_state("MAP")
                        self.add_msg("死の淵から蘇った…！(HP1)")

                    # ---- マップ移動と宝箱・ギミック ----
                    elif self.state == "MAP":
                        nx, ny = self.player.x, self.player.y
                        moved = False
                        
                        if e.key in [pygame.K_UP, pygame.K_w]:
                            ny -= 1; self.player.dx, self.player.dy = 0, -1; moved = True
                        elif e.key in [pygame.K_DOWN, pygame.K_s]:
                            ny += 1; self.player.dx, self.player.dy = 0, 1; moved = True
                        elif e.key in [pygame.K_LEFT, pygame.K_a]:
                            nx -= 1; self.player.dx, self.player.dy = -1, 0; moved = True
                        elif e.key in [pygame.K_RIGHT, pygame.K_d]:
                            nx += 1; self.player.dx, self.player.dy = 1, 0; moved = True
                            
                        elif e.key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                            tx, ty = self.player.x + self.player.dx, self.player.y + self.player.dy
                            if 0 <= tx < MAP_WIDTH and 0 <= ty < MAP_HEIGHT and self.map_data[ty][tx] == 3:
                                self.audio.play("decide")
                                self.map_data[ty][tx] = 1 # 床にする
                                self.save_game() # 宝箱を開けたのでセーブ
                                
                                if random.random() < 0.15:
                                    self.enemy = Enemy(self.floor, False, True)
                                    self.change_state("BATTLE_MAIN")
                                    self.fighting_boss = False
                                    self.add_msg("宝箱はミミックだった！")
                                else:
                                    self.add_msg("宝箱を開けた！")
                                    if random.random() < 0.25:
                                        ex = int((10 * self.floor) * random.uniform(0.8, 1.2))
                                        self.player.exp += ex
                                        self.add_msg(f"経験値 {ex} 獲得！")
                                        
                                    r = random.randint(1, 100)
                                    pt = 1 if r<=30 else (2 if r<=60 else (3 if r<=80 else (4 if r<=90 else (5 if r<=95 else 6))))
                                    self.player.parts += pt
                                    self.add_msg(f"部品を {pt} 個手に入れた！")
                                    
                                    leveled = False
                                    while self.player.exp >= 10 * (self.player.level**2) + 5:
                                        self.audio.play("levelup")
                                        l = self.player.level_up()
                                        pts = 3 if random.random() < 0.05 else (2 if random.random() < 0.3 else 1)
                                        self.player.stat_pts += pts
                                        self.add_msg(f"レベルアップ！ ステータスPt {pts} 獲得！")
                                        if l: self.add_msg(f"新魔法【{l}】を覚えた！")
                                        leveled = True
                                        
                                    if leveled:
                                        self.change_state("BATTLE_LEVELUP")
                        
                        if moved and 0 <= nx < MAP_WIDTH and 0 <= ny < MAP_HEIGHT and self.map_data[ny][nx] not in [0, 3]:
                            if self.map_data[ny][nx] == 4:
                                self.audio.play("damage")
                                self.map_data[ny][nx] = 1
                                self.player.x, self.player.y = nx, ny
                                self.player.hp -= 10
                                self.save_game() # 罠を踏んだらセーブ
                                self.add_msg("落とし穴だ！ 10ダメージ！")
                                if self.player.hp <= 0:
                                    self.change_state("GAMEOVER")
                            elif (nx, ny) == self.stairs:
                                if not self.has_encountered:
                                    self.has_encountered = True
                                    self.enemy = Enemy(self.floor, False)
                                    self.change_state("BATTLE_MAIN")
                                    self.fighting_boss = False
                                    self.add_msg("階段の前に敵が潜んでいた！")
                                else:
                                    self.enemy = Enemy(self.floor, True)
                                    self.change_state("BATTLE_MAIN")
                                    self.fighting_boss = True
                                    self.add_msg(f"階層ボス {self.enemy.name} が立ちはだかった！")
                            else:
                                self.player.x, self.player.y = nx, ny
                                self.player.steps_since_encounter += 1
                                self.save_game() # 一歩移動するごとにオートセーブ
                                
                                if self.player.steps_since_encounter >= ENCOUNTER_COOLDOWN_STEPS and random.random() < ENCOUNTER_RATE and self.map_data[ny][nx] not in [4, 5]:
                                    self.has_encountered = True
                                    self.enemy = Enemy(self.floor, False)
                                    self.change_state("BATTLE_MAIN")
                                    self.fighting_boss = False
                                    self.add_msg(f"{self.enemy.name} が出現！")
                                    self.player.steps_since_encounter = 0

                    # ---- フィールドメニュー操作 ----
                    elif self.state == "MENU_MAIN":
                        opts = ["アイテム", "ステータス強化", "ステータス確認", "クラフト", "魔法 (フィールド)", "図鑑 (ガイド)", "初期化"]
                        if e.key in [pygame.K_UP, pygame.K_DOWN, pygame.K_w, pygame.K_s]:
                            self.audio.play("cursor")
                            self.cursor = (self.cursor + (1 if e.key in [pygame.K_DOWN, pygame.K_s] else -1)) % len(opts)
                        elif e.key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                            self.audio.play("decide")
                            if self.cursor == 6:
                                self.change_state("MENU_INIT")
                            else:
                                states = ["MENU_ITEM", "MENU_LEVELUP", "MENU_STATUS", "MENU_CRAFT", "MENU_MAGIC", "MENU_GUIDE"]
                                self.change_state(states[self.cursor])

                    elif self.state == "MENU_GUIDE":
                        opts = ["ストーリー", "操作/宝箱", "地形/アイテム", "敵特性", "強化/クラフト", "魔法/必殺技"]
                        if e.key in [pygame.K_UP, pygame.K_DOWN, pygame.K_w, pygame.K_s]:
                            self.audio.play("cursor")
                            self.guide_cursor = (self.guide_cursor + (1 if e.key in [pygame.K_DOWN, pygame.K_s] else -1)) % len(opts)

                    elif self.state in ["MENU_ITEM", "BATTLE_ITEM"]:
                        opts = [f"HP回復薬 (所持: {self.player.hp_potions})", f"MP回復薬 (所持: {self.player.mp_potions})"]
                        if e.key in [pygame.K_UP, pygame.K_DOWN, pygame.K_w, pygame.K_s]:
                            self.audio.play("cursor")
                            self.cursor = (self.cursor + (1 if e.key in [pygame.K_DOWN, pygame.K_s] else -1)) % len(opts)
                        elif e.key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                            if self.cursor == 0:
                                if self.player.hp_potions > 0:
                                    self.player.hp_potions -= 1
                                    self.player.hp = min(self.player.max_hp, self.player.hp + 50)
                                    self.audio.play("magic")
                                    self.add_msg("HP回復薬を使った！")
                                    self.player.action_gauge = 0
                                    if self.state == "BATTLE_ITEM": self.change_state("BATTLE_MAIN")
                                else:
                                    self.add_msg("薬がない！")
                            elif self.cursor == 1:
                                if self.player.mp_potions > 0:
                                    self.player.mp_potions -= 1
                                    self.player.mp = min(self.player.max_mp, self.player.mp + 30)
                                    self.audio.play("magic")
                                    self.add_msg("MP回復薬を使った！")
                                    self.player.action_gauge = 0
                                    if self.state == "BATTLE_ITEM": self.change_state("BATTLE_MAIN")
                                else:
                                    self.add_msg("薬がない！")

                    elif self.state == "MENU_CRAFT":
                        p = self.player
                        opts = [f"武器強化 (Lv{p.weapon_lv})", f"ギア調整 (Lv{p.gear_lv})", f"体力増強 (Lv{p.hp_lv})", f"魔力増強 (Lv{p.mp_lv})", f"魔法強化 (Lv{p.magic_lv})"]
                        if e.key in [pygame.K_UP, pygame.K_DOWN, pygame.K_w, pygame.K_s]:
                            self.audio.play("cursor")
                            self.cursor = (self.cursor + (1 if e.key in [pygame.K_DOWN, pygame.K_s] else -1)) % len(opts)
                        elif e.key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                            self.audio.play("decide")
                            lv_list = [p.weapon_lv, p.gear_lv, p.hp_lv, p.mp_lv, p.magic_lv]
                            cost = lv_list[self.cursor] * 5
                            if p.parts >= cost:
                                p.parts -= cost
                                if self.cursor == 0: p.weapon_lv += 1; self.add_msg("武器強化！")
                                elif self.cursor == 1: p.gear_lv += 1; self.add_msg("ギア調整！")
                                elif self.cursor == 2: p.hp_lv += 1; p.max_hp += 20; p.hp += 20; self.add_msg("最大HP増大！")
                                elif self.cursor == 3: p.mp_lv += 1; p.max_mp += 10; p.mp += 10; self.add_msg("最大MP増大！")
                                elif self.cursor == 4: p.magic_lv += 1; self.add_msg("魔法威力強化！")
                            else:
                                self.add_msg("部品が足りない！")

                    elif self.state in ["MENU_LEVELUP", "BATTLE_LEVELUP"]:
                        if e.key in [pygame.K_UP, pygame.K_DOWN, pygame.K_w, pygame.K_s]:
                            self.audio.play("cursor")
                            self.cursor = (self.cursor + (1 if e.key in [pygame.K_DOWN, pygame.K_s] else -1)) % 5
                        elif e.key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                            self.audio.play("decide")
                            p = self.player
                            if p.stat_pts > 0:
                                if self.cursor == 0: p.max_hp += 10; p.hp += 10; self.add_msg("最大HP上昇！")
                                elif self.cursor == 1: p.max_mp += 5; p.mp += 5; self.add_msg("最大MP上昇！")
                                elif self.cursor == 2: p.base_atk += 2; self.add_msg("攻撃力上昇！")
                                elif self.cursor == 3: p.base_def += 2; self.add_msg("防御力上昇！")
                                elif self.cursor == 4: p.base_agi += 2; self.add_msg("素早さ上昇！")
                                p.stat_pts -= 1
                            else:
                                self.add_msg("ポイントが足りません！")

                    elif self.state == "MENU_MAGIC":
                        u_spells = [s for s in self.player.spells if s["type"] in ["heal", "defense"]]
                        if e.key in [pygame.K_UP, pygame.K_DOWN, pygame.K_w, pygame.K_s]:
                            self.audio.play("cursor")
                            if len(u_spells) > 0:
                                self.cursor = (self.cursor + (1 if e.key in [pygame.K_DOWN, pygame.K_s] else -1)) % len(u_spells)
                        elif e.key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                            if not u_spells:
                                self.add_msg("使える魔法がない！")
                            else:
                                s = u_spells[self.cursor]
                                if self.player.mp >= s["cost"]:
                                    self.audio.play("magic")
                                    self.player.mp -= s["cost"]
                                    pwr = int(s["power"] * (1 + self.player.level * 0.05)) + (self.player.magic_lv - 1) * 10
                                    if s["type"] == "heal":
                                        self.player.hp = min(self.player.max_hp, self.player.hp + pwr)
                                        self.add_msg(f"{s['name']}！ {pwr}回復")
                                    elif s["type"] == "defense":
                                        self.player.active_def += pwr
                                        self.add_msg(f"{s['name']}！ 防御上昇")
                                else:
                                    self.audio.play("decide")
                                    self.add_msg("MPが足りない！")

                    # ---- 戦闘コマンド ----
                    elif self.state == "BATTLE_MAIN":
                        if self.player.action_gauge >= 1000:
                            req_mp = self.player.max_mp * 9 // 10
                            opts = ["攻撃", "魔法", "アイテム", f"必殺技(MP{req_mp})", "逃げる"] if self.fighting_boss else ["攻撃", "魔法", "アイテム", "逃げる"]
                            
                            if e.key in [pygame.K_UP, pygame.K_DOWN, pygame.K_w, pygame.K_s]:
                                self.audio.play("cursor")
                                self.cursor = (self.cursor + (1 if e.key in [pygame.K_DOWN, pygame.K_s] else -1)) % len(opts)
                            elif e.key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                                if self.cursor == 0:
                                    self.audio.play("attack")
                                    dmg = max(1, self.player.atk - self.enemy.atk//4 + random.randint(-3,3))
                                    if random.random() < 0.15:
                                        dmg = int(dmg * PHI)
                                        self.add_msg("黄金比クリティカル！")
                                    self.enemy.hp -= dmg
                                    self.add_msg(f"攻撃！ {dmg}ダメージ")
                                    self.player.action_gauge = 0
                                    self.cursor = 0
                                elif self.cursor == 1:
                                    self.audio.play("decide")
                                    self.change_state("BATTLE_MAGIC")
                                elif self.cursor == 2:
                                    self.audio.play("decide")
                                    self.change_state("BATTLE_ITEM")
                                elif self.fighting_boss and self.cursor == 3:
                                    self.audio.play("decide")
                                    if self.player.ultimate_cd > 0:
                                        self.add_msg(f"必殺技はあと {self.player.ultimate_cd} 階層で回復！")
                                    elif self.player.mp >= req_mp:
                                        self.player.mp -= req_mp
                                        self.player.ultimate_cd = 5
                                        self.audio.play("magic")
                                        self.enemy.hp = self.enemy.hp // 3
                                        self.add_msg("必殺技炸裂！ ボスのHPが1/3に！")
                                        self.player.action_gauge = 0
                                        self.cursor = 0
                                    else:
                                        self.add_msg("MPが足りない！")
                                elif (self.fighting_boss and self.cursor == 4) or (not self.fighting_boss and self.cursor == 3):
                                    self.audio.play("decide")
                                    if self.fighting_boss:
                                        self.add_msg("ボスからは逃げられない！")
                                        self.player.action_gauge = 0
                                    else:
                                        if random.random() < 0.30:
                                            self.add_msg("逃走成功！")
                                            self.player.action_gauge = 0
                                            self.player.active_def = 0
                                            self.change_state("MAP")
                                            self.save_game() # 逃走成功でセーブ
                                        else:
                                            self.add_msg("逃走失敗！")
                                            self.player.action_gauge = 0
                                            
                                # ボスのリミッター解除
                                if self.state != "MAP" and self.enemy.is_boss and self.enemy.hp <= self.enemy.max_hp // 2 and not self.enemy.phase_2:
                                    self.enemy.phase_2 = True
                                    self.add_msg("警告：敵のリミッター解除！")
                                    self.enemy.atk = int(self.enemy.atk * 1.5)
                                    self.enemy.agi = int(self.enemy.agi * 1.5)

                    elif self.state == "BATTLE_MAGIC":
                        if e.key in [pygame.K_UP, pygame.K_DOWN, pygame.K_w, pygame.K_s]:
                            self.audio.play("cursor")
                            self.cursor = (self.cursor + (1 if e.key in [pygame.K_DOWN, pygame.K_s] else -1)) % len(self.player.spells)
                        elif e.key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                            s = self.player.spells[self.cursor]
                            if self.player.mp >= s["cost"]:
                                self.audio.play("magic")
                                self.player.mp -= s["cost"]
                                pwr = int(s["power"] * (1 + self.player.level * 0.05)) + (self.player.magic_lv - 1) * 10
                                if s["type"] == "heal":
                                    self.player.hp = min(self.player.max_hp, self.player.hp + pwr)
                                    self.add_msg(f"{s['name']}！ {pwr}回復")
                                elif s["type"] == "attack":
                                    dmg = pwr + random.randint(-5, 5)
                                    self.enemy.hp -= dmg
                                    self.add_msg(f"{s['name']}！ {dmg}ダメージ")
                                elif s["type"] == "defense":
                                    self.player.active_def += pwr
                                    self.add_msg(f"{s['name']}！ 防御力上昇")
                                self.player.action_gauge = 0
                                self.change_state("BATTLE_MAIN")
                            else:
                                self.audio.play("decide")
                                self.add_msg("MPが足りない！")

                    elif self.state == "CRAFT_SAFE_AREA":
                        if e.key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                            self.audio.play("decide")
                            self.generate_map()
                            self.player.x, self.player.y = 1, 1
                            self.change_state("MAP")
                            self.save_game() # 階層移動時にセーブ

            # ---- マップ時のトゲ判定 (毎フレーム) ----
            if self.state == "MAP" and self.map_data[self.player.y][self.player.x] == 5:
                self.spike_timer += 1
                if self.spike_timer >= 60:
                    self.audio.play("damage")
                    self.player.hp -= 3
                    self.spike_timer = 0
                    if self.player.hp <= 0:
                        self.change_state("GAMEOVER")
            elif self.state == "MAP":
                self.spike_timer = 0

            # ---- 戦闘の自動進行と勝敗 ----
            if self.state in ["BATTLE_MAIN", "BATTLE_MAGIC", "BATTLE_ITEM"]:
                if self.enemy.action_gauge >= 1000 and self.player.action_gauge < 1000:
                    self.audio.play("damage")
                    dmg = max(1, self.enemy.atk - self.player.defense // 2)
                    self.player.hp -= dmg
                    self.add_msg(f"敵の攻撃！ {dmg}ダメージ")
                    self.enemy.action_gauge = 0
                elif self.player.action_gauge < 1000:
                    self.player.action_gauge += self.player.agi
                    self.enemy.action_gauge += self.enemy.agi
                
                if self.enemy.hp <= 0:
                    self.player.exp += self.enemy.exp_yield
                    self.player.parts += self.enemy.drop_parts
                    self.player.active_def = 0
                    self.add_msg(f"勝利！ EXP {self.enemy.exp_yield} 獲得 (部品+{self.enemy.drop_parts})")
                    
                    dr = random.random()
                    if dr < 0.10: self.player.hp_potions += 1; self.add_msg("敵が『HP回復薬』を落とした！")
                    elif dr < 0.20: self.player.mp_potions += 1; self.add_msg("敵が『MP回復薬』を落とした！")
                    
                    lv_up = False
                    while self.player.exp >= 10 * (self.player.level**2) + 5:
                        self.audio.play("levelup")
                        ln = self.player.level_up()
                        r = random.randint(1, 100)
                        pts = 3 if r <= 5 else (2 if r <= 30 else 1)
                        self.player.stat_pts += pts
                        self.add_msg(f"LvUp！ Pt {pts} 獲得！")
                        if ln: self.add_msg(f"新魔法【{ln}】を覚えた！")
                        lv_up = True
                        
                    if self.fighting_boss:
                        self.add_msg("階層ボスを撃破した！")
                        self.floor += 1
                        if self.player.ultimate_cd > 0:
                            self.player.ultimate_cd -= 1
                        if self.floor % 10 == 0:
                            self.change_state("CRAFT_SAFE_AREA")
                            self.player.hp = self.player.max_hp
                            self.player.mp = self.player.max_mp
                        else:
                            self.generate_map()
                            self.player.x, self.player.y = 1, 1
                            self.change_state("BATTLE_LEVELUP" if lv_up else "MAP")
                            if not lv_up: self.save_game() # 戦闘終了時セーブ
                    else:
                        self.change_state("BATTLE_LEVELUP" if lv_up else "MAP")
                        if not lv_up: self.save_game() # 戦闘終了時セーブ
                        
                elif self.player.hp <= 0:
                    self.player.active_def = 0
                    self.change_state("GAMEOVER")

            # ---- 描画処理 ----
            
            # 背景マップの描画
            if self.state in ["MAP", "MENU_MAIN", "MENU_STATUS", "MENU_CRAFT", "MENU_LEVELUP", "MENU_MAGIC", "MENU_GUIDE", "BATTLE_LEVELUP", "MENU_ITEM", "MENU_INIT", "TUTORIAL"]:
                for y in range(MAP_HEIGHT):
                    for x in range(MAP_WIDTH):
                        tex = self.textures[['wall', 'floor', 'stairs', 'chest', 'hole', 'spike'][self.map_data[y][x]]]
                        self.screen.blit(tex, (x*GRID_SIZE, y*GRID_SIZE))
                        
                px, py = self.player.x * GRID_SIZE, self.player.y * GRID_SIZE
                self.screen.blit(self.textures['player'], (px, py))
                mx = px + GRID_SIZE//2 + self.player.dx * (GRID_SIZE//2 - 5)
                my = py + GRID_SIZE//2 + self.player.dy * (GRID_SIZE//2 - 5)
                pygame.draw.circle(self.screen, RED, (mx, my), 4)

            # --- チュートリアル ---
            if self.state == "TUTORIAL":
                r = pygame.Rect(MAP_PIXEL_W//2 - 250, MAP_PIXEL_H//2 - 100, 500, 200)
                # 半透明の黒背景
                s = pygame.Surface((r.width, r.height))
                s.set_alpha(220)
                s.fill(BLACK)
                self.screen.blit(s, (r.x, r.y))
                pygame.draw.rect(self.screen, YELLOW, r, 3)
                
                self.screen.blit(self.font_l.render("=== チュートリアル ===", True, WHITE), (r.x + 100, r.y + 20))
                
                # テキスト表示
                txt = self.tutorial_texts[self.tutorial_step]
                self.screen.blit(self.font.render(txt, True, LT_GRAY), (r.x + 30, r.y + 80))
                
                self.screen.blit(self.font.render("Space/Enter: 次へ   E/Esc: スキップ", True, GRAY), (r.right - 350, r.bottom - 30))

            elif self.state == "MENU_MAIN":
                r = pygame.Rect(MAP_PIXEL_W//2 - 150, MAP_PIXEL_H//2 - 160, 300, 320)
                pygame.draw.rect(self.screen, BLACK, r)
                pygame.draw.rect(self.screen, WHITE, r, 3)
                self.screen.blit(self.font_l.render("=== MENU ===", True, WHITE), (MAP_PIXEL_W//2 - 80, MAP_PIXEL_H//2 - 140))
                opts = ["アイテム", "ステータス強化", "ステータス確認", "クラフト", "魔法 (フィールド)", "図鑑 (ガイド)", "初期化"]
                for i, o in enumerate(opts):
                    c = YELLOW if i == self.cursor else WHITE
                    # 初期化だけ少し離して赤色っぽく
                    color = RED if i == 6 and i == self.cursor else c
                    self.screen.blit(self.font.render(f"{'▶' if i==self.cursor else ' '} {o}", True, color), (MAP_PIXEL_W//2 - 100, MAP_PIXEL_H//2 - 70 + i*30))
                self.screen.blit(self.font.render("E/Esc: 閉じる", True, GRAY), (MAP_PIXEL_W//2 - 100, MAP_PIXEL_H//2 + 130))
                
            elif self.state == "MENU_INIT":
                r = pygame.Rect(MAP_PIXEL_W//2 - 150, MAP_PIXEL_H//2 - 80, 300, 160)
                pygame.draw.rect(self.screen, BLACK, r)
                pygame.draw.rect(self.screen, RED, r, 3)
                self.screen.blit(self.font.render("セーブデータを初期化しますか？", True, WHITE), (r.x + 10, r.y + 30))
                self.screen.blit(self.font.render("(ゲームが完全に最初からになります)", True, GRAY), (r.x + 5, r.y + 60))
                
                c_yes = YELLOW if self.cursor == 0 else WHITE
                c_no = YELLOW if self.cursor == 1 else WHITE
                
                self.screen.blit(self.font.render(f"{'▶' if self.cursor==0 else ' '} はい", True, c_yes), (r.x + 60, r.y + 110))
                self.screen.blit(self.font.render(f"{'▶' if self.cursor==1 else ' '} いいえ", True, c_no), (r.x + 160, r.y + 110))
                
            elif self.state == "MENU_GUIDE":
                r = pygame.Rect(20, 20, WIDTH - 40, HEIGHT - 40)
                pygame.draw.rect(self.screen, DK_GRAY, r)
                pygame.draw.rect(self.screen, CYAN, r, 3)
                self.screen.blit(self.font_l.render("=== 冒険者図鑑 ===", True, WHITE), (r.x + 30, r.y + 20))
                
                opts = ["ストーリー", "操作/宝箱", "地形/アイテム", "敵特性", "強化/クラフト", "魔法/必殺技"]
                for i, o in enumerate(opts):
                    c = YELLOW if i == self.guide_cursor else WHITE
                    self.screen.blit(self.font.render(f"{'▶' if i==self.guide_cursor else ' '} {o}", True, c), (r.x + 20, r.y + 80 + i*40))
                
                dx, dy = r.x + 230, r.y + 80
                texts = [
                    ["黒猫クロを救うため、無機質な", "機械兵が徘徊する地下100階層の", "ダンジョンへ足を踏み入れる。"],
                    ["WSAD/矢印:移動  Space/Enter:決定", "E/Esc:戻る", "宝箱はマーカーが向いている状態で", "決定キーで開く。稀にミミックが出る。"],
                    ["落とし穴:10ダメ。トゲ:継続ダメ", "", "アイテム:敵が稀にHP/MP回復薬をドロップ", "回復手段が限られているため重要。"],
                    ["狙撃:高火/低速  妨害:防御/高速", "狂化:暴走/高火  ミミック:宝箱から出現", "倒すと多くの部品を落とす。"],
                    ["LvUpのPtでステータスを上げる。", "集めた部品を消費して、武器、ギア", "最大体力等をメニューから永続強化。"],
                    ["Lv5毎に習得。威力はLv等で上昇。", "", "必殺技:ボス戦専用。最大MP90%消費。", "ボスHPを1/3にする。CT5階層。"]
                ][self.guide_cursor]
                
                for i, t in enumerate(texts):
                    self.screen.blit(self.font.render(t, True, LT_GRAY), (dx, dy + i*30))
                self.screen.blit(self.font.render("E/Esc: 戻る", True, GRAY), (r.right - 140, r.bottom - 30))
                
            elif self.state in ["BATTLE_MAIN", "BATTLE_MAGIC", "BATTLE_ITEM"]:
                pygame.draw.rect(self.screen, DK_GRAY, (0, 0, MAP_PIXEL_W, MAP_PIXEL_H))
                t = self.textures['boss'] if self.fighting_boss else self.textures[f'enemy_{self.enemy.type_str}']
                if self.fighting_boss and self.enemy.phase_2: t = self.textures['boss_p2']
                self.screen.blit(t, t.get_rect(center=(MAP_PIXEL_W//2, MAP_PIXEL_H//2 - 40)))
                
                hr = self.enemy.hp / self.enemy.max_hp
                pygame.draw.rect(self.screen, RED, (MAP_PIXEL_W//2 - 100, MAP_PIXEL_H//2 + 50, 200, 10))
                if hr > 0:
                    pygame.draw.rect(self.screen, GREEN, (MAP_PIXEL_W//2 - 100, MAP_PIXEL_H//2 + 50, 200 * hr, 10))
                self.screen.blit(self.font.render(self.enemy.name, True, WHITE), (MAP_PIXEL_W//2 - 80, MAP_PIXEL_H//2 + 30))
                
                if self.player.action_gauge >= 1000:
                    cw, ch = 260, 160
                    cr = pygame.Rect(MAP_PIXEL_W//2 - cw//2, MAP_PIXEL_H//2 + 70, cw, ch)
                    pygame.draw.rect(self.screen, BLUE, cr)
                    pygame.draw.rect(self.screen, WHITE, cr, 2)
                    
                    if self.state == "BATTLE_MAIN":
                        req = self.player.max_mp * 9 // 10
                        opts = ["攻撃", "魔法", "アイテム", f"極技(MP{req})", "逃げる"] if self.fighting_boss else ["攻撃", "魔法", "アイテム", "逃げる"]
                        for i, o in enumerate(opts):
                            c = YELLOW if i == self.cursor else WHITE
                            self.screen.blit(self.font.render(f"{'▶' if i==self.cursor else ' '} {o}", True, c), (cr.x + 20, cr.y + 15 + i*28))
                    elif self.state == "BATTLE_MAGIC":
                        for i, s in enumerate(self.player.spells):
                            c = YELLOW if i == self.cursor else WHITE
                            self.screen.blit(self.font.render(f"{'▶' if i==self.cursor else ' '} {s['name']} (MP{s['cost']})", True, c), (cr.x + 20, cr.y + 15 + i*25))
                    elif self.state == "BATTLE_ITEM":
                        opts = [f"HP薬({self.player.hp_potions})", f"MP薬({self.player.mp_potions})"]
                        for i, o in enumerate(opts):
                            c = YELLOW if i == self.cursor else WHITE
                            self.screen.blit(self.font.render(f"{'▶' if i==self.cursor else ' '} {o}", True, c), (cr.x + 20, cr.y + 15 + i*35))

            elif self.state == "MENU_STATUS":
                r = pygame.Rect(50, 50, MAP_PIXEL_W - 100, MAP_PIXEL_H - 100)
                pygame.draw.rect(self.screen, DK_GRAY, r)
                pygame.draw.rect(self.screen, GREEN, r, 3)
                p, x, y = self.player, r.x+30, r.y+20
                self.screen.blit(self.font_l.render("=== ステータス確認 ===", True, WHITE), (x, y))
                self.screen.blit(self.font.render(f"Lv: {p.level}   EXP: {p.exp}", True, WHITE), (x, y+50))
                self.screen.blit(self.font.render(f"HP: {p.hp}/{p.max_hp}  MP: {p.mp}/{p.max_mp}", True, WHITE), (x, y+80))
                self.screen.blit(self.font.render(f"攻撃力: {p.atk}  防御力: {p.defense}  素早さ: {p.agi}", True, WHITE), (x, y+110))
                self.screen.blit(self.font.render(f"未振分Pt: {p.stat_pts}  部品: {p.parts}", True, YELLOW), (x, y+140))
                self.screen.blit(self.font.render(f"薬: HP {p.hp_potions}個 / MP {p.mp_potions}個", True, GREEN), (x, y+170))
                ct = "使用可能" if p.ultimate_cd<=0 else f"あと{p.ultimate_cd}階層"
                self.screen.blit(self.font.render(f"必殺技: {ct}", True, CYAN), (x, y+200))
                self.screen.blit(self.font.render("E/Esc: 戻る", True, GRAY), (r.right - 140, r.bottom - 30))

            elif self.state == "MENU_CRAFT":
                r = pygame.Rect(50, 50, MAP_PIXEL_W - 100, MAP_PIXEL_H - 100)
                pygame.draw.rect(self.screen, DK_GRAY, r)
                pygame.draw.rect(self.screen, BLUE, r, 3)
                p = self.player
                self.screen.blit(self.font_l.render("=== クラフト ===", True, WHITE), (r.x+100, r.y+20))
                self.screen.blit(self.font.render(f"所持部品: {p.parts} 個", True, GREEN), (r.x+30, r.y+60))
                opts = [f"武器 (Lv{p.weapon_lv}) - コスト:{p.weapon_lv*5}", f"ギア (Lv{p.gear_lv}) - コスト:{p.gear_lv*5}",
                        f"体力 (Lv{p.hp_lv}) - コスト:{p.hp_lv*5}", f"魔力 (Lv{p.mp_lv}) - コスト:{p.mp_lv*5}",
                        f"魔法 (Lv{p.magic_lv}) - コスト:{p.magic_lv*5}"]
                for i, o in enumerate(opts):
                    c = YELLOW if i == self.cursor else WHITE
                    self.screen.blit(self.font.render(f"{'▶' if i==self.cursor else ' '} {o}", True, c), (r.x+30, r.y+100+i*30))
                self.screen.blit(self.font.render("E/Esc: 戻る", True, GRAY), (r.right - 140, r.bottom - 30))

            elif self.state in ["MENU_LEVELUP", "BATTLE_LEVELUP"]:
                r = pygame.Rect(50, 50, MAP_PIXEL_W - 100, MAP_PIXEL_H - 100)
                pygame.draw.rect(self.screen, DK_GRAY, r)
                pygame.draw.rect(self.screen, YELLOW, r, 3)
                p = self.player
                t = "レベルアップ！" if self.state == "BATTLE_LEVELUP" else "ステータス強化"
                self.screen.blit(self.font_xl.render(t, True, YELLOW if self.state=="BATTLE_LEVELUP" else WHITE), (r.x+80, 50))
                self.screen.blit(self.font.render(f"残りポイント: {p.stat_pts} Pt", True, GREEN), (r.x+30, 110))
                opts = [f"最大HP(+10) [現在:{p.max_hp}]", f"最大MP(+5) [現在:{p.max_mp}]",
                        f"攻撃力(+2) [現在:{p.base_atk}]", f"防御力(+2) [現在:{p.base_def}]",
                        f"素早さ(+2) [現在:{p.base_agi}]"]
                for i, o in enumerate(opts):
                    c = YELLOW if i == self.cursor else WHITE
                    self.screen.blit(self.font.render(f"{'▶' if i==self.cursor else ' '} {o}", True, c), (r.x+30, 150+i*30))
                self.screen.blit(self.font.render("E/Esc: 戻る", True, GRAY), (r.right - 140, r.bottom - 30))

            elif self.state == "MENU_MAGIC" or self.state == "MENU_ITEM":
                r = pygame.Rect(MAP_PIXEL_W//2 - 180, MAP_PIXEL_H//2 - 130, 360, 260)
                pygame.draw.rect(self.screen, BLACK, r)
                pygame.draw.rect(self.screen, BLUE if self.state=="MENU_MAGIC" else RED, r, 3)
                t = "フィールド魔法" if self.state=="MENU_MAGIC" else "アイテム"
                self.screen.blit(self.font_l.render(f"=== {t} ===", True, WHITE), (r.x+30, r.y+20))
                
                if self.state == "MENU_MAGIC":
                    us = [s for s in self.player.spells if s["type"] in ["heal", "defense"]]
                    if not us: self.screen.blit(self.font.render("使える魔法なし", True, GRAY), (r.x+30, r.y+80))
                    else:
                        for i, s in enumerate(us):
                            c = YELLOW if i == self.cursor else WHITE
                            self.screen.blit(self.font.render(f"{'▶' if i==self.cursor else ' '} {s['name']}(MP{s['cost']})", True, c), (r.x+30, r.y+80+i*30))
                else:
                    opts = [f"HP回復薬 (所持: {self.player.hp_potions})", f"MP回復薬 (所持: {self.player.mp_potions})"]
                    for i, o in enumerate(opts):
                        c = YELLOW if i == self.cursor else WHITE
                        self.screen.blit(self.font.render(f"{'▶' if i==self.cursor else ' '} {o}", True, c), (r.x+30, r.y+80+i*40))
                self.screen.blit(self.font.render("E/Esc: 戻る", True, GRAY), (r.right - 140, r.bottom - 30))

            elif self.state == "CRAFT_SAFE_AREA":
                pygame.draw.rect(self.screen, DK_GRAY, (0, 0, MAP_PIXEL_W, MAP_PIXEL_H))
                self.screen.blit(self.font_l.render("--- セーフエリア ---", True, GREEN), (100, 100))
                self.screen.blit(self.font.render("HPとMPが全回復した。クラフトなどが行える。", True, WHITE), (100, 160))
                self.screen.blit(self.font.render("Space/Enterキーで次の階層へ進む", True, YELLOW), (100, 220))

            elif self.state == "GAMEOVER":
                self.screen.blit(self.font_xl.render("GAME OVER", True, RED), (MAP_PIXEL_W//2-100, MAP_PIXEL_H//2-40))
                self.screen.blit(self.font.render("クロを救い出せなかった...", True, WHITE), (MAP_PIXEL_W//2-120, MAP_PIXEL_H//2+20))
                self.screen.blit(self.font.render("Cキー: コンティニュー (HP1で再開)", True, YELLOW), (MAP_PIXEL_W//2-170, MAP_PIXEL_H//2+60))

        async def run(self):  # ← async を追加する
            while True:
                self.screen.fill(BLACK)
                events = pygame.event.get()
                # ... (中略) ...
                self.draw_ui()
                pygame.display.flip()
                self.clock.tick(FPS)
                await asyncio.sleep(0) # ← ループの最後に、ブラウザへ制御を返す魔法のおまじないを追加！

if __name__ == "__main__":
    game = Game()
    asyncio.run(game.run())

