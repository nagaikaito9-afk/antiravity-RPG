import pygame
import random
import math
import sys
import os
import json
import asyncio

# --- 定数設定 ---
PHI = (1 + math.sqrt(5)) / 2
GRID_SIZE = 40
MAP_WIDTH, MAP_HEIGHT = 15, 10

MAP_PIXEL_W = MAP_WIDTH * GRID_SIZE
MAP_PIXEL_H = MAP_HEIGHT * GRID_SIZE
LOG_H = 160
SIDE_W = 250
WIDTH = MAP_PIXEL_W + SIDE_W
HEIGHT = MAP_PIXEL_H + LOG_H

ENCOUNTER_RATE = 0.10
ENCOUNTER_COOLDOWN_STEPS = 3
ENEMY_TEX_SIZE = 150

FPS = 60

# --- 色定義 ---
BLACK, WHITE = (10, 10, 10), (240, 240, 240)
GRAY, DK_GRAY, LT_GRAY = (80, 80, 80), (40, 40, 40), (160, 160, 160)
RED, DK_RED = (220, 50, 50), (120, 20, 20)
BLUE, CYAN = (50, 100, 250), (50, 220, 255)
GREEN, DK_GREEN = (50, 200, 50), (20, 100, 20)
YELLOW, GOLD = (255, 215, 0), (218, 165, 32)
SILVER, BROWN, PURPLE = (192, 192, 192), (139, 69, 19), (147, 112, 219)

# --- 音声管理クラス ---
class AudioManager:
    def __init__(self):
        self.audio_ready = False
        self.bgm_started = False
        self.sounds = {}

    def init_audio(self):
        if self.audio_ready:
            return
        try:
            pygame.mixer.init()
            se_files = {
                "cursor": "cursor.ogg", "decide": "decide.ogg", "attack": "attack.ogg",
                "magic": "magic.ogg", "damage": "damage.ogg", "levelup": "levelup.ogg"
            }
            for name, filename in se_files.items():
                if os.path.exists(filename):
                    self.sounds[name] = pygame.mixer.Sound(filename)
                else:
                    self.sounds[name] = None
            if os.path.exists("bgm.ogg"):
                pygame.mixer.music.load("bgm.ogg")
            self.audio_ready = True
        except:
            pass

    def play(self, name):
        if self.audio_ready and name in self.sounds and self.sounds[name]:
            try:
                self.sounds[name].play()
            except:
                pass

    def start_bgm(self):
        self.init_audio()
        if not self.bgm_started and self.audio_ready:
            self.bgm_started = True
            try:
                pygame.mixer.music.play(-1)
            except:
                pass

# --- リアルな立体描画ヘルパー関数 ---
def draw_shaded_rect(surf, color, rect, radius=0):
    pygame.draw.rect(surf, color, rect, border_radius=radius)
    hl_color = (min(255, color[0]+60), min(255, color[1]+60), min(255, color[2]+60))
    hl_rect = (rect[0]+2, rect[1]+2, rect[2]-4, max(1, rect[3]//4))
    pygame.draw.rect(surf, hl_color, hl_rect, border_radius=radius)
    sh_color = (max(0, color[0]-60), max(0, color[1]-60), max(0, color[2]-60))
    sh_rect = (rect[0]+2, rect[1]+rect[3]-max(1, rect[3]//3)-2, rect[2]-4, max(1, rect[3]//3))
    pygame.draw.rect(surf, sh_color, sh_rect, border_radius=radius)

# --- テクスチャ生成関数 ---
def create_textures():
    textures = {}
    
    floor = pygame.Surface((GRID_SIZE, GRID_SIZE))
    floor.fill((140, 140, 140))
    for _ in range(15):
        rx, ry = random.randint(2, GRID_SIZE-4), random.randint(2, GRID_SIZE-4)
        c = random.choice([(120, 120, 120), (160, 160, 160)])
        pygame.draw.rect(floor, c, (rx, ry, 6, 6))
    pygame.draw.rect(floor, (180, 180, 180), (0, 0, GRID_SIZE, GRID_SIZE), 1)
    textures['floor'] = floor
    
    wall = pygame.Surface((GRID_SIZE, GRID_SIZE))
    wall.fill((40, 40, 40))
    for i in range(2):
        for j in range(2):
            x, y = j*20, i*20
            if i == 1: x = (j*20+10)%40-10
            draw_shaded_rect(wall, (60, 60, 60), (x, y, 20, 20), 2)
    textures['wall'] = wall
    
    stairs = pygame.Surface((GRID_SIZE, GRID_SIZE))
    for i in range(5):
        h = GRID_SIZE // 5
        c = max(20, 160 - i*30)
        draw_shaded_rect(stairs, (0, c, 0), (0, i*h, GRID_SIZE, h))
    textures['stairs'] = stairs
    
    chest = pygame.Surface((GRID_SIZE, GRID_SIZE), pygame.SRCALPHA)
    draw_shaded_rect(chest, BROWN, (6, 10, GRID_SIZE-12, GRID_SIZE-16), 3)
    pygame.draw.rect(chest, GOLD, (6, 10, GRID_SIZE-12, GRID_SIZE-16), 2, border_radius=3)
    draw_shaded_rect(chest, GOLD, (GRID_SIZE//2-4, 16, 8, 8), 1)
    textures['chest'] = chest

    hole = floor.copy()
    for i in range(12):
        c = max(0, 100 - i*10)
        pygame.draw.circle(hole, (c, c, c), (GRID_SIZE//2, GRID_SIZE//2), GRID_SIZE//2 - i)
    textures['hole'] = hole
    
    spike = floor.copy()
    draw_shaded_rect(spike, (60, 60, 60), (4, 4, GRID_SIZE-8, GRID_SIZE-8), 4)
    for px, py in [(12,12), (28,12), (12,28), (28,28)]:
        pygame.draw.polygon(spike, DK_RED, [(px, py-14), (px-6, py+4), (px+6, py+4)])
        pygame.draw.polygon(spike, RED, [(px, py-14), (px-3, py+4), (px+3, py+4)])
    textures['spike'] = spike

    player = pygame.Surface((GRID_SIZE, GRID_SIZE), pygame.SRCALPHA)
    draw_shaded_rect(player, BLUE, (12, 12, 16, 22), 3) 
    draw_shaded_rect(player, SILVER, (10, 16, 20, 14), 4)
    pygame.draw.circle(player, SILVER, (20, 12), 8)
    pygame.draw.rect(player, BLACK, (15, 10, 10, 3))
    draw_shaded_rect(player, BROWN, (4, 14, 10, 14), 2)
    pygame.draw.rect(player, SILVER, (4, 14, 10, 14), 1, border_radius=2)
    draw_shaded_rect(player, BROWN, (29, 20, 4, 8))
    draw_shaded_rect(player, GOLD, (27, 18, 8, 3))
    draw_shaded_rect(player, SILVER, (29, 4, 4, 14))
    textures['player'] = player

    def draw_mech(color, eye_color, shape="normal"):
        surf = pygame.Surface((ENEMY_TEX_SIZE, ENEMY_TEX_SIZE), pygame.SRCALPHA)
        if shape == "tank":
            draw_shaded_rect(surf, color, (30, 50, 90, 70), 15)
            draw_shaded_rect(surf, DK_GRAY, (20, 100, 110, 30), 5)
            pygame.draw.circle(surf, eye_color, (75, 70), 15)
        elif shape == "attacker":
            pygame.draw.polygon(surf, color, [(75, 20), (120, 120), (30, 120)])
            pygame.draw.polygon(surf, DK_GRAY, [(75, 40), (100, 110), (50, 110)])
            pygame.draw.circle(surf, eye_color, (75, 80), 10)
        elif shape == "speed":
            draw_shaded_rect(surf, color, (50, 20, 50, 110), 25)
            draw_shaded_rect(surf, SILVER, (30, 60, 20, 40), 10)
            draw_shaded_rect(surf, SILVER, (100, 60, 20, 40), 10)
            pygame.draw.circle(surf, eye_color, (75, 40), 8)
        elif shape == "sniper":
            draw_shaded_rect(surf, color, (65, 30, 20, 100), 5)
            draw_shaded_rect(surf, SILVER, (70, 10, 10, 60))
            pygame.draw.circle(surf, eye_color, (75, 80), 8)
            pygame.draw.circle(surf, WHITE, (75, 80), 3)
        elif shape == "jammer":
            pygame.draw.circle(surf, color, (75, 75), 45)
            pygame.draw.circle(surf, DK_GRAY, (75, 75), 35)
            pygame.draw.circle(surf, eye_color, (75, 75), 15)
            for i in range(4):
                pygame.draw.arc(surf, eye_color, (15, 15, 120, 120), i*1.5, i*1.5+0.5, 4)
        elif shape == "berserker":
            draw_shaded_rect(surf, BLACK, (45, 40, 60, 80), 8)
            pygame.draw.rect(surf, color, (45, 40, 60, 80), 4, border_radius=8)
            pygame.draw.circle(surf, RED, (75, 70), 20)
            pygame.draw.circle(surf, WHITE, (75, 70), 5)
        else:
            draw_shaded_rect(surf, color, (50, 50, 50, 70), 10)
            pygame.draw.circle(surf, eye_color, (75, 70), 12)
        return surf

    textures['enemy_normal'] = draw_mech(GRAY, RED, "normal")
    textures['enemy_tank'] = draw_mech((70, 90, 60), YELLOW, "tank")
    textures['enemy_attacker'] = draw_mech((150, 50, 50), CYAN, "attacker")
    textures['enemy_speed'] = draw_mech((60, 80, 160), WHITE, "speed")
    textures['enemy_sniper'] = draw_mech((50, 100, 50), GREEN, "sniper")
    textures['enemy_jammer'] = draw_mech(PURPLE, WHITE, "jammer")
    textures['enemy_berserker'] = draw_mech(RED, RED, "berserker")
    textures['enemy_mimic'] = draw_mech(BROWN, RED, "normal")

    boss_0 = pygame.Surface((ENEMY_TEX_SIZE, ENEMY_TEX_SIZE), pygame.SRCALPHA)
    draw_shaded_rect(boss_0, DK_GRAY, (45, 30, 60, 90), 10)
    draw_shaded_rect(boss_0, GRAY, (25, 20, 35, 50), 8)
    draw_shaded_rect(boss_0, GRAY, (90, 20, 35, 50), 8)
    pygame.draw.circle(boss_0, RED, (75, 50), 14)
    textures['boss_0'] = boss_0

    boss_1 = pygame.Surface((ENEMY_TEX_SIZE, ENEMY_TEX_SIZE), pygame.SRCALPHA)
    for px, py in [(20, 30), (130, 30), (30, 120), (120, 120)]:
        pygame.draw.line(boss_1, DK_GREEN, (75, 75), (px, py), 18)
        pygame.draw.circle(boss_1, SILVER, (px, py), 12)
    draw_shaded_rect(boss_1, (40, 50, 40), (45, 45, 60, 60), 30)
    pygame.draw.circle(boss_1, PURPLE, (60, 60), 10)
    pygame.draw.circle(boss_1, PURPLE, (90, 60), 10)
    pygame.draw.circle(boss_1, RED, (75, 85), 12)
    textures['boss_1'] = boss_1

    boss_2 = pygame.Surface((ENEMY_TEX_SIZE, ENEMY_TEX_SIZE), pygame.SRCALPHA)
    pygame.draw.polygon(boss_2, SILVER, [(75, 10), (140, 110), (75, 90), (10, 110)])
    draw_shaded_rect(boss_2, BLUE, (60, 40, 30, 50), 5)
    pygame.draw.circle(boss_2, CYAN, (45, 100), 12)
    pygame.draw.circle(boss_2, CYAN, (105, 100), 12)
    textures['boss_2'] = boss_2

    boss_3 = pygame.Surface((ENEMY_TEX_SIZE, ENEMY_TEX_SIZE), pygame.SRCALPHA)
    draw_shaded_rect(boss_3, DK_GRAY, (10, 80, 130, 50), 15)
    draw_shaded_rect(boss_3, GREEN, (35, 40, 80, 50), 20)
    draw_shaded_rect(boss_3, (30,30,30), (35, 10, 20, 50))
    draw_shaded_rect(boss_3, (30,30,30), (95, 10, 20, 50))
    pygame.draw.circle(boss_3, YELLOW, (75, 65), 12)
    textures['boss_3'] = boss_3

    boss_4 = pygame.Surface((ENEMY_TEX_SIZE, ENEMY_TEX_SIZE), pygame.SRCALPHA)
    pygame.draw.circle(boss_4, WHITE, (75, 75), 45)
    pygame.draw.circle(boss_4, CYAN, (75, 75), 38)
    for i in range(8):
        angle = i * math.pi / 4
        x = 75 + math.cos(angle) * 65
        y = 75 + math.sin(angle) * 65
        draw_shaded_rect(boss_4, GOLD, (x-12, y-12, 24, 24), 6)
    textures['boss_4'] = boss_4

    for i in range(5):
        p2 = textures[f'boss_{i}'].copy()
        pygame.draw.circle(p2, RED, (75, 75), 65, 6)
        textures[f'boss_{i}_p2'] = p2

    return textures

class Player:
    def __init__(self):
        self.x, self.y = 1, 1
        self.dx, self.dy = 0, 1
        self.level, self.exp = 1, 0
        self.hp, self.max_hp = 60, 60
        self.mp, self.max_mp = 20, 20
        self.base_atk, self.base_def, self.base_agi = 12, 5, 10
        self.scrap, self.motor, self.cpu = 0, 0, 0
        self.stat_pts = 0
        self.weapon_lv, self.gear_lv, self.hp_lv, self.mp_lv, self.magic_lv = 1, 1, 1, 1, 1
        self.hp_potions, self.mp_potions, self.ultimate_cd = 0, 0, 0
        self.action_gauge, self.steps_since_encounter, self.active_def = 0, ENCOUNTER_COOLDOWN_STEPS, 0
        self.spells = [{"name": "ヒール", "cost": 5, "type": "heal", "power": 30}]
        
    @property
    def atk(self): return self.base_atk + (self.weapon_lv * 4)
    @property
    def agi(self): return self.base_agi + (self.gear_lv * 3)
    @property
    def defense(self): return self.base_def + self.active_def
    
    def get_stat_bonus(self):
        bonus_mult = self.level // 5
        return {
            "hp": 10 + bonus_mult * 5,
            "mp": 5 + bonus_mult * 2,
            "atk": 2 + bonus_mult,
            "def": 2 + bonus_mult,
            "agi": 2 + bonus_mult
        }
    
    def level_up(self):
        self.level += 1
        self.max_hp += 8
        self.max_mp += 3
        self.hp, self.mp = self.max_hp, self.max_mp
        learned = None
        if self.level == 5: learned = "ファイア"
        elif self.level == 10: learned = "プロテクト"
        elif self.level == 15: learned = "サンダー"
        elif self.level == 20: learned = "フルヒール"
        
        if learned:
            powers = {"ファイア": 45, "プロテクト": 12, "サンダー": 80, "フルヒール": 999}
            types = {"ファイア": "attack", "プロテクト": "defense", "サンダー": "attack", "フルヒール": "heal"}
            costs = {"ファイア": 8, "プロテクト": 10, "サンダー": 15, "フルヒール": 20}
            self.spells.append({"name": learned, "cost": costs[learned], "type": types[learned], "power": powers[learned]})
        return learned

class Enemy:
    def __init__(self, floor, is_boss=False, is_mimic=False):
        self.is_boss = is_boss
        self.is_mimic = is_mimic
        self.phase_2 = False
        scale = 1.5 ** (floor - 1)
        b_hp, b_atk, b_agi = (120, 15, 12+floor*0.5) if is_boss else (30, 8, 12+floor*0.5)
        self.type_str = "normal"
        self.boss_tier = 0
        
        self.drop_scrap = 0
        self.drop_motor = 0
        self.drop_cpu = 0
        
        if is_boss:
            self.boss_tier = min((floor - 1) // 20, 4)
            boss_names = ["重装巨兵 タイタン", "四脚魔獣 アラクネ", "浮遊要塞 ヴァルキリー", "殲滅重戦車 ベヒモス", "中枢コア『クロノス』"]
            self.name = f"階層 {floor} の守護ボス: {boss_names[self.boss_tier]}"
            self.drop_scrap = random.randint(15, 25) + floor
            self.drop_motor = random.randint(3, 8) + floor // 10
            self.drop_cpu = random.randint(1, 3) + floor // 20
        elif is_mimic:
            self.type_str = "mimic"
            self.name = "罠箱 ミミック"
            b_hp *= 2.0; b_atk *= 1.5; b_agi *= 1.2
            self.drop_scrap = random.randint(5, 10) + int(floor * 0.8)
            self.drop_motor = random.randint(1, 3)
            self.drop_cpu = 1 if random.random() < 0.5 else 0
        else:
            r = random.random()
            if r < 0.15:
                self.type_str = "tank"; self.name = "重装型・機械兵"
                b_hp *= 2.5; b_atk *= 0.6; b_agi *= 0.5
            elif r < 0.30:
                self.type_str = "attacker"; self.name = "強襲型・機械兵"
                b_hp *= 0.6; b_atk *= 2.0
            elif r < 0.45:
                self.type_str = "speed"; self.name = "高速型・機械兵"
                b_hp *= 0.4; b_atk *= 0.7; b_agi *= 3.0
            elif r < 0.60:
                self.type_str = "sniper"; self.name = "高精度・機械狙撃兵"
                b_hp *= 0.4; b_atk *= 2.5; b_agi *= 0.8
            elif r < 0.75:
                self.type_str = "jammer"; self.name = "電磁攪乱・妨害兵"
                b_hp *= 1.2; b_atk *= 0.5; b_agi *= 2.5
            elif r < 0.90:
                self.type_str = "berserker"; self.name = "狂化型・暴走機械兵"
                b_hp *= 1.0; b_atk *= 1.8; b_agi *= 1.2
            else:
                self.type_str = "normal"; self.name = "標準型・機械兵"
                
            base_scrap = 3 if random.random() < 0.1 else (2 if random.random() < 0.4 else 1)
            self.drop_scrap = base_scrap + int(floor * 0.3)
            if floor >= 5 and random.random() < 0.3 + (floor * 0.01):
                self.drop_motor = 1 + random.randint(0, floor // 20)
            if floor >= 15 and random.random() < 0.1 + (floor * 0.01):
                self.drop_cpu = 1 + random.randint(0, floor // 30)
            
        self.max_hp = int(b_hp * scale)
        self.hp = self.max_hp
        self.atk = int(b_atk * scale)
        self.agi = int(b_agi)
        self.exp_yield = int((40 if is_mimic else (60 if is_boss else 15)) * scale)
        self.action_gauge = 0

class Game:
    def __init__(self):
        pygame.display.init()
        pygame.font.init()
        
        self.screen = pygame.display.set_mode((850, 560), pygame.SCALED)
        pygame.display.set_caption("クロ奪還 v3.5 - Web Edition")
        self.clock = pygame.time.Clock()
        
        self.last_touch_time = 0
        
        try:
            self.font = pygame.font.Font("font.ttf", 20)
            self.font_s = pygame.font.Font("font.ttf", 16)
            self.font_l = pygame.font.Font("font.ttf", 28)
            self.font_xl = pygame.font.Font("font.ttf", 40)
        except:
            self.font = pygame.font.Font(None, 24)
            self.font_s = pygame.font.Font(None, 20)
            self.font_l = pygame.font.Font(None, 36)
            self.font_xl = pygame.font.Font(None, 48)
        
        self.audio = AudioManager()
        self.textures = create_textures()
        self.player = Player()
        
        self.floor = 1
        self.cursor = 0
        self.guide_cursor = 0
        self.msg = ["クロを救い出すため、危険なダンジョンに潜入した。"]
        self.spike_timer = 0
        self.has_encountered = False
        self.fighting_boss = False
        self.save_timer = 0
        
        self.tutorial_done = False
        self.tutorial_step = 0
        self.tutorial_texts = [
            "君の大切な相棒である『クロ』は、",
            "この地下100階層の最深部に囚われている。",
            "画面の指示に従って移動し、",
            "緑色の『階段』を目指して最下層へ向かえ。",
            "赤く点滅する『トゲ』や『落とし穴』は",
            "踏むと深刻なダメージを受けてしまうぞ。",
            "敵から得た『部品』で自身を強化できる。",
            "それでは健闘を祈る……クロを救い出せ！"
        ]
        
        self.state = "MODE_SELECT"
        self.control_mode = "keyboard"

    def change_state(self, new_state):
        self.state = new_state
        self.cursor = 0

    def execute_save_data(self):
        data = {
            "floor": self.floor, 
            "map_data": self.map_data, 
            "stairs": self.stairs, 
            "tutorial_done": self.tutorial_done,
            "player": {
                "x": self.player.x, "y": self.player.y, "dx": self.player.dx, "dy": self.player.dy,
                "level": self.player.level, "exp": self.player.exp, "hp": self.player.hp, "max_hp": self.player.max_hp,
                "mp": self.player.mp, "max_mp": self.player.max_mp,
                "base_atk": self.player.base_atk, "base_def": self.player.base_def, "base_agi": self.player.base_agi,
                "scrap": self.player.scrap, "motor": self.player.motor, "cpu": self.player.cpu, "stat_pts": self.player.stat_pts,
                "weapon_lv": self.player.weapon_lv, "gear_lv": self.player.gear_lv, 
                "hp_lv": self.player.hp_lv, "mp_lv": self.player.mp_lv, "magic_lv": self.player.magic_lv,
                "hp_potions": self.player.hp_potions, "mp_potions": self.player.mp_potions,
                "ultimate_cd": self.player.ultimate_cd, "spells": self.player.spells
            }
        }
        try:
            with open("save_data.json", "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False)
        except: 
            pass

    def load_game(self):
        try:
            with open("save_data.json", "r", encoding="utf-8") as f:
                data = json.load(f)
            self.floor = data["floor"]
            self.map_data = data["map_data"]
            self.stairs = tuple(data["stairs"])
            self.tutorial_done = data.get("tutorial_done", False)
            
            p = data["player"]
            self.player.x, self.player.y = p["x"], p["y"]
            self.player.dx, self.player.dy = p["dx"], p["dy"]
            self.player.level, self.player.exp = p["level"], p["exp"]
            self.player.hp, self.player.max_hp = p["hp"], p["max_hp"]
            self.player.mp, self.player.max_mp = p["mp"], p["max_mp"]
            self.player.base_atk = p["base_atk"]
            self.player.base_def = p["base_def"]
            self.player.base_agi = p["base_agi"]
            self.player.stat_pts = p["stat_pts"]
            self.player.scrap = p.get("scrap", p.get("parts", 0))
            self.player.motor = p.get("motor", 0)
            self.player.cpu = p.get("cpu", 0)
            
            self.player.weapon_lv = p["weapon_lv"]
            self.player.gear_lv = p["gear_lv"]
            self.player.hp_lv = p["hp_lv"]
            self.player.mp_lv = p["mp_lv"]
            self.player.magic_lv = p["magic_lv"]
            self.player.hp_potions = p["hp_potions"]
            self.player.mp_potions = p["mp_potions"]
            self.player.ultimate_cd = p["ultimate_cd"]
            self.player.spells = p["spells"]
            
            self.add_msg("前回の続きから冒険を再開します。")
            return True
        except: 
            return False

    def reset_save_data(self):
        try: 
            os.remove("save_data.json")
        except: 
            pass
        self.__init__()

    def generate_map(self):
        self.stairs = (MAP_WIDTH-2, MAP_HEIGHT-2)
        for _ in range(20):
            self.map_data = [[0]*MAP_WIDTH for _ in range(MAP_HEIGHT)]
            for y in range(1, MAP_HEIGHT-1):
                for x in range(1, MAP_WIDTH-1):
                    r = random.random()
                    if r < 0.65: self.map_data[y][x] = 1
                    elif r < 0.75: self.map_data[y][x] = 0
                    elif r < 0.90: self.map_data[y][x] = 5
                    else: self.map_data[y][x] = 4
                    
            self.map_data[1][1] = 1
            self.map_data[self.stairs[1]][self.stairs[0]] = 2
            
            v = [[False]*MAP_WIDTH for _ in range(MAP_HEIGHT)]
            q = [(1,1)]
            v[1][1] = True
            r_ok = False
            
            while q:
                cx, cy = q.pop(0)
                if (cx, cy) == self.stairs: 
                    r_ok = True
                    break
                for dx, dy in [(0,1),(0,-1),(1,0),(-1,0)]:
                    nx, ny = cx+dx, cy+dy
                    if 0 <= nx < MAP_WIDTH and 0 <= ny < MAP_HEIGHT and not v[ny][nx] and self.map_data[ny][nx] != 0:
                        v[ny][nx] = True
                        q.append((nx,ny))
            if r_ok: 
                break
                
        if not r_ok:
            for x in range(1, MAP_WIDTH-1): self.map_data[1][x] = 1
            for y in range(1, MAP_HEIGHT-1): self.map_data[y][self.stairs[0]] = 1
            self.map_data[self.stairs[1]][self.stairs[0]] = 2
                
        cells = []
        for y in range(1, MAP_HEIGHT-1):
            for x in range(1, MAP_WIDTH-1):
                if self.map_data[y][x] == 1 and (x,y) != (1,1) and (x,y) != self.stairs:
                    cells.append((x,y))
                    
        num_chests = 1
        if random.random() < 0.20:
            num_chests = 2
            if random.random() < 0.20:
                num_chests = 3
                
        for _ in range(num_chests):
            if cells:
                cx, cy = random.choice(cells)
                self.map_data[cy][cx] = 3
                cells.remove((cx, cy))
                
        self.has_encountered = False

    def get_virtual_key(self, pos):
        x, y = pos
        if 50 <= x <= 150 and 360 <= y <= 450: return pygame.K_UP
        if 50 <= x <= 150 and 490 <= y <= 560: return pygame.K_DOWN
        if 0 <= x <= 80 and 420 <= y <= 520: return pygame.K_LEFT
        if 120 <= x <= 220 and 420 <= y <= 520: return pygame.K_RIGHT
        
        if (x - 750)**2 + (y - 480)**2 <= 65**2: return pygame.K_RETURN
        if (x - 630)**2 + (y - 480)**2 <= 65**2: return pygame.K_ESCAPE
        return None

    def draw_virtual_pad(self):
        if self.control_mode != "touch" or self.state == "MODE_SELECT": 
            return
        
        pad_surf = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        color = (255, 255, 255, 60)
        pygame.draw.rect(pad_surf, color, (70, 380, 60, 60), border_radius=10)
        pygame.draw.rect(pad_surf, color, (70, 500, 60, 60), border_radius=10)
        pygame.draw.rect(pad_surf, color, (10, 440, 60, 60), border_radius=10)
        pygame.draw.rect(pad_surf, color, (130, 440, 60, 60), border_radius=10)
        
        pygame.draw.polygon(pad_surf, (255,255,255,150), [(100, 390), (85, 420), (115, 420)])
        pygame.draw.polygon(pad_surf, (255,255,255,150), [(100, 550), (85, 520), (115, 520)])
        pygame.draw.polygon(pad_surf, (255,255,255,150), [(20, 470), (50, 455), (50, 485)])
        pygame.draw.polygon(pad_surf, (255,255,255,150), [(180, 470), (150, 455), (150, 485)])

        pygame.draw.circle(pad_surf, color, (750, 480), 45)
        pygame.draw.circle(pad_surf, color, (630, 480), 40)
        
        pygame.draw.circle(pad_surf, (255,255,255, 150), (750, 480), 20, 3)
        pygame.draw.line(pad_surf, (255,255,255, 150), (615, 465), (645, 495), 4)
        pygame.draw.line(pad_surf, (255,255,255, 150), (615, 495), (645, 465), 4)

        self.screen.blit(pad_surf, (0,0))

    def add_msg(self, m):
        self.msg.append(m)
        if len(self.msg) > 6: 
            self.msg.pop(0)

    def draw_ui(self):
        pygame.draw.rect(self.screen, DK_GRAY, (0, MAP_PIXEL_H, MAP_PIXEL_W, LOG_H))
        pygame.draw.rect(self.screen, GRAY, (0, MAP_PIXEL_H, MAP_PIXEL_W, LOG_H), 3)
        for i, m in enumerate(self.msg): 
            self.screen.blit(self.font.render(m, True, WHITE), (15, MAP_PIXEL_H + 15 + i*22))
            
        pygame.draw.rect(self.screen, BLACK, (MAP_PIXEL_W, 0, SIDE_W, HEIGHT))
        pygame.draw.rect(self.screen, GRAY, (MAP_PIXEL_W, 0, SIDE_W, HEIGHT), 3)
        
        px = MAP_PIXEL_W + 15
        p = self.player
        
        self.screen.blit(self.font_l.render(f"地下 {self.floor} 階", True, YELLOW), (px, 20))
        
        rec_lv = int(self.floor * 1.5) + 3
        c_lv = GREEN if p.level >= rec_lv else RED
        self.screen.blit(self.font.render(f"レベル: {p.level}", True, WHITE), (px, 60))
        self.screen.blit(self.font_s.render(f"(推奨: {rec_lv})", True, c_lv), (px+100, 64))
        
        curr_lvl_exp = 10 * ((p.level-1)**2) + 5 if p.level > 1 else 0
        next_lvl_exp = 10 * (p.level**2) + 5
        exp_req = next_lvl_exp - curr_lvl_exp
        exp_current = p.exp - curr_lvl_exp
        exp_ratio = max(0.0, min(1.0, exp_current / exp_req))
        
        self.screen.blit(self.font_s.render(f"EXP: {p.exp} / {next_lvl_exp}", True, WHITE), (px, 90))
        pygame.draw.rect(self.screen, GRAY, (px, 110, SIDE_W-30, 10))
        pygame.draw.rect(self.screen, GREEN, (px, 110, (SIDE_W-30)*exp_ratio, 10))
        
        self.screen.blit(self.font_s.render(f"HP: {p.hp} / {p.max_hp}", True, WHITE), (px, 130))
        pygame.draw.rect(self.screen, GRAY, (px, 150, SIDE_W-30, 10))
        if p.max_hp > 0: 
            pygame.draw.rect(self.screen, RED, (px, 150, (SIDE_W-30)*max(0,p.hp)/p.max_hp, 10))
            
        self.screen.blit(self.font_s.render(f"MP: {p.mp} / {p.max_mp}", True, WHITE), (px, 170))
        pygame.draw.rect(self.screen, GRAY, (px, 190, SIDE_W-30, 10))
        if p.max_mp > 0: 
            pygame.draw.rect(self.screen, BLUE, (px, 190, (SIDE_W-30)*max(0,p.mp)/p.max_mp, 10))
            
        self.screen.blit(self.font_s.render("アクションゲージ", True, YELLOW), (px, 210))
        pygame.draw.rect(self.screen, GRAY, (px, 230, SIDE_W-30, 5))
        pygame.draw.rect(self.screen, YELLOW, (px, 230, (SIDE_W-30)*min(1.0, p.action_gauge/1000), 5))
        
        self.screen.blit(self.font.render(f"攻撃力: {p.atk}", True, WHITE), (px, 250))
        self.screen.blit(self.font.render(f"防御力: {p.defense}", True, WHITE), (px, 280))
        self.screen.blit(self.font.render(f"素早さ: {p.agi}", True, WHITE), (px, 310))
        
        self.screen.blit(self.font_s.render(f"スクラップ: {p.scrap} 個", True, GREEN), (px, 350))
        self.screen.blit(self.font_s.render(f"モーター:   {p.motor} 個", True, GREEN), (px, 375))
        self.screen.blit(self.font_s.render(f"演算チップ: {p.cpu} 個", True, GREEN), (px, 400))
        self.screen.blit(self.font_s.render(f"強化ポイント: {p.stat_pts}", True, YELLOW), (px, 430))

    async def run(self):
        while True:
            try:
                if self.state == "SAVE_IN_PROGRESS":
                    self.save_timer -= 1
                    if self.save_timer <= 0:
                        self.execute_save_data()
                        self.state = "SAVE_COMPLETE"
                        
                self.screen.fill(BLACK)
                
                for e in pygame.event.get():
                    if e.type == pygame.QUIT: 
                        self.execute_save_data()
                        pygame.quit()
                        sys.exit()
                        
                    key = None
                    
                    if e.type == pygame.KEYDOWN:
                        self.audio.start_bgm()
                        if self.state == "MODE_SELECT" or self.control_mode == "keyboard":
                            key = e.key
                            
                    elif e.type == pygame.MOUSEBUTTONDOWN:
                        current_time = pygame.time.get_ticks()
                        if current_time - getattr(self, 'last_touch_time', 0) < 100:
                            continue
                        self.last_touch_time = current_time

                        self.audio.start_bgm()
                        touch_x, touch_y = e.pos
                        
                        if self.state == "MODE_SELECT":
                            if 160 <= touch_y <= 225:
                                self.cursor = 0
                                key = pygame.K_RETURN
                            elif 226 <= touch_y <= 290:
                                self.cursor = 1
                                key = pygame.K_RETURN
                        elif self.control_mode == "touch":
                            key = self.get_virtual_key((touch_x, touch_y))

                    if key is not None:
                        if self.state == "SAVE_IN_PROGRESS":
                            continue
                        elif self.state == "SAVE_COMPLETE":
                            if key in [pygame.K_ESCAPE, pygame.K_e]:
                                self.audio.play("decide")
                                self.change_state("MENU_MAIN")
                            continue

                        if self.state == "MODE_SELECT":
                            if key in [pygame.K_UP, pygame.K_w]: 
                                self.cursor = 0
                            elif key in [pygame.K_DOWN, pygame.K_s]: 
                                self.cursor = 1
                            elif key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                                self.audio.play("decide")
                                self.control_mode = "touch" if self.cursor == 0 else "keyboard"
                                if not self.load_game():
                                    self.generate_map()
                                    self.change_state("TUTORIAL")
                                else:
                                    self.change_state("MAP")
                                    
                        elif self.state == "TUTORIAL":
                            if key in [pygame.K_ESCAPE, pygame.K_e]: 
                                self.audio.play("decide")
                                self.tutorial_done = True
                                self.change_state("MAP")
                            elif key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                                self.audio.play("decide")
                                self.tutorial_step += 1
                                if self.tutorial_step >= len(self.tutorial_texts): 
                                    self.tutorial_done = True
                                    self.change_state("MAP")

                        elif self.state == "MENU_INIT":
                            if key in [pygame.K_ESCAPE, pygame.K_e]: 
                                self.change_state("MENU_MAIN")
                            elif key in [pygame.K_LEFT, pygame.K_RIGHT, pygame.K_a, pygame.K_d]: 
                                self.audio.play("cursor")
                                self.cursor = 1 - self.cursor
                            elif key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                                self.audio.play("decide")
                                if self.cursor == 0: 
                                    self.reset_save_data()
                                else: 
                                    self.change_state("MENU_MAIN")

                        elif key in [pygame.K_ESCAPE, pygame.K_e]:
                            if self.state == "MAP": 
                                self.change_state("MENU_MAIN")
                            elif self.state == "MENU_MAIN": 
                                self.change_state("MAP")
                            elif self.state in ["MENU_STATUS", "MENU_CRAFT", "MENU_LEVELUP", "MENU_MAGIC", "MENU_GUIDE", "MENU_ITEM"]: 
                                self.change_state("MENU_MAIN")
                            elif self.state == "BATTLE_LEVELUP": 
                                self.change_state("MAP")
                            elif self.state in ["BATTLE_MAGIC", "BATTLE_ITEM"]: 
                                self.change_state("BATTLE_MAIN")

                        elif self.state == "GAMEOVER" and key == pygame.K_c:
                            self.audio.play("decide")
                            self.player.hp = 1
                            self.player.action_gauge = 0
                            self.player.active_def = 0
                            self.generate_map()
                            self.player.x, self.player.y = 1, 1
                            self.change_state("MAP")
                            self.add_msg("死の淵から蘇った…！(HPが1になりました)")

                        elif self.state == "MAP":
                            nx, ny = self.player.x, self.player.y
                            moved = False
                            if key in [pygame.K_UP, pygame.K_w]: ny -= 1; self.player.dx, self.player.dy = 0, -1; moved = True
                            elif key in [pygame.K_DOWN, pygame.K_s]: ny += 1; self.player.dx, self.player.dy = 0, 1; moved = True
                            elif key in [pygame.K_LEFT, pygame.K_a]: nx -= 1; self.player.dx, self.player.dy = -1, 0; moved = True
                            elif key in [pygame.K_RIGHT, pygame.K_d]: nx += 1; self.player.dx, self.player.dy = 1, 0; moved = True
                            elif key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                                tx, ty = self.player.x + self.player.dx, self.player.y + self.player.dy
                                if 0 <= tx < MAP_WIDTH and 0 <= ty < MAP_HEIGHT and self.map_data[ty][tx] == 3:
                                    self.audio.play("decide")
                                    self.map_data[ty][tx] = 1
                                    if random.random() < 0.15: 
                                        self.enemy = Enemy(self.floor, False, True)
                                        self.change_state("BATTLE_MAIN")
                                        self.fighting_boss = False
                                        self.add_msg("宝箱はミミックだった！戦闘開始！")
                                    else:
                                        self.add_msg("宝箱を開けた！")
                                        s = random.randint(1, 3) + int(self.floor * 0.5)
                                        m = random.randint(1, 2) if self.floor >= 5 else 0
                                        c = random.randint(1, 1) if self.floor >= 15 else 0
                                        self.player.scrap += s
                                        self.player.motor += m
                                        self.player.cpu += c
                                        self.add_msg(f"スクラップ{s}個" + (f"、モーター{m}個" if m>0 else "") + (f"、チップ{c}個" if c>0 else "") + "を入手！")
                                        if random.random() < 0.25: 
                                            self.player.hp_potions += 1
                                            self.add_msg("HP回復薬を手に入れた！")
                                        self.player.exp += int(10 * self.floor)
                                        leveled = False
                                        while self.player.exp >= 10*(self.player.level**2)+5:
                                            self.audio.play("levelup")
                                            self.player.level_up()
                                            self.player.stat_pts += 1
                                            self.add_msg("レベルアップ！ 強化ポイントを獲得！")
                                            leveled = True
                                        if leveled: 
                                            self.change_state("BATTLE_LEVELUP")
                                    
                            if moved and 0 <= nx < MAP_WIDTH and 0 <= ny < MAP_HEIGHT and self.map_data[ny][nx] not in [0, 3]:
                                if self.map_data[ny][nx] == 4:
                                    self.audio.play("damage")
                                    self.map_data[ny][nx] = 1
                                    self.player.x, self.player.y = nx, ny
                                    self.player.hp -= 10
                                    self.add_msg("落とし穴だ！ 10 のダメージを受けた！")
                                    if self.player.hp <= 0: 
                                        self.change_state("GAMEOVER")
                                elif (nx, ny) == self.stairs:
                                    self.player.x, self.player.y = nx, ny
                                    if not self.has_encountered: 
                                        self.has_encountered = True
                                        self.enemy = Enemy(self.floor, False)
                                        self.change_state("BATTLE_MAIN")
                                        self.fighting_boss = False
                                        self.add_msg("階段に敵が潜んでいた！")
                                    else: 
                                        self.enemy = Enemy(self.floor, True)
                                        self.change_state("BATTLE_MAIN")
                                        self.fighting_boss = True
                                        self.add_msg(f"ボス 『{self.enemy.name}』 が出現！")
                                else:
                                    self.player.x, self.player.y = nx, ny
                                    self.player.steps_since_encounter += 1
                                    if self.player.steps_since_encounter >= ENCOUNTER_COOLDOWN_STEPS and random.random() < ENCOUNTER_RATE and self.map_data[ny][nx] not in [4,5]:
                                        self.has_encountered = True
                                        self.enemy = Enemy(self.floor, False)
                                        self.change_state("BATTLE_MAIN")
                                        self.fighting_boss = False
                                        self.add_msg("敵が出現した！戦闘開始！")
                                        self.player.steps_since_encounter = 0

                        elif self.state == "MENU_MAIN":
                            opts = ["アイテムを使う", "ステータス強化", "ステータス確認", "クラフト (装備強化)", "魔法 (フィールド)", "冒険者図鑑", "ゲームをセーブする", "セーブデータの初期化"]
                            if key in [pygame.K_UP, pygame.K_DOWN, pygame.K_w, pygame.K_s]: 
                                self.audio.play("cursor")
                                self.cursor = (self.cursor + (1 if key in [pygame.K_DOWN, pygame.K_s] else -1)) % len(opts)
                            elif key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                                self.audio.play("decide")
                                if self.cursor == 7: 
                                    self.change_state("MENU_INIT")
                                    self.cursor = 1
                                elif self.cursor == 6:
                                    self.state = "SAVE_IN_PROGRESS"
                                    self.save_timer = 40
                                else: 
                                    self.change_state(["MENU_ITEM", "MENU_LEVELUP", "MENU_STATUS", "MENU_CRAFT", "MENU_MAGIC", "MENU_GUIDE"][self.cursor])

                        elif self.state == "MENU_GUIDE":
                            opts = ["ストーリー概要", "操作方法と宝箱", "地形とアイテム", "敵の特性とボス", "クラフトと部品", "魔法と極技"]
                            if key in [pygame.K_UP, pygame.K_DOWN, pygame.K_w, pygame.K_s]: 
                                self.audio.play("cursor")
                                self.guide_cursor = (self.guide_cursor + (1 if key in [pygame.K_DOWN, pygame.K_s] else -1)) % len(opts)

                        elif self.state in ["MENU_ITEM", "BATTLE_ITEM"]:
                            opts = [f"HP回復薬 (残り: {self.player.hp_potions} 個)", f"MP回復薬 (残り: {self.player.mp_potions} 個)"]
                            if key in [pygame.K_UP, pygame.K_DOWN, pygame.K_w, pygame.K_s]: 
                                self.audio.play("cursor")
                                self.cursor = (self.cursor + (1 if key in [pygame.K_DOWN, pygame.K_s] else -1)) % len(opts)
                            elif key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                                if self.cursor == 0:
                                    if self.player.hp_potions > 0: 
                                        self.player.hp_potions -= 1
                                        self.player.hp = min(self.player.max_hp, self.player.hp + 50)
                                        self.audio.play("magic")
                                        self.add_msg("HP回復薬を使用した！")
                                        self.player.action_gauge = 0
                                        if self.state == "BATTLE_ITEM": 
                                            self.change_state("BATTLE_MAIN")
                                    else: 
                                        self.add_msg("回復薬を持っていない！")
                                elif self.cursor == 1:
                                    if self.player.mp_potions > 0: 
                                        self.player.mp_potions -= 1
                                        self.player.mp = min(self.player.max_mp, self.player.mp + 30)
                                        self.audio.play("magic")
                                        self.add_msg("MP回復薬を使用した！")
                                        self.player.action_gauge = 0
                                        if self.state == "BATTLE_ITEM": 
                                            self.change_state("BATTLE_MAIN")
                                    else: 
                                        self.add_msg("回復薬を持っていない！")

                        elif self.state == "MENU_CRAFT":
                            costs = []
                            for lv in [self.player.weapon_lv, self.player.gear_lv, self.player.hp_lv, self.player.mp_lv, self.player.magic_lv]:
                                cost_s = lv * 5
                                cost_m = max(0, (lv - 2) * 2)
                                cost_c = max(0, (lv - 5) * 1)
                                costs.append((cost_s, cost_m, cost_c))
                                
                            if key in [pygame.K_UP, pygame.K_DOWN, pygame.K_w, pygame.K_s]: 
                                self.audio.play("cursor")
                                self.cursor = (self.cursor + (1 if key in [pygame.K_DOWN, pygame.K_s] else -1)) % 5
                            elif key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                                self.audio.play("decide")
                                cost_s, cost_m, cost_c = costs[self.cursor]
                                if self.player.scrap >= cost_s and self.player.motor >= cost_m and self.player.cpu >= cost_c:
                                    self.player.scrap -= cost_s
                                    self.player.motor -= cost_m
                                    self.player.cpu -= cost_c
                                    if self.cursor == 0: 
                                        self.player.weapon_lv += 1
                                        self.add_msg("武器を強化した！")
                                    elif self.cursor == 1: 
                                        self.player.gear_lv += 1
                                        self.add_msg("防具ギアを調整した！")
                                    elif self.cursor == 2: 
                                        self.player.hp_lv += 1
                                        self.player.max_hp += 20
                                        self.player.hp += 20
                                        self.add_msg("最大体力を増大させた！")
                                    elif self.cursor == 3: 
                                        self.player.mp_lv += 1
                                        self.player.max_mp += 10
                                        self.player.mp += 10
                                        self.add_msg("最大魔力を増大させた！")
                                    elif self.cursor == 4: 
                                        self.player.magic_lv += 1
                                        self.add_msg("魔法の威力をアップした！")
                                else: 
                                    self.add_msg("強化に必要な部品が足りない！")

                        elif self.state in ["MENU_LEVELUP", "BATTLE_LEVELUP"]:
                            if key in [pygame.K_UP, pygame.K_DOWN, pygame.K_w, pygame.K_s]: 
                                self.audio.play("cursor")
                                self.cursor = (self.cursor + (1 if key in [pygame.K_DOWN, pygame.K_s] else -1)) % 5
                            elif key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                                self.audio.play("decide")
                                p = self.player
                                if p.stat_pts > 0:
                                    bonus = p.get_stat_bonus()
                                    if self.cursor == 0: p.max_hp += bonus['hp']; p.hp += bonus['hp']
                                    elif self.cursor == 1: p.max_mp += bonus['mp']; p.mp += bonus['mp']
                                    elif self.cursor == 2: p.base_atk += bonus['atk']
                                    elif self.cursor == 3: p.base_def += bonus['def']
                                    elif self.cursor == 4: p.base_agi += bonus['agi']
                                    p.stat_pts -= 1
                                    self.add_msg("ステータスを直接強化した！")
                                else: 
                                    self.add_msg("強化ポイントが足りない！")

                        elif self.state == "MENU_MAGIC":
                            u = [s for s in self.player.spells if s["type"] in ["heal", "defense"]]
                            if key in [pygame.K_UP, pygame.K_DOWN, pygame.K_w, pygame.K_s]: 
                                self.audio.play("cursor")
                                if u: 
                                    self.cursor = (self.cursor + (1 if key in [pygame.K_DOWN, pygame.K_s] else -1)) % len(u)
                            elif key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                                if not u: 
                                    self.add_msg("フィールドで使える魔法がない")
                                else:
                                    s = u[self.cursor]
                                    if self.player.mp >= s["cost"]:
                                        self.audio.play("magic")
                                        self.player.mp -= s["cost"]
                                        pwr = int(s["power"] * (1 + self.player.level * 0.05)) + (self.player.magic_lv - 1) * 10
                                        if s["type"] == "heal": 
                                            self.player.hp = min(self.player.max_hp, self.player.hp + pwr)
                                            self.add_msg(f"魔法でHPが {pwr} 回復した！")
                                        elif s["type"] == "attack": 
                                            d = pwr + random.randint(-5, 5)
                                            self.enemy.hp -= d
                                            self.add_msg(f"魔法で {d} のダメージを与えた！")
                                        elif s["type"] == "defense": 
                                            self.player.active_def += pwr
                                            self.add_msg("魔法で防御力がアップした！")
                                        self.player.action_gauge = 0
                                        self.change_state("BATTLE_MAIN")
                                    else: 
                                        self.add_msg("MPが足りない！")

                        elif self.state == "BATTLE_MAIN":
                            if self.player.action_gauge >= 1000:
                                req = self.player.max_mp * 9 // 10
                                if self.fighting_boss:
                                    opts = ["武器で攻撃する", "魔法を使用する", "アイテムを使う", f"極技 (消費MP: {req})"]
                                else:
                                    opts = ["武器で攻撃する", "魔法を使用する", "アイテムを使う", "戦闘から逃走する"]
                                
                                if key in [pygame.K_UP, pygame.K_DOWN, pygame.K_w, pygame.K_s]: 
                                    self.audio.play("cursor")
                                    self.cursor = (self.cursor + (1 if key in [pygame.K_DOWN, pygame.K_s] else -1)) % len(opts)
                                elif key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                                    if self.cursor == 0:
                                        self.audio.play("attack")
                                        d = max(1, self.player.atk - self.enemy.atk//4 + random.randint(-3,3))
                                        if random.random() < 0.15: 
                                            d = int(d * PHI)
                                            self.add_msg("黄金比の力が宿った！クリティカルヒット！")
                                        self.enemy.hp -= d
                                        self.add_msg(f"{d} のダメージを与えた！")
                                        self.player.action_gauge = 0
                                        self.cursor = 0
                                    elif self.cursor == 1: 
                                        self.audio.play("decide")
                                        self.change_state("BATTLE_MAGIC")
                                    elif self.cursor == 2: 
                                        self.audio.play("decide")
                                        self.change_state("BATTLE_ITEM")
                                    elif self.cursor == 3:
                                        if self.fighting_boss:
                                            if self.player.ultimate_cd > 0: 
                                                self.add_msg("極技はまだ使用できない！")
                                            elif self.player.mp >= req: 
                                                self.player.mp -= req
                                                self.player.ultimate_cd = 5
                                                self.audio.play("magic")
                                                self.enemy.hp = self.enemy.hp // 3
                                                self.add_msg("極技が炸裂！ボスのHPを大幅に削った！")
                                                self.player.action_gauge = 0
                                                self.cursor = 0
                                            else: 
                                                self.add_msg("MPが足りない！")
                                        else:
                                            if random.random() < 0.4: 
                                                self.add_msg("逃走に成功した！")
                                                self.change_state("MAP")
                                            else: 
                                                self.add_msg("逃走に失敗した！")
                                                self.player.action_gauge = 0
                                            
                                    if self.state != "MAP" and self.enemy.is_boss and self.enemy.hp <= self.enemy.max_hp // 2 and not self.enemy.phase_2: 
                                        self.enemy.phase_2 = True
                                        self.add_msg("ボスが暴走モードに突入した！")
                                        self.enemy.atk = int(self.enemy.atk * 1.5)
                                        self.enemy.agi = int(self.enemy.agi * 1.5)

                        elif self.state == "BATTLE_MAGIC":
                            if key in [pygame.K_UP, pygame.K_DOWN, pygame.K_w, pygame.K_s]: 
                                self.audio.play("cursor")
                                self.cursor = (self.cursor + (1 if key in [pygame.K_DOWN, pygame.K_s] else -1)) % len(self.player.spells)
                            elif key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                                s = self.player.spells[self.cursor]
                                if self.player.mp >= s["cost"]:
                                    self.audio.play("magic")
                                    self.player.mp -= s["cost"]
                                    pwr = int(s["power"] * (1 + self.player.level * 0.05)) + (self.player.magic_lv - 1) * 10
                                    if s["type"] == "heal": 
                                        self.player.hp = min(self.player.max_hp, self.player.hp + pwr)
                                        self.add_msg(f"魔法でHPが {pwr} 回復した！")
                                    elif s["type"] == "attack": 
                                        d = pwr + random.randint(-5, 5)
                                        self.enemy.hp -= d
                                        self.add_msg(f"魔法で {d} のダメージを与えた！")
                                    elif s["type"] == "defense": 
                                        self.player.active_def += pwr
                                        self.add_msg("魔法で防御力がアップした！")
                                    self.player.action_gauge = 0
                                    self.change_state("BATTLE_MAIN")
                                else: 
                                    self.add_msg("MPが足りない！")

                        elif self.state == "CRAFT_SAFE_AREA":
                            if key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]: 
                                self.audio.play("decide")
                                self.generate_map()
                                self.player.x, self.player.y = 1, 1
                                self.change_state("MAP")

                if self.state == "MAP" and self.map_data[self.player.y][self.player.x] == 5:
                    self.spike_timer += 1
                    if self.spike_timer >= 60: 
                        self.audio.play("damage")
                        self.player.hp -= 3
                        self.spike_timer = 0
                        self.add_msg("トゲの罠！ 3 のダメージを受けた！")
                        if self.player.hp <= 0: 
                            self.change_state("GAMEOVER")
                elif self.state == "MAP": 
                    self.spike_timer = 0

                if self.state in ["BATTLE_MAIN", "BATTLE_MAGIC", "BATTLE_ITEM"]:
                    if self.enemy.action_gauge >= 1000 and self.player.action_gauge < 1000: 
                        self.audio.play("damage")
                        d = max(1, self.enemy.atk - self.player.defense // 2)
                        self.player.hp -= d
                        self.add_msg(f"敵の攻撃！ {d} のダメージを受けた！")
                        self.enemy.action_gauge = 0
                    elif self.player.action_gauge < 1000: 
                        self.player.action_gauge += self.player.agi
                        self.enemy.action_gauge += self.enemy.agi
                        
                    if self.enemy.hp <= 0:
                        self.player.exp += self.enemy.exp_yield
                        self.player.scrap += self.enemy.drop_scrap
                        self.player.motor += self.enemy.drop_motor
                        self.player.cpu += self.enemy.drop_cpu
                        self.player.active_def = 0
                        self.add_msg("敵を打ち倒した！")
                        
                        dr_msg = f"スクラップ{self.enemy.drop_scrap}個"
                        if self.enemy.drop_motor > 0: dr_msg += f"、モーター{self.enemy.drop_motor}個"
                        if self.enemy.drop_cpu > 0: dr_msg += f"、チップ{self.enemy.drop_cpu}個"
                        self.add_msg(dr_msg + " を入手した！")
                        
                        if random.random() < 0.2: 
                            self.player.hp_potions += 1
                            self.add_msg("敵がHP回復薬を落とした！")
                            
                        lv = False
                        while self.player.exp >= 10 * (self.player.level**2) + 5: 
                            self.audio.play("levelup")
                            self.player.level_up()
                            self.player.stat_pts += 1
                            self.add_msg("レベルアップ！ 強化ポイントを獲得！")
                            lv = True
                            
                        if self.fighting_boss:
                            self.floor += 1
                            if self.player.ultimate_cd > 0: 
                                self.player.ultimate_cd -= 1
                            if self.floor % 10 == 0: 
                                self.change_state("CRAFT_SAFE_AREA")
                                self.player.hp, self.player.mp = self.player.max_hp, self.player.max_mp
                            else: 
                                self.generate_map()
                                self.player.x, self.player.y = 1, 1
                                self.change_state("BATTLE_LEVELUP" if lv else "MAP")
                        else: 
                            self.change_state("BATTLE_LEVELUP" if lv else "MAP")
                            
                    elif self.player.hp <= 0: 
                        self.change_state("GAMEOVER")

                if self.state in ["MAP", "MENU_MAIN", "MENU_STATUS", "MENU_CRAFT", "MENU_LEVELUP", "MENU_MAGIC", "MENU_GUIDE", "BATTLE_LEVELUP", "MENU_ITEM", "MENU_INIT", "TUTORIAL", "SAVE_IN_PROGRESS", "SAVE_COMPLETE"]:
                    for y in range(MAP_HEIGHT):
                        for x in range(MAP_WIDTH): 
                            self.screen.blit(self.textures[['wall', 'floor', 'stairs', 'chest', 'hole', 'spike'][self.map_data[y][x]]], (x*GRID_SIZE, y*GRID_SIZE))
                    px, py = self.player.x * GRID_SIZE, self.player.y * GRID_SIZE
                    self.screen.blit(self.textures['player'], (px, py))
                    pygame.draw.circle(self.screen, RED, (px+20+self.player.dx*15, py+20+self.player.dy*15), 4)

                if self.state == "MODE_SELECT":
                    pygame.draw.rect(self.screen, DK_GRAY, (0, 0, MAP_PIXEL_W, MAP_PIXEL_H))
                    r = pygame.Rect(MAP_PIXEL_W//2 - 220, MAP_PIXEL_H//2 - 100, 440, 200)
                    pygame.draw.rect(self.screen, BLACK, r)
                    pygame.draw.rect(self.screen, WHITE, r, 3)
                    self.screen.blit(self.font_l.render("操作方法を選択してください", True, WHITE), (r.x + 40, r.y + 20))
                    
                    opts = ["タッチ操作 (モバイル対応)", "キーボード操作 (パソコン)"]
                    for i, o in enumerate(opts):
                        c = YELLOW if i == self.cursor else WHITE
                        pygame.draw.rect(self.screen, DK_GRAY if i == self.cursor else BLACK, (r.x + 20, r.y + 80 + i * 50, 400, 40))
                        self.screen.blit(self.font.render(f"{'▶' if i == self.cursor else ' '} {o}", True, c), (r.x + 60, r.y + 88 + i * 50))
                        
                elif self.state == "TUTORIAL":
                    overlay = pygame.Surface((WIDTH, HEIGHT))
                    overlay.set_alpha(180)
                    overlay.fill(BLACK)
                    self.screen.blit(overlay, (0,0))
                    r = pygame.Rect(MAP_PIXEL_W//2 - 240, MAP_PIXEL_H//2 - 100, 480, 200)
                    pygame.draw.rect(self.screen, DK_GRAY, r)
                    pygame.draw.rect(self.screen, YELLOW, r, 3)
                    self.screen.blit(self.font_l.render("チュートリアル", True, YELLOW), (r.x + 30, r.y + 30))
                    self.screen.blit(self.font.render(self.tutorial_texts[self.tutorial_step], True, WHITE), (r.x + 30, r.y + 80))
                    self.screen.blit(self.font_s.render("Enter/Space/Aボタン: 次へ進む    E/Esc/Bボタン: スキップ", True, GRAY), (r.right - 350, r.bottom - 25))
                    
                elif self.state == "MENU_MAIN":
                    r = pygame.Rect(MAP_PIXEL_W//2 - 180, MAP_PIXEL_H//2 - 160, 360, 320)
                    pygame.draw.rect(self.screen, BLACK, r)
                    pygame.draw.rect(self.screen, WHITE, r, 3)
                    self.screen.blit(self.font_l.render("メインメニュー", True, WHITE), (MAP_PIXEL_W//2 - 80, r.y + 15))
                    
                    opts = ["アイテムを使う", "ステータス強化", "ステータス確認", "クラフト (装備強化)", "魔法 (フィールド)", "冒険者図鑑", "ゲームをセーブする", "セーブデータの初期化"]
                    for i, o in enumerate(opts): 
                        self.screen.blit(self.font.render(f"{'▶' if i==self.cursor else ' '} {o}", True, RED if i == 7 and i == self.cursor else (YELLOW if i == self.cursor else WHITE)), (MAP_PIXEL_W//2 - 130, MAP_PIXEL_H//2 - 100 + i*30))
                        
                elif self.state == "MENU_INIT":
                    overlay = pygame.Surface((WIDTH, HEIGHT))
                    overlay.set_alpha(180)
                    overlay.fill(BLACK)
                    self.screen.blit(overlay, (0,0))
                    r = pygame.Rect(MAP_PIXEL_W//2 - 200, MAP_PIXEL_H//2 - 80, 400, 160)
                    pygame.draw.rect(self.screen, DK_GRAY, r)
                    pygame.draw.rect(self.screen, RED, r, 3)
                    self.screen.blit(self.font_l.render("セーブデータを初期化しますか？", True, RED), (r.x + 20, r.y + 30))
                    self.screen.blit(self.font.render("はい", True, YELLOW if self.cursor==0 else WHITE), (r.x + 100, r.y + 100))
                    self.screen.blit(self.font.render("いいえ", True, YELLOW if self.cursor==1 else WHITE), (r.x + 240, r.y + 100))
                    
                elif self.state == "MENU_GUIDE":
                    r = pygame.Rect(20, 20, MAP_PIXEL_W - 40, MAP_PIXEL_H - 40)
                    pygame.draw.rect(self.screen, DK_GRAY, r)
                    pygame.draw.rect(self.screen, CYAN, r, 3)
                    self.screen.blit(self.font_l.render("冒険者図鑑", True, WHITE), (r.x+30, r.y+20))
                    
                    opts = ["ストーリー概要", "操作方法と宝箱", "地形とアイテム", "敵の特性とボス", "クラフトと部品", "魔法と極技"]
                    for i, o in enumerate(opts): 
                        self.screen.blit(self.font_s.render(f"{'▶' if i==self.guide_cursor else ' '} {o}", True, YELLOW if i == self.guide_cursor else WHITE), (r.x+20, r.y+70+i*40))
                        
                    texts = [
                        ["相棒である『クロ』が、悪の機械軍団に", "よって地下100階層のダンジョンの最深部", "に囚われてしまった。", "立ち塞がる強力な機械兵たちを打ち倒し、", "大切な相棒を必ず救い出そう！"],
                        ["【移動】 矢印キー または 十字ボタン", "【決定】 Enter または Aボタン", "【メニュー/戻る】 Esc または Bボタン", " ", "マップ上の『宝箱』を調べると部品や", "回復薬を得られるが、まれに強力な罠箱", "『ミミック』が潜んでいることがあるぞ。"],
                        ["【緑の床】 次の階層へ進むための階段。", "　※敵が待ち伏せしていることがある。", "【赤のトゲ】 踏んでいる間ダメージ！", "【黒い穴】 落ちると10の固定ダメージ！", " ", "【HP/MP回復薬】", "メニューや戦闘中に使用でき、即座に", "HPを50、MPを30回復することができる。"],
                        ["【重装型】 HPが高いが、素早さは低い。", "【強襲型】 攻撃力が非常に高い。", "【高速型】 連続で行動されやすい。", "【狙撃型】 攻撃力が高く命中精度も高い。", "【妨害型】 予測不能な動きで攪乱する。", "【暴走型】 ステータスが全体的に高い。", "【階層ボス】 10階層ごとに登場する。", "　※HPが半分を切ると『暴走モード』へ！"],
                        ["敵を倒して得た『部品』を消費して、", "武器や防具のレベルを上げることができる。", "最初は『スクラップ』だけで強化できるが、", "レベルが上がると『モーター』や", "高度な『演算チップ』が必要になってくる。", " ", "部品は地下深くに進むほど、強力な敵や", "宝箱から多く手に入るようになるぞ。"],
                        ["レベルが5上がるごとに、強力な魔法を", "新たに習得していく。", " ", "【極技 (必殺技)】", "ボス戦でのみ使用可能。最大MPの9割を", "消費し、ボスの現在HPを3分の1も削る", "超強力な一撃を放つ。一度使用すると、", "5階層進むまで再使用できないので注意。"]
                    ][self.guide_cursor]
                    
                    for i, t in enumerate(texts): 
                        self.screen.blit(self.font_s.render(t, True, LT_GRAY), (r.x+200, r.y+70+i*35))
                        
                elif self.state in ["BATTLE_MAIN", "BATTLE_MAGIC", "BATTLE_ITEM"]:
                    pygame.draw.rect(self.screen, DK_GRAY, (0, 0, MAP_PIXEL_W, MAP_PIXEL_H))
                    
                    self.screen.blit(self.font_l.render(f"{self.enemy.name}", True, WHITE), (MAP_PIXEL_W//2-180, MAP_PIXEL_H//2-160))
                    
                    if self.fighting_boss:
                        if self.enemy.phase_2:
                            t = self.textures[f'boss_{self.enemy.boss_tier}_p2']
                        else:
                            t = self.textures[f'boss_{self.enemy.boss_tier}']
                    else:
                        t = self.textures[f'enemy_{self.enemy.type_str}']
                        
                    self.screen.blit(t, t.get_rect(center=(MAP_PIXEL_W//2, MAP_PIXEL_H//2-50)))
                    
                    hr = self.enemy.hp/self.enemy.max_hp
                    pygame.draw.rect(self.screen, RED, (MAP_PIXEL_W//2-100, MAP_PIXEL_H//2+40, 200, 10))
                    if hr>0: 
                        pygame.draw.rect(self.screen, GREEN, (MAP_PIXEL_W//2-100, MAP_PIXEL_H//2+40, 200*hr, 10))
                    self.screen.blit(self.font.render(f"体力: {self.enemy.hp} / {self.enemy.max_hp}", True, WHITE), (MAP_PIXEL_W//2-80, MAP_PIXEL_H//2+55))
                        
                    if self.player.action_gauge >= 1000:
                        cr = pygame.Rect(MAP_PIXEL_W//2-140, MAP_PIXEL_H//2+80, 280, 120)
                        pygame.draw.rect(self.screen, BLUE, cr)
                        pygame.draw.rect(self.screen, WHITE, cr, 2)
                        if self.state == "BATTLE_MAIN":
                            req = self.player.max_mp * 9 // 10
                            if self.fighting_boss:
                                opts = ["武器で攻撃する", "魔法を使用する", "アイテムを使う", f"極技 (消費MP: {req})"]
                            else:
                                opts = ["武器で攻撃する", "魔法を使用する", "アイテムを使う", "戦闘から逃走する"]
                                
                            for i, o in enumerate(opts): 
                                self.screen.blit(self.font.render(f"{'▶' if i==self.cursor else ' '} {o}", True, YELLOW if i == self.cursor else WHITE), (cr.x+20, cr.y+10+i*24))
                        elif self.state == "BATTLE_MAGIC":
                            for i, s in enumerate(self.player.spells): 
                                self.screen.blit(self.font.render(f"{'▶' if i==self.cursor else ' '} {s['name']} (消費MP: {s['cost']})", True, YELLOW if i == self.cursor else WHITE), (cr.x+20, cr.y+10+i*24))
                        elif self.state == "BATTLE_ITEM":
                            opts = [f"HP回復薬 (残り: {self.player.hp_potions} 個)", f"MP回復薬 (残り: {self.player.mp_potions} 個)"]
                            for i, o in enumerate(opts): 
                                self.screen.blit(self.font.render(f"{'▶' if i==self.cursor else ' '} {o}", True, YELLOW if i == self.cursor else WHITE), (cr.x+20, cr.y+10+i*30))
                                
                elif self.state == "MENU_STATUS":
                    r = pygame.Rect(30, 30, MAP_PIXEL_W-60, MAP_PIXEL_H-60)
                    pygame.draw.rect(self.screen, DK_GRAY, r)
                    pygame.draw.rect(self.screen, GREEN, r, 3)
                    p = self.player; x, y = r.x+30, r.y+20
                    self.screen.blit(self.font_l.render("現在のステータス", True, WHITE), (x, y))
                    self.screen.blit(self.font.render(f"レベル: {p.level}   経験値: {p.exp}", True, WHITE), (x, y+60))
                    self.screen.blit(self.font.render(f"HP: {p.hp} / {p.max_hp}   MP: {p.mp} / {p.max_mp}", True, WHITE), (x, y+90))
                    self.screen.blit(self.font.render(f"攻撃力: {p.atk}   防御力: {p.defense}   素早さ: {p.agi}", True, WHITE), (x, y+120))
                    self.screen.blit(self.font.render(f"未振り分けの強化ポイント: {p.stat_pts}", True, YELLOW), (x, y+150))
                    self.screen.blit(self.font.render(f"スクラップ: {p.scrap} 個   モーター: {p.motor} 個   チップ: {p.cpu} 個", True, GREEN), (x, y+180))
                    self.screen.blit(self.font.render(f"HP回復薬: {p.hp_potions} 個   MP回復薬: {p.mp_potions} 個", True, CYAN), (x, y+210))
                    
                elif self.state == "MENU_CRAFT":
                    r = pygame.Rect(20, 20, MAP_PIXEL_W-40, MAP_PIXEL_H-40)
                    pygame.draw.rect(self.screen, DK_GRAY, r)
                    pygame.draw.rect(self.screen, BLUE, r, 3)
                    p = self.player
                    self.screen.blit(self.font_l.render("クラフト (装備の強化)", True, WHITE), (r.x+20, r.y+20))
                    self.screen.blit(self.font_s.render(f"所持部品: スクラップ {p.scrap} / モーター {p.motor} / 演算チップ {p.cpu}", True, GREEN), (r.x+20, r.y+60))
                    
                    names = ["武器の強化", "防具ギアの調整", "最大体力の増大", "最大魔力の増大", "魔法威力の強化"]
                    for i in range(5):
                        lv = [p.weapon_lv, p.gear_lv, p.hp_lv, p.mp_lv, p.magic_lv][i]
                        cost_s = lv * 5
                        cost_m = max(0, (lv - 2) * 2)
                        cost_c = max(0, (lv - 5) * 1)
                        color = YELLOW if i == self.cursor else WHITE
                        
                        req_str = f"消費: ｽｸﾗｯﾌﾟ {cost_s} 個"
                        if cost_m > 0: req_str += f" / ﾓｰﾀｰ {cost_m} 個"
                        if cost_c > 0: req_str += f" / 演算ﾁｯﾌﾟ {cost_c} 個"
                        
                        can_craft = p.scrap >= cost_s and p.motor >= cost_m and p.cpu >= cost_c
                        
                        text = f"{'▶' if i==self.cursor else ' '} {names[i]} (現在レベル {lv})  [{req_str}]"
                        self.screen.blit(self.font_s.render(text, True, color if can_craft else GRAY), (r.x+20, r.y+100+i*40))
                        
                elif self.state in ["MENU_LEVELUP", "BATTLE_LEVELUP"]:
                    r = pygame.Rect(30, 30, MAP_PIXEL_W-60, MAP_PIXEL_H-60)
                    pygame.draw.rect(self.screen, DK_GRAY, r)
                    pygame.draw.rect(self.screen, YELLOW, r, 3)
                    self.screen.blit(self.font_l.render(f"ステータス強化 (残りポイント: {self.player.stat_pts})", True, YELLOW if self.state=="BATTLE_LEVELUP" else WHITE), (r.x+30, 40))
                    
                    bonus = self.player.get_stat_bonus()
                    opts = [
                        f"最大HPをアップ (+{bonus['hp']}) -> 変更後: {self.player.max_hp + bonus['hp']}",
                        f"最大MPをアップ (+{bonus['mp']})  -> 変更後: {self.player.max_mp + bonus['mp']}",
                        f"攻撃力をアップ (+{bonus['atk']})  -> 変更後: {self.player.base_atk + bonus['atk']}",
                        f"防御力をアップ (+{bonus['def']})  -> 変更後: {self.player.base_def + bonus['def']}",
                        f"素早さをアップ (+{bonus['agi']})  -> 変更後: {self.player.base_agi + bonus['agi']}"
                    ]
                    for i, o in enumerate(opts): 
                        self.screen.blit(self.font.render(f"{'▶' if i==self.cursor else ' '} {o}", True, YELLOW if i==self.cursor else WHITE), (r.x+30, 100+i*40))
                        
                elif self.state == "MENU_MAGIC" or self.state == "MENU_ITEM":
                    r = pygame.Rect(MAP_PIXEL_W//2-200, MAP_PIXEL_H//2-130, 400, 260)
                    pygame.draw.rect(self.screen, BLACK, r)
                    pygame.draw.rect(self.screen, BLUE if self.state=="MENU_MAGIC" else RED, r, 3)
                    self.screen.blit(self.font_l.render("魔法を使用する" if self.state == "MENU_MAGIC" else "アイテムを使用する", True, WHITE), (r.x+30, r.y+20))
                    
                    if self.state == "MENU_MAGIC":
                        u = [s for s in self.player.spells if s["type"] in ["heal", "defense"]]
                        if not u: 
                            self.screen.blit(self.font.render("フィールドで使える魔法がありません", True, GRAY), (r.x+30, r.y+70))
                        else:
                            for i, s in enumerate(u): 
                                c = YELLOW if i == self.cursor else WHITE
                                self.screen.blit(self.font.render(f"{'▶' if i==self.cursor else ' '} {s['name']} (消費MP: {s['cost']})", True, c), (r.x+30, r.y+70+i*40))
                    else:
                        opts = [f"HP回復薬 (残り: {self.player.hp_potions} 個)", f"MP回復薬 (残り: {self.player.mp_potions} 個)"]
                        for i, o in enumerate(opts): 
                            c = YELLOW if i == self.cursor else WHITE
                            self.screen.blit(self.font.render(f"{'▶' if i==self.cursor else ' '} {o}", True, c), (r.x+30, r.y+70+i*40))
                
                elif self.state == "CRAFT_SAFE_AREA":
                    pygame.draw.rect(self.screen, DK_GRAY, (0, 0, MAP_PIXEL_W, MAP_PIXEL_H))
                    self.screen.blit(self.font_l.render("セーフエリアでHPとMPが全回復した。ボタンで進む。",True,WHITE), (60,160))
                    
                elif self.state == "GAMEOVER":
                    self.screen.blit(self.font_xl.render("GAME OVER",True,RED), (MAP_PIXEL_W//2-100, MAP_PIXEL_H//2-40))
                    self.screen.blit(self.font.render("Cキー または タッチ でコンティニュー",True,YELLOW), (MAP_PIXEL_W//2-180, MAP_PIXEL_H//2+40))

                elif self.state in ["SAVE_IN_PROGRESS", "SAVE_COMPLETE"]:
                    r = pygame.Rect(MAP_PIXEL_W//2 - 160, MAP_PIXEL_H//2 - 70, 320, 140)
                    pygame.draw.rect(self.screen, DK_GRAY, r)
                    pygame.draw.rect(self.screen, YELLOW, r, 3)
                    if self.state == "SAVE_IN_PROGRESS":
                        text = self.font_l.render("セーブ中...", True, WHITE)
                        self.screen.blit(text, (r.x + r.width//2 - text.get_width()//2, r.y + 55))
                    else:
                        text = self.font_l.render("セーブ完了！", True, GREEN)
                        self.screen.blit(text, (r.x + r.width//2 - text.get_width()//2, r.y + 35))
                        sub_text = self.font_s.render("E / Esc / Bボタンで閉じる", True, GRAY)
                        self.screen.blit(sub_text, (r.x + r.width//2 - sub_text.get_width()//2, r.y + 90))

                self.draw_ui()
                self.draw_virtual_pad()

                pygame.display.flip()
            except Exception as e:
                pass
            
            self.clock.tick(FPS)
            await asyncio.sleep(0)

async def main():
    game = Game()
    await game.run()

if __name__ == "__main__":
    asyncio.run(main())
