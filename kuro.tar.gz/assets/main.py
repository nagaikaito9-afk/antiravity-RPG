import pygame
import random
import math
import sys
import os
import json
import asyncio

# --- 定数設定 ---
PHI = (1 + math.sqrt(5)) / 2
GRID_SIZE = 40
MAP_WIDTH, MAP_HEIGHT = 15, 10

MAP_PIXEL_W = MAP_WIDTH * GRID_SIZE
MAP_PIXEL_H = MAP_HEIGHT * GRID_SIZE
LOG_H = 160
SIDE_W = 250
WIDTH = MAP_PIXEL_W + SIDE_W
HEIGHT = MAP_PIXEL_H + LOG_H

ENCOUNTER_RATE = 0.12
ENCOUNTER_COOLDOWN_STEPS = 3
ENEMY_TEX_SIZE = 150

FPS = 60

# --- 色定義 ---
BLACK, WHITE = (10, 10, 10), (240, 240, 240)
GRAY, DK_GRAY, LT_GRAY = (80, 80, 80), (40, 40, 40), (160, 160, 160)
RED, DK_RED = (220, 50, 50), (120, 20, 20)
BLUE, CYAN = (50, 100, 250), (50, 220, 255)
GREEN, DK_GREEN = (50, 200, 50), (20, 100, 20)
YELLOW, GOLD = (255, 215, 0), (218, 165, 32)
SILVER, BROWN, PURPLE = (192, 192, 192), (139, 69, 19), (147, 112, 219)

# --- 音声管理クラス ---
class AudioManager:
    def __init__(self):
        self.audio_ready = False
        self.bgm_started = False
        self.sounds = {}

    def init_audio(self):
        if self.audio_ready: return
        try:
            pygame.mixer.init()
            se_files = {"cursor": "cursor.ogg", "decide": "decide.ogg", "attack": "attack.ogg",
                        "magic": "magic.ogg", "damage": "damage.ogg", "levelup": "levelup.ogg"}
            for name, filename in se_files.items():
                try: self.sounds[name] = pygame.mixer.Sound(filename)
                except: self.sounds[name] = None
            try: pygame.mixer.music.load("bgm.ogg")
            except: pass
            self.audio_ready = True
        except: pass

    def play(self, name):
        if self.audio_ready and name in self.sounds and self.sounds[name]:
            try: self.sounds[name].play()
            except: pass

    def start_bgm(self):
        self.init_audio()
        if not self.bgm_started and self.audio_ready:
            self.bgm_started = True
            try: pygame.mixer.music.play(-1)
            except: pass

# --- 描画ヘルパー ---
def draw_shaded_rect(surf, color, rect, radius=0):
    pygame.draw.rect(surf, color, rect, border_radius=radius)
    hl_color = (min(255, color[0]+60), min(255, color[1]+60), min(255, color[2]+60))
    hl_rect = (rect[0]+2, rect[1]+2, rect[2]-4, max(1, rect[3]//4))
    pygame.draw.rect(surf, hl_color, hl_rect, border_radius=radius)

def create_textures():
    textures = {}
    floor = pygame.Surface((GRID_SIZE, GRID_SIZE))
    floor.fill((130, 130, 135))
    for _ in range(8):
        rx, ry = random.randint(2, GRID_SIZE-6), random.randint(2, GRID_SIZE-6)
        pygame.draw.rect(floor, (110, 110, 115), (rx, ry, 4, 4))
    textures['floor'] = floor
    
    wall = pygame.Surface((GRID_SIZE, GRID_SIZE))
    wall.fill((30, 30, 35))
    for i in range(2):
        for j in range(2):
            draw_shaded_rect(wall, (50, 50, 55), (j*20+2, i*20+2, 16, 16), 4)
    textures['wall'] = wall
    
    stairs = pygame.Surface((GRID_SIZE, GRID_SIZE))
    stairs.fill((20, 80, 20))
    pygame.draw.rect(stairs, GREEN, (4, 4, GRID_SIZE-8, GRID_SIZE-8), 2)
    textures['stairs'] = stairs
    
    chest = pygame.Surface((GRID_SIZE, GRID_SIZE), pygame.SRCALPHA)
    draw_shaded_rect(chest, BROWN, (6, 10, 28, 24), 3)
    pygame.draw.rect(chest, GOLD, (6, 18, 28, 4))
    textures['chest'] = chest

    hole = floor.copy()
    pygame.draw.circle(hole, BLACK, (20, 20), 15)
    textures['hole'] = hole
    
    spike = floor.copy()
    for i in range(3):
        pygame.draw.polygon(spike, RED, [(10+i*10, 35), (15+i*10, 5), (20+i*10, 35)])
    textures['spike'] = spike

    player = pygame.Surface((GRID_SIZE, GRID_SIZE), pygame.SRCALPHA)
    draw_shaded_rect(player, BLUE, (12, 12, 16, 22), 3) 
    draw_shaded_rect(player, SILVER, (10, 16, 20, 14), 4)
    pygame.draw.circle(player, SILVER, (20, 12), 8)
    pygame.draw.rect(player, BLACK, (15, 10, 10, 3))
    textures['player'] = player

    def draw_mech(color, eye_color, shape="normal"):
        surf = pygame.Surface((ENEMY_TEX_SIZE, ENEMY_TEX_SIZE), pygame.SRCALPHA)
        if shape == "tank": draw_shaded_rect(surf, color, (30, 50, 90, 70), 15)
        elif shape == "attacker": pygame.draw.polygon(surf, color, [(75, 20), (120, 120), (30, 120)])
        elif shape == "speed": draw_shaded_rect(surf, color, (50, 20, 50, 110), 25)
        else: draw_shaded_rect(surf, color, (50, 50, 50, 70), 10)
        pygame.draw.circle(surf, eye_color, (75, 70), 12)
        return surf

    textures['enemy_normal'] = draw_mech(GRAY, RED)
    textures['enemy_tank'] = draw_mech((70, 80, 70), YELLOW, "tank")
    textures['enemy_attacker'] = draw_mech((120, 60, 60), CYAN, "attacker")
    textures['enemy_speed'] = draw_mech((60, 60, 120), WHITE, "speed")
    textures['enemy_mimic'] = draw_mech(BROWN, RED)

    for i in range(5):
        b = pygame.Surface((ENEMY_TEX_SIZE, ENEMY_TEX_SIZE), pygame.SRCALPHA)
        pygame.draw.circle(b, [DK_RED, PURPLE, DK_GRAY, DK_GREEN, BLACK][i], (75, 75), 60)
        pygame.draw.circle(b, RED, (75, 75), 20)
        textures[f'boss_{i}'] = b
        p2 = b.copy()
        pygame.draw.circle(p2, RED, (75, 75), 70, 4)
        textures[f'boss_{i}_p2'] = p2

    return textures

def get_potion_heal(ptype, lv):
    if ptype == "hp": return [50, 150, 400, 1000, 2500][lv-1]
    return [30, 100, 250, 600, 1500][lv-1]

# --- プレイヤークラス ---
class Player:
    def __init__(self):
        self.x, self.y = 1, 1
        self.dx, self.dy = 0, 1
        self.level, self.exp = 1, 0
        self.hp, self.max_hp = 60, 60
        self.mp, self.max_mp = 25, 25
        self.base_atk, self.base_def, self.base_agi = 12, 5, 10
        self.scrap, self.motor, self.cpu = 0, 0, 0
        self.stat_pts = 0
        self.weapon_lv, self.gear_lv, self.hp_lv, self.mp_lv, self.magic_lv = 1, 1, 1, 1, 1
        self.hp_potions = {"1":0, "2":0, "3":0, "4":0, "5":0}
        self.mp_potions = {"1":0, "2":0, "3":0, "4":0, "5":0}
        self.ultimate_cd = 0
        self.action_gauge, self.steps_since_encounter, self.active_def = 0, 3, 0
        self.all_msg = []
        self.charge_count = 0
        self.spells = [{"name": "ヒール", "cost": 5, "type": "heal", "power": 30, "desc": "HPを回復する。"}]

    @property
    def atk(self):
        mult = 1.5 ** self.charge_count
        return int((self.base_atk + (self.weapon_lv * 4)) * mult)

    @property
    def agi(self): return self.base_agi + (self.gear_lv * 3)
    @property
    def defense(self): return self.base_def + self.active_def
    
    def get_stat_bonus(self):
        m = self.level // 5
        return {"hp": 15+m*5, "mp": 8+m*2, "atk": 2+m, "def": 2+m, "agi": 2+m}

    def level_up(self):
        self.level += 1
        self.max_hp += 10; self.max_mp += 5
        self.hp, self.mp = self.max_hp, self.max_mp
        learned = None
        if self.level == 5: learned = "ファイア"
        elif self.level == 10: learned = "プロテクト"
        elif self.level == 15: learned = "サンダー"
        elif self.level == 20: learned = "フルヒール"
        if learned:
            costs = {"ファイア":8, "プロテクト":10, "サンダー":18, "フルヒール":25}
            powers = {"ファイア":50, "プロテクト":15, "サンダー":100, "フルヒール":999}
            descs = {"ファイア":"火炎攻撃", "プロテクト":"防御UP", "サンダー":"雷撃", "フルヒール":"全回復"}
            self.spells.append({"name": learned, "cost": costs[learned], "type": "attack" if "ヒール" not in learned else "heal", "power": powers[learned], "desc": descs[learned]})
        return learned

class Enemy:
    def __init__(self, floor, is_boss=False, is_mimic=False):
        self.is_boss = is_boss
        self.is_mimic = is_mimic
        self.phase_2 = False
        scale = 1.12 ** (floor - 1)
        b_hp, b_atk, b_agi = (150, 18, 12+floor*0.4) if is_boss else (35, 9, 10+floor*0.4)
        self.type_str = "normal"
        self.boss_tier = min((floor - 1) // 20, 4) if is_boss else 0
        
        if is_boss:
            names = ["タイタン", "アラクネ", "ヴァルキリー", "ベヒモス", "クロノス"]
            self.name = f"守護者: {names[self.boss_tier]}"
            self.drop_scrap = 20 + floor; self.drop_motor = 5 + floor//10; self.drop_cpu = 2 + floor//20
        elif is_mimic:
            self.type_str = "mimic"
            self.name = "罠箱 ミミック"
            b_hp *= 2.0; b_atk *= 1.5; b_agi *= 1.2
            self.drop_scrap = random.randint(5, 10) + int(floor * 0.8)
            self.drop_motor = random.randint(1, 3)
            self.drop_cpu = 1 if random.random() < 0.5 else 0
        else:
            r = random.random()
            if r < 0.2: self.type_str = "tank"; self.name = "重装兵"; b_hp *= 2.2; b_atk *= 0.7
            elif r < 0.4: self.type_str = "attacker"; self.name = "突撃兵"; b_hp *= 0.7; b_atk *= 1.8
            else: self.type_str = "normal"; self.name = "偵察機"
            self.drop_scrap = 2 + floor//4; self.drop_motor = 1 if floor>10 else 0; self.drop_cpu = 1 if floor>25 else 0

        self.max_hp = int(b_hp * scale)
        self.hp = self.max_hp
        self.atk = int(b_atk * scale)
        self.agi = int(b_agi)
        self.exp_yield = int((50 if is_boss else 18) * scale)
        self.action_gauge = 0

# --- メインゲームクラス ---
class Game:
    def __init__(self):
        pygame.display.init(); pygame.font.init()
        self.screen = pygame.display.set_mode((850, 560), pygame.SCALED)
        self.clock = pygame.time.Clock()
        self.last_touch_time = 0
        try:
            self.font = pygame.font.Font("font.ttf", 20)
            self.font_s = pygame.font.Font("font.ttf", 16)
            self.font_l = pygame.font.Font("font.ttf", 26)
        except:
            self.font = pygame.font.Font(None, 24)
            self.font_s = pygame.font.Font(None, 18)
            self.font_l = pygame.font.Font(None, 32)
        
        self.audio = AudioManager(); self.textures = create_textures(); self.player = Player()
        self.floor = 1; self.state = "MODE_SELECT"; self.cursor = 0; self.guide_cursor = 0
        self.msg = []; self.add_msg("クロ奪還作戦を開始する。")
        self.save_timer = 0; self.new_learned_spells = []
        self.item_opts = []; self.item_map = []
        
        self.tutorial_done = False
        self.tutorial_step = 0
        self.tutorial_texts = [
            "君の大切な相棒である『クロ』は、",
            "この地下100階層の最深部に囚われている。",
            "画面の指示に従って移動し、",
            "緑色の『階段』を目指して最下層へ向かえ。",
            "赤く点滅する『トゲ』や『落とし穴』は",
            "踏むと深刻なダメージを受けてしまうぞ。",
            "敵から得た『部品』で自身を強化できる。",
            "それでは健闘を祈る……クロを救い出せ！"
        ]
        self.control_mode = "keyboard"

    def add_msg(self, m):
        self.msg.append(m)
        if len(self.msg) > 6: self.msg.pop(0)
        if not hasattr(self.player, 'all_msg'): self.player.all_msg = []
        self.player.all_msg.insert(0, m)
        if len(self.player.all_msg) > 100: self.player.all_msg.pop()

    def build_item_list(self):
        self.item_opts = []
        self.item_map = []
        for lv in range(1, 6):
            if self.player.hp_potions.get(str(lv), 0) > 0:
                h_val = get_potion_heal('hp', lv)
                self.item_opts.append(f"HP薬Lv{lv} (残:{self.player.hp_potions[str(lv)]}) +{h_val}")
                self.item_map.append(("hp", lv, h_val))
        for lv in range(1, 6):
            if self.player.mp_potions.get(str(lv), 0) > 0:
                h_val = get_potion_heal('mp', lv)
                self.item_opts.append(f"MP薬Lv{lv} (残:{self.player.mp_potions[str(lv)]}) +{h_val}")
                self.item_map.append(("mp", lv, h_val))
        if not self.item_opts:
            self.item_opts.append("使えるアイテムがない")
            self.item_map.append(None)

    def generate_map(self):
        self.map_data = [[0]*MAP_WIDTH for _ in range(MAP_HEIGHT)]
        cx, cy = 1, 1
        self.map_data[cy][cx] = 1
        cells_count = 0
        target_cells = (MAP_WIDTH * MAP_HEIGHT) // 2
        
        while cells_count < target_cells:
            dx, dy = random.choice([(0,1),(0,-1),(1,0),(-1,0)])
            nx, ny = cx+dx, cy+dy
            if 1 <= nx < MAP_WIDTH-1 and 1 <= ny < MAP_HEIGHT-1:
                if self.map_data[ny][nx] == 0:
                    self.map_data[ny][nx] = 1
                    cells_count += 1
                cx, cy = nx, ny
        
        self.stairs = (MAP_WIDTH-2, MAP_HEIGHT-2)
        while self.map_data[self.stairs[1]][self.stairs[0]] == 0:
            self.stairs = (random.randint(5, MAP_WIDTH-2), random.randint(5, MAP_HEIGHT-2))
        self.map_data[self.stairs[1]][self.stairs[0]] = 2
        
        floor_cells = [(x, y) for y in range(MAP_HEIGHT) for x in range(MAP_WIDTH) if self.map_data[y][x] == 1 and (x,y)!=(1,1) and (x,y)!=self.stairs]
        random.shuffle(floor_cells)
        
        chests = 1 + (1 if random.random()<0.25 else 0) + (1 if random.random()<0.05 else 0)
        for _ in range(chests):
            if floor_cells: pos = floor_cells.pop(); self.map_data[pos[1]][pos[0]] = 3
        
        for _ in range(3):
            if floor_cells: pos = floor_cells.pop(); self.map_data[pos[1]][pos[0]] = random.choice([4, 5])

    def change_state(self, s):
        self.state = s; self.cursor = 0

    def execute_save_data(self):
        d = {"floor":self.floor, "map_data":self.map_data, "stairs":self.stairs, "player": vars(self.player)}
        try:
            with open("save_data.json", "w", encoding="utf-8") as f: json.dump(d, f)
        except: pass

    def load_game(self):
        try:
            with open("save_data.json", "r", encoding="utf-8") as f: d = json.load(f)
            self.floor = d["floor"]; self.map_data = d["map_data"]; self.stairs = tuple(d["stairs"])
            for k, v in d["player"].items(): setattr(self.player, k, v)
            return True
        except: return False

    # ★ 謎のエラー原因だった underground を and に完全修正！
    def get_virtual_key(self, pos):
        x, y = pos
        if 70 <= x <= 130 and 380 <= y <= 440: return pygame.K_UP
        if 70 <= x <= 130 and 500 <= y <= 560: return pygame.K_DOWN
        if 10 <= x <= 70 and 440 <= y <= 500: return pygame.K_LEFT
        if 130 <= x <= 190 and 440 <= y <= 500: return pygame.K_RIGHT
        if (x-750)**2 + (y-480)**2 <= 45**2: return pygame.K_RETURN
        if (x-630)**2 + (y-480)**2 <= 40**2: return pygame.K_ESCAPE
        return None

    def draw_ui(self):
        pygame.draw.rect(self.screen, DK_GRAY, (0, MAP_PIXEL_H, MAP_PIXEL_W, LOG_H))
        pygame.draw.rect(self.screen, GRAY, (0, MAP_PIXEL_H, MAP_PIXEL_W, LOG_H), 2)
        for i, m in enumerate(self.msg): self.screen.blit(self.font.render(m, True, WHITE), (15, MAP_PIXEL_H+15+i*22))
        pygame.draw.rect(self.screen, BLACK, (MAP_PIXEL_W, 0, SIDE_W, HEIGHT))
        pygame.draw.rect(self.screen, GRAY, (MAP_PIXEL_W, 0, SIDE_W, HEIGHT), 2)
        
        px = MAP_PIXEL_W + 15
        p = self.player
        self.screen.blit(self.font_l.render(f"B{self.floor}F", True, YELLOW), (px, 15))
        self.screen.blit(self.font_s.render(f"Lv {p.level}", True, WHITE), (px, 50))
        
        nx_exp = 10*(p.level**2)+5
        ratio = min(1.0, p.exp/nx_exp)
        pygame.draw.rect(self.screen, DK_GRAY, (px, 75, 210, 8))
        pygame.draw.rect(self.screen, GREEN, (px, 75, 210*ratio, 8))

        def draw_bar(y, label, val, m_val, col):
            self.screen.blit(self.font_s.render(f"{label}: {val}/{m_val}", True, WHITE), (px, y))
            pygame.draw.rect(self.screen, DK_GRAY, (px, y+20, 210, 10))
            if m_val>0: pygame.draw.rect(self.screen, col, (px, y+20, 210*max(0,val)/m_val, 10))

        draw_bar(95, "HP", p.hp, p.max_hp, RED)
        draw_bar(135, "MP", p.mp, p.max_mp, BLUE)
        
        self.screen.blit(self.font.render(f"ATK: {p.atk}", True, WHITE), (px, 185))
        self.screen.blit(self.font.render(f"DEF: {p.defense}", True, WHITE), (px, 215))
        self.screen.blit(self.font_s.render(f"SCRAP: {p.scrap}", True, GREEN), (px, 250))
        self.screen.blit(self.font_s.render(f"MOTOR: {p.motor}", True, GREEN), (px, 275))
        self.screen.blit(self.font_s.render(f"CHIP: {p.cpu}", True, GREEN), (px, 300))

    def draw_virtual_pad(self):
        if self.control_mode != "touch" or self.state in ["MODE_SELECT", "SAVE_IN_PROGRESS"]: return
        pad_surf = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        color = (255, 255, 255, 60)
        pygame.draw.rect(pad_surf, color, (70, 380, 60, 60), border_radius=10)
        pygame.draw.rect(pad_surf, color, (70, 500, 60, 60), border_radius=10)
        pygame.draw.rect(pad_surf, color, (10, 440, 60, 60), border_radius=10)
        pygame.draw.rect(pad_surf, color, (130, 440, 60, 60), border_radius=10)
        pygame.draw.polygon(pad_surf, (255,255,255,150), [(100, 390), (85, 420), (115, 420)])
        pygame.draw.polygon(pad_surf, (255,255,255,150), [(100, 550), (85, 520), (115, 520)])
        pygame.draw.polygon(pad_surf, (255,255,255,150), [(20, 470), (50, 455), (50, 485)])
        pygame.draw.polygon(pad_surf, (255,255,255,150), [(180, 470), (150, 455), (150, 485)])
        pygame.draw.circle(pad_surf, color, (750, 480), 45)
        pygame.draw.circle(pad_surf, color, (630, 480), 40)
        pygame.draw.circle(pad_surf, (255,255,255, 150), (750, 480), 20, 3)
        pygame.draw.line(pad_surf, (255,255,255, 150), (615, 465), (645, 495), 4)
        pygame.draw.line(pad_surf, (255,255,255, 150), (615, 495), (645, 465), 4)
        self.screen.blit(pad_surf, (0,0))

    async def run(self):
        while True:
            try:
                self.screen.fill(BLACK)
                if self.state == "SAVE_IN_PROGRESS":
                    self.save_timer -= 1
                    txt = self.font_l.render("セーブ中...", True, WHITE)
                    self.screen.blit(txt, (MAP_PIXEL_W//2-txt.get_width()//2, MAP_PIXEL_H//2-20))
                    if self.save_timer <= 0: self.execute_save_data(); self.state = "SAVE_COMPLETE"
                else:
                    for e in pygame.event.get():
                        if e.type == pygame.QUIT: self.execute_save_data(); pygame.quit(); sys.exit()
                        key = None
                        if e.type == pygame.KEYDOWN:
                            if self.state=="MODE_SELECT" or self.control_mode=="keyboard": key = e.key
                        elif e.type == pygame.MOUSEBUTTONDOWN:
                            now = pygame.time.get_ticks()
                            if now - self.last_touch_time < 150: continue
                            self.last_touch_time = now
                            if self.state=="MODE_SELECT":
                                if 180<=e.pos[1]<=225: self.cursor=0; key=pygame.K_RETURN
                                elif 230<=e.pos[1]<=275: self.cursor=1; key=pygame.K_RETURN
                            elif self.control_mode=="touch": key=self.get_virtual_key(e.pos)

                        if key:
                            if self.state=="MODE_SELECT":
                                if key in [pygame.K_UP, pygame.K_DOWN]: self.cursor = 1-self.cursor
                                elif key==pygame.K_RETURN:
                                    self.control_mode = "touch" if self.cursor==0 else "keyboard"
                                    if not self.load_game(): self.generate_map(); self.change_state("TUTORIAL")
                                    else: self.change_state("MAP")
                            elif self.state=="SAVE_COMPLETE":
                                if key in [pygame.K_ESCAPE, pygame.K_e]: self.change_state("MENU_MAIN")
                            elif self.state=="MAGIC_LEARNED":
                                if key in [pygame.K_RETURN, pygame.K_SPACE, pygame.K_ESCAPE]:
                                    self.new_learned_spells.pop(0)
                                    if not self.new_learned_spells: self.change_state("MAP")
                            elif self.state=="TUTORIAL":
                                if key==pygame.K_RETURN:
                                    self.tutorial_step += 1
                                    if self.tutorial_step >= len(self.tutorial_texts): self.change_state("MAP")
                            elif self.state=="MAP":
                                nx, ny = self.player.x, self.player.y
                                if key in [pygame.K_UP, pygame.K_w]: ny-=1; self.player.dy=-1; self.player.dx=0
                                elif key in [pygame.K_DOWN, pygame.K_s]: ny+=1; self.player.dy=1; self.player.dx=0
                                elif key in [pygame.K_LEFT, pygame.K_a]: nx-=1; self.player.dx=-1; self.player.dy=0
                                elif key in [pygame.K_RIGHT, pygame.K_d]: nx+=1; self.player.dx=1; self.player.dy=0
                                if (nx, ny) != (self.player.x, self.player.y):
                                    if 0<=nx<MAP_WIDTH and 0<=ny<MAP_HEIGHT and self.map_data[ny][nx]!=0:
                                        self.player.x, self.player.y = nx, ny
                                        if self.map_data[ny][nx]==2:
                                            self.enemy=Enemy(self.floor, True); self.fighting_boss=True; self.change_state("BATTLE_MAIN")
                                        elif random.random()<ENCOUNTER_RATE:
                                            self.enemy=Enemy(self.floor); self.fighting_boss=False; self.change_state("BATTLE_MAIN")
                                        elif self.map_data[ny][nx]==3:
                                            self.map_data[ny][nx]=1; self.audio.play("decide")
                                            if random.random()<0.15:
                                                self.enemy=Enemy(self.floor, False, True); self.fighting_boss=False; self.change_state("BATTLE_MAIN")
                                                self.add_msg("ミミックだ！")
                                            else:
                                                self.add_msg("宝箱を開けた！")
                                                self.player.scrap += random.randint(1,3)+int(self.floor*0.5)
                                                plv = str(min(5, 1+(self.floor-1)//20))
                                                if random.random()<0.3: self.player.hp_potions[plv]+=1; self.add_msg(f"HP薬Lv{plv}ゲット！")
                                                if random.random()<0.2: self.player.mp_potions[plv]+=1; self.add_msg(f"MP薬Lv{plv}ゲット！")
                                                self.player.exp += int(10*self.floor)
                                                lv_flag = False
                                                while self.player.exp >= 10*(self.player.level**2)+5:
                                                    self.audio.play("levelup")
                                                    spl = self.player.level_up()
                                                    if spl: self.new_learned_spells.append(spl)
                                                    self.player.stat_pts += 1
                                                    lv_flag = True
                                                if lv_flag: self.change_state("BATTLE_LEVELUP")

                            elif self.state=="MENU_MAIN":
                                opts = ["アイテム", "ステータス強化", "クラフト", "魔法", "ログ観覧", "セーブ", "初期化"]
                                if key in [pygame.K_UP, pygame.K_DOWN]: self.cursor=(self.cursor+(1 if key==pygame.K_DOWN else -1))%len(opts)
                                elif key==pygame.K_RETURN:
                                    if self.cursor==6: self.change_state("MENU_INIT")
                                    elif self.cursor==5: self.state="SAVE_IN_PROGRESS"; self.save_timer=40
                                    else: 
                                        self.change_state(["MENU_ITEM","MENU_LEVELUP","MENU_CRAFT","MENU_MAGIC","MENU_LOG"][self.cursor])
                                        if self.state=="MENU_ITEM": self.build_item_list()
                            elif self.state=="BATTLE_MAIN":
                                opts = ["攻撃", "魔法", "アイテム", "ためる", "逃げる"]
                                if self.fighting_boss: opts = ["攻撃", "魔法", "アイテム", "ためる", "極技"]
                                if key in [pygame.K_UP, pygame.K_DOWN]: self.cursor=(self.cursor+(1 if key==pygame.K_DOWN else -1))%len(opts)
                                elif key==pygame.K_RETURN:
                                    if opts[self.cursor]=="ためる":
                                        if self.player.charge_count < 10:
                                            self.player.charge_count += 1
                                            self.add_msg(f"力をためた！({self.player.charge_count}/10)")
                                            self.player.action_gauge = 0
                                        else: self.add_msg("これ以上ためられない！")
                                    elif opts[self.cursor]=="攻撃":
                                        dmg = max(5, self.player.atk - self.enemy.defense)
                                        self.enemy.hp -= dmg; self.add_msg(f"{dmg}のダメージ！")
                                        self.player.charge_count = 0 
                                        self.player.action_gauge = 0
                                    elif opts[self.cursor]=="逃げる":
                                        if random.random()<0.5: self.change_state("MAP")
                                        else: self.add_msg("逃げられない！"); self.player.action_gauge=0
                                    elif opts[self.cursor]=="魔法": self.change_state("BATTLE_MAGIC")
                                    elif opts[self.cursor]=="アイテム": self.build_item_list(); self.change_state("BATTLE_ITEM")
                                    elif opts[self.cursor]=="極技":
                                        req = self.player.max_mp * 9 // 10
                                        if self.player.ultimate_cd > 0: self.add_msg("まだ極技は使えない！")
                                        elif self.player.mp >= req:
                                            self.player.mp -= req
                                            self.player.ultimate_cd = 5
                                            self.audio.play("magic")
                                            self.enemy.hp = self.enemy.hp // 3
                                            self.add_msg("極技炸裂！HPを大きく削った！")
                                            self.player.action_gauge = 0
                                        else: self.add_msg("MPが足りない！")

                            # ★ 消えていた全メニュー処理の完全復活
                            elif self.state in ["MENU_ITEM", "BATTLE_ITEM"]:
                                if key in [pygame.K_UP, pygame.K_DOWN]:
                                    if self.item_opts: self.cursor = (self.cursor + (1 if key==pygame.K_DOWN else -1)) % len(self.item_opts)
                                elif key==pygame.K_RETURN:
                                    if self.item_opts and self.item_map[self.cursor]:
                                        itype, ilv, iheal = self.item_map[self.cursor]
                                        if itype == "hp":
                                            self.player.hp_potions[str(ilv)] -= 1
                                            self.player.hp = min(self.player.max_hp, self.player.hp + iheal)
                                            self.add_msg(f"HP薬Lv{ilv}使用！")
                                        else:
                                            self.player.mp_potions[str(ilv)] -= 1
                                            self.player.mp = min(self.player.max_mp, self.player.mp + iheal)
                                            self.add_msg(f"MP薬Lv{ilv}使用！")
                                        self.audio.play("magic")
                                        if self.state == "BATTLE_ITEM":
                                            self.player.action_gauge = 0; self.change_state("BATTLE_MAIN")
                                        else:
                                            self.build_item_list(); self.cursor = min(self.cursor, max(0, len(self.item_opts)-1))

                            elif self.state in ["MENU_MAGIC", "BATTLE_MAGIC"]:
                                u = [s for s in self.player.spells if s["type"] in ["heal", "defense"]] if self.state=="MENU_MAGIC" else self.player.spells
                                if key in [pygame.K_UP, pygame.K_DOWN]:
                                    if u: self.cursor = (self.cursor + (1 if key==pygame.K_DOWN else -1)) % len(u)
                                elif key==pygame.K_RETURN:
                                    if u:
                                        s = u[self.cursor]
                                        if self.player.mp >= s["cost"]:
                                            self.audio.play("magic")
                                            self.player.mp -= s["cost"]
                                            pwr = int(s["power"] * (1 + self.player.level * 0.05)) + (self.player.magic_lv - 1) * 10
                                            if s["type"] == "heal":
                                                self.player.hp = min(self.player.max_hp, self.player.hp + pwr)
                                                self.add_msg(f"HPが{pwr}回復！")
                                            elif s["type"] == "attack":
                                                d = pwr + random.randint(-5, 5)
                                                self.enemy.hp -= d
                                                self.add_msg(f"魔法で{d}ダメ！")
                                            elif s["type"] == "defense":
                                                self.player.active_def += pwr
                                                self.add_msg("防御力UP！")
                                            if self.state=="BATTLE_MAGIC": self.player.action_gauge=0; self.change_state("BATTLE_MAIN")
                                        else: self.add_msg("MPが足りない！")

                            elif self.state in ["MENU_LEVELUP", "BATTLE_LEVELUP"]:
                                if key in [pygame.K_UP, pygame.K_DOWN]: self.cursor = (self.cursor + (1 if key==pygame.K_DOWN else -1)) % 5
                                elif key==pygame.K_RETURN:
                                    if self.player.stat_pts > 0:
                                        self.audio.play("decide")
                                        bonus = self.player.get_stat_bonus()
                                        if self.cursor == 0: self.player.max_hp += bonus['hp']; self.player.hp += bonus['hp']
                                        elif self.cursor == 1: self.player.max_mp += bonus['mp']; self.player.mp += bonus['mp']
                                        elif self.cursor == 2: self.player.base_atk += bonus['atk']
                                        elif self.cursor == 3: self.player.base_def += bonus['def']
                                        elif self.cursor == 4: self.player.base_agi += bonus['agi']
                                        self.player.stat_pts -= 1
                                        self.add_msg("ステータス強化！")
                                    else: self.add_msg("ポイント不足！")

                            elif self.state == "MENU_CRAFT":
                                if key in [pygame.K_UP, pygame.K_DOWN]: self.cursor = (self.cursor + (1 if key==pygame.K_DOWN else -1)) % 4
                                elif key==pygame.K_RETURN:
                                    self.audio.play("decide")
                                    lv = [self.player.weapon_lv, self.player.gear_lv, self.player.hp_lv, self.player.mp_lv][self.cursor]
                                    cost = lv * 10
                                    if self.player.scrap >= cost:
                                        self.player.scrap -= cost
                                        if self.cursor == 0: self.player.weapon_lv += 1; self.add_msg("武器を強化！")
                                        elif self.cursor == 1: self.player.gear_lv += 1; self.add_msg("防具を強化！")
                                        elif self.cursor == 2: self.player.hp_lv += 1; self.player.max_hp += 20; self.player.hp += 20; self.add_msg("最大HP増大！")
                                        elif self.cursor == 3: self.player.mp_lv += 1; self.player.max_mp += 10; self.player.mp += 10; self.add_msg("最大MP増大！")
                                    else: self.add_msg("スクラップ不足！")

                            elif self.state == "MENU_LOG":
                                if key in [pygame.K_UP, pygame.K_w]: self.cursor = max(0, self.cursor - 1)
                                elif key in [pygame.K_DOWN, pygame.K_s]: self.cursor = min(max(0, len(self.player.all_msg) - 1), self.cursor + 1)

                            elif key in [pygame.K_ESCAPE, pygame.K_e]:
                                if self.state in ["MENU_ITEM","MENU_LEVELUP","MENU_CRAFT","MENU_MAGIC","MENU_LOG"]: self.change_state("MENU_MAIN")
                                elif self.state in ["BATTLE_MAGIC", "BATTLE_ITEM"]: self.change_state("BATTLE_MAIN")

                # --- 描画ロジック ---
                if self.state in ["MAP", "MENU_MAIN", "MENU_STATUS", "MENU_CRAFT", "MENU_LEVELUP", "MENU_MAGIC", "MENU_LOG", "MENU_ITEM", "TUTORIAL", "SAVE_COMPLETE"]:
                    for y in range(MAP_HEIGHT):
                        for x in range(MAP_WIDTH):
                            tile = ['wall','floor','stairs','chest','hole','spike'][self.map_data[y][x]]
                            self.screen.blit(self.textures[tile], (x*GRID_SIZE, y*GRID_SIZE))
                    self.screen.blit(self.textures['player'], (self.player.x*GRID_SIZE, self.player.y*GRID_SIZE))

                if self.state == "CRAFT_SAFE_AREA":
                    pygame.draw.rect(self.screen, BLACK, (50, 150, MAP_PIXEL_W-100, 100))
                    pygame.draw.rect(self.screen, GREEN, (50, 150, MAP_PIXEL_W-100, 100), 3)
                    txt = self.font.render("セーフエリア到達。HP/MP全快！", True, WHITE)
                    self.screen.blit(txt, (MAP_PIXEL_W//2-txt.get_width()//2, 185))

                elif self.state == "MENU_CRAFT":
                    r = pygame.Rect(30, 30, MAP_PIXEL_W-60, MAP_PIXEL_H-60)
                    pygame.draw.rect(self.screen, BLACK, r); pygame.draw.rect(self.screen, BLUE, r, 2)
                    self.screen.blit(self.font.render("装備強化 (スクラップ消費)", True, CYAN), (r.x+20, r.y+15))
                    p = self.player
                    opts = [("武器", p.weapon_lv), ("防具", p.gear_lv), ("HP", p.hp_lv), ("MP", p.mp_lv)]
                    for i, (name, lv) in enumerate(opts):
                        cost = lv * 10
                        c = YELLOW if i==self.cursor else WHITE
                        txt = self.font_s.render(f"{'▶' if i==self.cursor else '  '} {name} Lv{lv} (必要:{cost})", True, c if p.scrap>=cost else GRAY)
                        self.screen.blit(txt, (r.x+20, r.y+60+i*35))

                elif self.state in ["MENU_LEVELUP", "BATTLE_LEVELUP"]:
                    r = pygame.Rect(30, 30, MAP_PIXEL_W-60, MAP_PIXEL_H-60)
                    pygame.draw.rect(self.screen, DK_GRAY, r); pygame.draw.rect(self.screen, YELLOW, r, 2)
                    self.screen.blit(self.font_l.render(f"ステータス強化 (Pt: {self.player.stat_pts})", True, YELLOW), (r.x+30, 30))
                    bonus = self.player.get_stat_bonus()
                    opts = [f"最大HP +{bonus['hp']} -> {self.player.max_hp + bonus['hp']}",
                            f"最大MP +{bonus['mp']} -> {self.player.max_mp + bonus['mp']}",
                            f"攻撃力 +{bonus['atk']} -> {self.player.base_atk + bonus['atk']}",
                            f"防御力 +{bonus['def']} -> {self.player.base_def + bonus['def']}",
                            f"素早さ +{bonus['agi']} -> {self.player.base_agi + bonus['agi']}"]
                    for i, o in enumerate(opts):
                        self.screen.blit(self.font.render(f"{'▶' if i==self.cursor else ' '} {o}", True, YELLOW if i==self.cursor else WHITE), (r.x+30, 80+i*35))

                elif self.state == "MENU_LOG":
                    r = pygame.Rect(30, 30, MAP_PIXEL_W-60, MAP_PIXEL_H-60)
                    pygame.draw.rect(self.screen, DK_GRAY, r); pygame.draw.rect(self.screen, CYAN, r, 2)
                    self.screen.blit(self.font_l.render("過去のログ (新しい順)", True, WHITE), (r.x+30, r.y+20))
                    max_disp = 8
                    start_idx = max(0, min(self.cursor - 3, len(self.player.all_msg) - max_disp))
                    for i in range(min(max_disp, len(self.player.all_msg) - start_idx)):
                        idx = start_idx + i
                        c = YELLOW if idx == self.cursor else WHITE
                        self.screen.blit(self.font.render(f"{self.player.all_msg[idx]}", True, c), (r.x+30, r.y+70+i*32))

                elif self.state in ["MENU_ITEM", "MENU_MAGIC"]:
                    r = pygame.Rect(30, 30, MAP_PIXEL_W-60, MAP_PIXEL_H-60)
                    pygame.draw.rect(self.screen, BLACK, r); pygame.draw.rect(self.screen, RED if self.state=="MENU_ITEM" else BLUE, r, 2)
                    self.screen.blit(self.font_l.render("アイテム" if self.state=="MENU_ITEM" else "フィールド魔法", True, WHITE), (r.x+30, r.y+20))
                    items = self.item_opts if self.state=="MENU_ITEM" else [s for s in self.player.spells if s["type"] in ["heal", "defense"]]
                    max_disp = 8
                    start_idx = max(0, min(self.cursor - 3, len(items) - max_disp))
                    for i in range(min(max_disp, len(items) - start_idx)):
                        idx = start_idx + i
                        c = YELLOW if idx == self.cursor else WHITE
                        txt = items[idx] if self.state=="MENU_ITEM" else f"{items[idx]['name']} (MP:{items[idx]['cost']})"
                        self.screen.blit(self.font.render(f"{'▶' if idx==self.cursor else ' '} {txt}", True, c), (r.x+30, r.y+70+i*32))

                elif self.state in ["BATTLE_MAIN", "BATTLE_MAGIC", "BATTLE_ITEM"]:
                    pygame.draw.rect(self.screen, DK_GRAY, (0, 0, MAP_PIXEL_W, MAP_PIXEL_H))
                    bt = self.textures[f'boss_{self.enemy.boss_tier}{"_p2" if self.enemy.phase_2 else ""}' if self.enemy.is_boss else f'enemy_{self.enemy.type_str}']
                    self.screen.blit(bt, bt.get_rect(center=(MAP_PIXEL_W//2, MAP_PIXEL_H//2-40)))
                    pygame.draw.rect(self.screen, RED, (MAP_PIXEL_W//2-100, MAP_PIXEL_H//2+50, 200, 10))
                    pygame.draw.rect(self.screen, GREEN, (MAP_PIXEL_W//2-100, MAP_PIXEL_H//2+50, 200*self.enemy.hp/self.enemy.max_hp, 10))
                    hp_txt = self.font_s.render(f"HP: {self.enemy.hp}/{self.enemy.max_hp}", True, WHITE)
                    self.screen.blit(hp_txt, (MAP_PIXEL_W//2-hp_txt.get_width()//2, MAP_PIXEL_H//2+65))
                    
                    if self.player.action_gauge >= 1000:
                        cmd_r = pygame.Rect(MAP_PIXEL_W//2-140, MAP_PIXEL_H//2+90, 280, 100)
                        pygame.draw.rect(self.screen, BLACK, cmd_r); pygame.draw.rect(self.screen, WHITE, cmd_r, 1)
                        if self.state == "BATTLE_MAIN":
                            opts = ["攻撃", "魔法", "アイテム", "ためる", "逃げる"]
                            if self.fighting_boss: opts = ["攻撃", "魔法", "アイテム", "ためる", "極技"]
                            for i, o in enumerate(opts):
                                c = YELLOW if i==self.cursor else WHITE
                                self.screen.blit(self.font_s.render(f"{'▶' if i==self.cursor else ' '} {o}", True, c), (cmd_r.x+15+(i//3)*130, cmd_r.y+10+(i%3)*28))
                        elif self.state == "BATTLE_MAGIC":
                            u = self.player.spells
                            max_disp = 4
                            start_idx = max(0, min(self.cursor - 1, len(u) - max_disp))
                            for i in range(min(max_disp, len(u) - start_idx)):
                                idx = start_idx + i
                                s = u[idx]
                                c = YELLOW if idx == self.cursor else WHITE
                                self.screen.blit(self.font.render(f"{'▶' if idx==self.cursor else ' '} {s['name']} (MP:{s['cost']})", True, c), (cmd_r.x+20, cmd_r.y+10+i*22))
                        elif self.state == "BATTLE_ITEM":
                            max_disp = 4
                            start_idx = max(0, min(self.cursor - 1, len(self.item_opts) - max_disp))
                            for i in range(min(max_disp, len(self.item_opts) - start_idx)):
                                idx = start_idx + i
                                c = YELLOW if idx == self.cursor else WHITE
                                self.screen.blit(self.font_s.render(f"{'▶' if idx==self.cursor else ' '} {self.item_opts[idx]}", True, c), (cmd_r.x+15, cmd_r.y+10+i*22))

                elif self.state == "SAVE_COMPLETE":
                    r = pygame.Rect(MAP_PIXEL_W//2-150, MAP_PIXEL_H//2-50, 300, 100)
                    pygame.draw.rect(self.screen, BLACK, r); pygame.draw.rect(self.screen, GOLD, r, 2)
                    self.screen.blit(self.font.render("セーブ完了！", True, GREEN), (r.x+100, r.y+25))
                    self.screen.blit(self.font_s.render("Eボタン等で閉じる", True, GRAY), (r.x+85, r.y+65))

                elif self.state == "MAGIC_LEARNED":
                    r = pygame.Rect(MAP_PIXEL_W//2 - 200, MAP_PIXEL_H//2 - 80, 400, 160)
                    pygame.draw.rect(self.screen, DK_GRAY, r); pygame.draw.rect(self.screen, YELLOW, r, 3)
                    self.screen.blit(self.font_l.render("新しい魔法を覚えた！", True, YELLOW), (r.x + 80, r.y + 20))
                    self.screen.blit(self.font_l.render(f"『{self.new_learned_spells[0]}』", True, CYAN), (r.x + 120, r.y + 70))
                    self.screen.blit(self.font_s.render("ボタンを押して閉じる", True, GRAY), (r.x + 120, r.y + 120))

                self.draw_ui()
                if self.control_mode=="touch": self.draw_virtual_pad()
                
                # 行動ゲージ進行
                if self.state in ["BATTLE_MAIN", "BATTLE_MAGIC", "BATTLE_ITEM"] and self.player.action_gauge < 1000:
                    self.player.action_gauge += self.player.agi
                    self.enemy.action_gauge += self.enemy.agi
                    if self.enemy.action_gauge >= 1000:
                        dmg = max(1, self.enemy.atk - self.player.defense)
                        self.player.hp -= dmg; self.add_msg(f"敵の攻撃！{dmg}ダメ"); self.enemy.action_gauge=0
                        if self.player.hp <= 0: self.state="GAMEOVER"

                if self.enemy.hp <= 0 and self.state in ["BATTLE_MAIN","BATTLE_MAGIC","BATTLE_ITEM"]:
                    self.add_msg("勝利！"); self.player.exp += self.enemy.exp_yield; self.player.scrap += self.enemy.drop_scrap
                    lv_flag = False
                    while self.player.exp >= 10*(self.player.level**2)+5:
                        self.audio.play("levelup")
                        spl = self.player.level_up()
                        if spl: self.new_learned_spells.append(spl)
                        self.player.stat_pts += 1
                        lv_flag = True
                    if self.fighting_boss:
                        self.floor+=1; self.generate_map()
                        if self.floor % 10 == 0: self.change_state("CRAFT_SAFE_AREA")
                        else: self.change_state("BATTLE_LEVELUP" if lv_flag else "MAP")
                    else:
                        self.change_state("BATTLE_LEVELUP" if lv_flag else "MAP")

                pygame.display.flip()
            except Exception as e: print(e)
            self.clock.tick(FPS); await asyncio.sleep(0)

async def main():
    game = Game(); await game.run()

if __name__ == "__main__": asyncio.run(main())
