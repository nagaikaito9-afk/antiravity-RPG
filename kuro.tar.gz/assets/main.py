import pygame
import random
import math
import sys
import os
import json
import asyncio

# --- 定数設定 ---
PHI = (1 + math.sqrt(5)) / 2
GRID_SIZE = 40
MAP_WIDTH, MAP_HEIGHT = 15, 10

MAP_PIXEL_W = MAP_WIDTH * GRID_SIZE
MAP_PIXEL_H = MAP_HEIGHT * GRID_SIZE
LOG_H = 160
SIDE_W = 250
WIDTH = MAP_PIXEL_W + SIDE_W
HEIGHT = MAP_PIXEL_H + LOG_H

ENCOUNTER_RATE = 0.12
ENCOUNTER_COOLDOWN_STEPS = 3
ENEMY_TEX_SIZE = 150

FPS = 60

# --- 色定義 ---
BLACK, WHITE = (10, 10, 10), (240, 240, 240)
GRAY, DK_GRAY, LT_GRAY = (80, 80, 80), (40, 40, 40), (160, 160, 160)
RED, DK_RED = (220, 50, 50), (120, 20, 20)
BLUE, CYAN = (50, 100, 250), (50, 220, 255)
GREEN, DK_GREEN = (50, 200, 50), (20, 100, 20)
YELLOW, GOLD = (255, 215, 0), (218, 165, 32)
SILVER, BROWN, PURPLE = (192, 192, 192), (139, 69, 19), (147, 112, 219)

# --- 音声管理クラス ---
class AudioManager:
    def __init__(self):
        self.audio_ready = False
        self.bgm_started = False
        self.sounds = {}

    def init_audio(self):
        if self.audio_ready: return
        try:
            pygame.mixer.init()
            se_files = {"cursor": "cursor.ogg", "decide": "decide.ogg", "attack": "attack.ogg",
                        "magic": "magic.ogg", "damage": "damage.ogg", "levelup": "levelup.ogg"}
            for name, filename in se_files.items():
                try: self.sounds[name] = pygame.mixer.Sound(filename)
                except: self.sounds[name] = None
            try: pygame.mixer.music.load("bgm.ogg")
            except: pass
            self.audio_ready = True
        except: pass

    def play(self, name):
        if self.audio_ready and name in self.sounds and self.sounds[name]:
            try: self.sounds[name].play()
            except: pass

    def start_bgm(self):
        self.init_audio()
        if not self.bgm_started and self.audio_ready:
            self.bgm_started = True
            try: pygame.mixer.music.play(-1)
            except: pass

# --- 描画ヘルパー ---
def draw_shaded_rect(surf, color, rect, radius=0):
    pygame.draw.rect(surf, color, rect, border_radius=radius)
    hl_color = (min(255, color[0]+60), min(255, color[1]+60), min(255, color[2]+60))
    hl_rect = (rect[0]+2, rect[1]+2, rect[2]-4, max(1, rect[3]//4))
    pygame.draw.rect(surf, hl_color, hl_rect, border_radius=radius)

# --- テクスチャ生成関数（王道の四角いマップタイル） ---
def create_textures():
    textures = {}
    
    floor = pygame.Surface((GRID_SIZE, GRID_SIZE))
    floor.fill((140, 140, 140))
    for _ in range(15):
        rx, ry = random.randint(2, GRID_SIZE-4), random.randint(2, GRID_SIZE-4)
        c = random.choice([(120, 120, 120), (160, 160, 160)])
        pygame.draw.rect(floor, c, (rx, ry, 6, 6))
    pygame.draw.rect(floor, (180, 180, 180), (0, 0, GRID_SIZE, GRID_SIZE), 1)
    textures['floor'] = floor
    
    wall = pygame.Surface((GRID_SIZE, GRID_SIZE))
    wall.fill((40, 40, 40))
    for i in range(2):
        for j in range(2):
            x, y = j*20, i*20
            if i == 1: x = (j*20+10)%40-10
            draw_shaded_rect(wall, (60, 60, 60), (x, y, 20, 20), 2)
    textures['wall'] = wall
    
    stairs = pygame.Surface((GRID_SIZE, GRID_SIZE))
    for i in range(5):
        h = GRID_SIZE // 5
        c = max(20, 160 - i*30)
        draw_shaded_rect(stairs, (0, c, 0), (0, i*h, GRID_SIZE, h))
    textures['stairs'] = stairs
    
    chest = pygame.Surface((GRID_SIZE, GRID_SIZE), pygame.SRCALPHA)
    draw_shaded_rect(chest, BROWN, (6, 10, GRID_SIZE-12, GRID_SIZE-16), 3)
    pygame.draw.rect(chest, GOLD, (6, 10, GRID_SIZE-12, GRID_SIZE-16), 2, border_radius=3)
    draw_shaded_rect(chest, GOLD, (GRID_SIZE//2-4, 16, 8, 8), 1)
    textures['chest'] = chest

    hole = floor.copy()
    for i in range(12):
        c = max(0, 100 - i*10)
        pygame.draw.circle(hole, (c, c, c), (GRID_SIZE//2, GRID_SIZE//2), GRID_SIZE//2 - i)
    textures['hole'] = hole
    
    spike = floor.copy()
    draw_shaded_rect(spike, (60, 60, 60), (4, 4, GRID_SIZE-8, GRID_SIZE-8), 4)
    for px, py in [(12,12), (28,12), (12,28), (28,28)]:
        pygame.draw.polygon(spike, DK_RED, [(px, py-14), (px-6, py+4), (px+6, py+4)])
        pygame.draw.polygon(spike, RED, [(px, py-14), (px-3, py+4), (px+3, py+4)])
    textures['spike'] = spike

    player = pygame.Surface((GRID_SIZE, GRID_SIZE), pygame.SRCALPHA)
    draw_shaded_rect(player, BLUE, (12, 12, 16, 22), 3) 
    draw_shaded_rect(player, SILVER, (10, 16, 20, 14), 4)
    pygame.draw.circle(player, SILVER, (20, 12), 8)
    pygame.draw.rect(player, BLACK, (15, 10, 10, 3))
    draw_shaded_rect(player, BROWN, (4, 14, 10, 14), 2)
    pygame.draw.rect(player, SILVER, (4, 14, 10, 14), 1, border_radius=2)
    draw_shaded_rect(player, BROWN, (29, 20, 4, 8))
    draw_shaded_rect(player, GOLD, (27, 18, 8, 3))
    draw_shaded_rect(player, SILVER, (29, 4, 4, 14))
    textures['player'] = player

    def draw_mech(color, eye_color, shape="normal"):
        surf = pygame.Surface((ENEMY_TEX_SIZE, ENEMY_TEX_SIZE), pygame.SRCALPHA)
        if shape == "tank": draw_shaded_rect(surf, color, (30, 50, 90, 70), 15)
        elif shape == "attacker": pygame.draw.polygon(surf, color, [(75, 20), (120, 120), (30, 120)])
        elif shape == "speed": draw_shaded_rect(surf, color, (50, 20, 50, 110), 25)
        else: draw_shaded_rect(surf, color, (50, 50, 50, 70), 10)
        pygame.draw.circle(surf, eye_color, (75, 70), 12)
        return surf

    textures['enemy_normal'] = draw_mech(GRAY, RED)
    textures['enemy_tank'] = draw_mech((70, 80, 70), YELLOW, "tank")
    textures['enemy_attacker'] = draw_mech((120, 60, 60), CYAN, "attacker")
    textures['enemy_speed'] = draw_mech((60, 60, 120), WHITE, "speed")
    textures['enemy_mimic'] = draw_mech(BROWN, RED)

    for i in range(5):
        b = pygame.Surface((ENEMY_TEX_SIZE, ENEMY_TEX_SIZE), pygame.SRCALPHA)
        pygame.draw.circle(b, [DK_RED, PURPLE, DK_GRAY, DK_GREEN, BLACK][i], (75, 75), 60)
        pygame.draw.circle(b, RED, (75, 75), 20)
        textures[f'boss_{i}'] = b
        p2 = b.copy()
        pygame.draw.circle(p2, RED, (75, 75), 70, 4)
        textures[f'boss_{i}_p2'] = p2

    return textures

def get_potion_heal(ptype, lv):
    if ptype == "hp": return [50, 150, 400, 1000, 2500][lv-1]
    return [30, 100, 250, 600, 1500][lv-1]

# --- プレイヤークラス ---
class Player:
    def __init__(self):
        self.x, self.y = 1, 1
        self.dx, self.dy = 0, 1
        self.level, self.exp = 1, 0
        self.hp, self.max_hp = 60, 60
        self.mp, self.max_mp = 25, 25
        self.base_atk, self.base_def, self.base_agi = 12, 5, 10
        self.scrap, self.motor, self.cpu = 0, 0, 0
        self.stat_pts = 0
        self.weapon_lv, self.gear_lv, self.hp_lv, self.mp_lv, self.magic_lv = 1, 1, 1, 1, 1
        self.hp_potions = {"1":0, "2":0, "3":0, "4":0, "5":0}
        self.mp_potions = {"1":0, "2":0, "3":0, "4":0, "5":0}
        self.ultimate_cd = 0
        self.action_gauge, self.steps_since_encounter, self.active_def = 0, 3, 0
        self.all_msg = []
        self.charge_count = 0
        self.spells = [{"name": "ヒール", "cost": 5, "type": "heal", "power": 30, "desc": "体力を少し回復"}]

    @property
    def atk(self):
        mult = 1.5 ** self.charge_count
        return int((self.base_atk + (self.weapon_lv * 4)) * mult)

    @property
    def agi(self): return self.base_agi + (self.gear_lv * 3)
    @property
    def defense(self): return self.base_def + self.active_def
    
    def get_stat_bonus(self):
        m = self.level // 5
        return {"hp": 15+m*5, "mp": 8+m*2, "atk": 2+m, "def": 2+m, "agi": 2+m}

    def level_up(self):
        self.level += 1
        self.max_hp += 10; self.max_mp += 5
        self.hp, self.mp = self.max_hp, self.max_mp
        learned = None
        if self.level == 5: learned = "ファイア"
        elif self.level == 10: learned = "プロテクト"
        elif self.level == 15: learned = "サンダー"
        elif self.level == 20: learned = "フルヒール"
        
        if learned:
            costs = {"ファイア":8, "プロテクト":10, "サンダー":18, "フルヒール":25}
            powers = {"ファイア":50, "プロテクト":15, "サンダー":100, "フルヒール":999}
            descs = {"ファイア":"火炎攻撃", "プロテクト":"防御力上昇", "サンダー":"雷撃", "フルヒール":"全回復"}
            self.spells.append({"name": learned, "cost": costs[learned], "type": "attack" if "ヒール" not in learned else "heal", "power": powers[learned], "desc": descs[learned]})
        return learned

class Enemy:
    def __init__(self, floor, is_boss=False, is_mimic=False):
        self.is_boss = is_boss
        self.is_mimic = is_mimic
        self.phase_2 = False
        scale = 1.12 ** (floor - 1)
        b_hp, b_atk, b_agi = (150, 18, 12+floor*0.4) if is_boss else (35, 9, 10+floor*0.4)
        b_def = 10 if is_boss else 4
        self.type_str = "normal"
        self.boss_tier = min((floor - 1) // 20, 4) if is_boss else 0
        
        if is_boss:
            names = ["タイタン", "アラクネ", "ヴァルキリー", "ベヒモス", "クロノス"]
            self.name = f"守護ボス: {names[self.boss_tier]}"
            self.drop_scrap = 20 + floor; self.drop_motor = 5 + floor//10; self.drop_cpu = 2 + floor//20
        elif is_mimic:
            self.type_str = "mimic"
            self.name = "罠箱 ミミック"
            b_hp *= 2.0; b_atk *= 1.5; b_agi *= 1.2; b_def *= 1.5
            self.drop_scrap = random.randint(5, 10) + int(floor * 0.8)
            self.drop_motor = random.randint(1, 3)
            self.drop_cpu = 1 if random.random() < 0.5 else 0
        else:
            r = random.random()
            if r < 0.2: 
                self.type_str = "tank"; self.name = "重装兵"
                b_hp *= 2.2; b_atk *= 0.7; b_def *= 2.5
            elif r < 0.4: 
                self.type_str = "attacker"; self.name = "突撃兵"
                b_hp *= 0.7; b_atk *= 1.8; b_def *= 0.5
            else: 
                self.type_str = "normal"; self.name = "一般機"
            self.drop_scrap = 2 + floor//4; self.drop_motor = 1 if floor>10 else 0; self.drop_cpu = 1 if floor>25 else 0

        self.max_hp = int(b_hp * scale)
        self.hp = self.max_hp
        self.atk = int(b_atk * scale)
        self.defense = int(b_def * scale)
        self.agi = int(b_agi)
        self.exp_yield = int((50 if is_boss else 18) * scale)
        self.action_gauge = 0

# --- メインゲームクラス ---
class Game:
    def __init__(self):
        pygame.display.init(); pygame.font.init()
        self.screen = pygame.display.set_mode((850, 560), pygame.SCALED)
        self.clock = pygame.time.Clock()
        self.last_touch_time = 0
        self.swipe_y_acc = 0
        
        try:
            self.font = pygame.font.Font("font.ttf", 20)
            self.font_s = pygame.font.Font("font.ttf", 16)
            self.font_l = pygame.font.Font("font.ttf", 26)
        except:
            self.font = pygame.font.Font(None, 24)
            self.font_s = pygame.font.Font(None, 18)
            self.font_l = pygame.font.Font(None, 32)
        
        self.audio = AudioManager(); self.textures = create_textures(); self.player = Player()
        self.floor = 1; self.state = "MODE_SELECT"; self.cursor = 0; self.guide_cursor = 0
        self.msg = []; self.add_msg("クロ奪還作戦を開始する。")
        self.save_timer = 0; self.new_learned_spells = []
        self.item_opts = []; self.item_map = []
        
        self.tutorial_done = False
        self.tutorial_step = 0
        self.tutorial_texts = [
            "君の大切な相棒である『クロ』は、",
            "この地下100階層の最深部に囚われている。",
            "画面の指示に従って移動し、",
            "緑色の『階段』を目指して最下層へ向かえ。",
            "赤く点滅する『トゲ』や『落とし穴』は",
            "踏むと深刻なダメージを受けてしまうぞ。",
            "敵から得た『部品』で自身を強化できる。",
            "それでは健闘を祈る……クロを救い出せ！"
        ]
        self.control_mode = "keyboard"

    def add_msg(self, m):
        self.msg.append(m)
        if len(self.msg) > 6: self.msg.pop(0)
        if not hasattr(self.player, 'all_msg'): self.player.all_msg = []
        self.player.all_msg.insert(0, m)
        if len(self.player.all_msg) > 100: self.player.all_msg.pop()

    def build_item_list(self):
        self.item_opts = []
        self.item_map = []
        for lv in range(1, 6):
            if self.player.hp_potions.get(str(lv), 0) > 0:
                h_val = get_potion_heal('hp', lv)
                self.item_opts.append(f"体力回復薬 レベル{lv} (残:{self.player.hp_potions[str(lv)]}) +{h_val}")
                self.item_map.append(("hp", lv, h_val))
        for lv in range(1, 6):
            if self.player.mp_potions.get(str(lv), 0) > 0:
                h_val = get_potion_heal('mp', lv)
                self.item_opts.append(f"魔力回復薬 レベル{lv} (残:{self.player.mp_potions[str(lv)]}) +{h_val}")
                self.item_map.append(("mp", lv, h_val))
        if not self.item_opts:
            self.item_opts.append("使えるアイテムがない")
            self.item_map.append(None)

    def generate_map(self):
        # ★ 安全な元の四角い部屋の迷路生成
        self.stairs = (MAP_WIDTH-2, MAP_HEIGHT-2)
        for _ in range(20):
            self.map_data = [[0]*MAP_WIDTH for _ in range(MAP_HEIGHT)]
            for y in range(1, MAP_HEIGHT-1):
                for x in range(1, MAP_WIDTH-1):
                    r = random.random()
                    if r < 0.65: self.map_data[y][x] = 1
                    elif r < 0.75: self.map_data[y][x] = 0
                    elif r < 0.90: self.map_data[y][x] = 5
                    else: self.map_data[y][x] = 4
                    
            self.map_data[1][1] = 1
            self.map_data[self.stairs[1]][self.stairs[0]] = 2
            
            # 道がつながっているかチェック
            v = [[False]*MAP_WIDTH for _ in range(MAP_HEIGHT)]
            q = [(1,1)]
            v[1][1] = True
            r_ok = False
            
            while q:
                cx, cy = q.pop(0)
                if (cx, cy) == self.stairs: 
                    r_ok = True
                    break
                for dx, dy in [(0,1),(0,-1),(1,0),(-1,0)]:
                    nx, ny = cx+dx, cy+dy
                    if 0 <= nx < MAP_WIDTH and 0 <= ny < MAP_HEIGHT and not v[ny][nx] and self.map_data[ny][nx] != 0:
                        v[ny][nx] = True
                        q.append((nx,ny))
            if r_ok: break
                
        if not r_ok:
            for x in range(1, MAP_WIDTH-1): self.map_data[1][x] = 1
            for y in range(1, MAP_HEIGHT-1): self.map_data[y][self.stairs[0]] = 1
            self.map_data[self.stairs[1]][self.stairs[0]] = 2
                
        cells = []
        for y in range(1, MAP_HEIGHT-1):
            for x in range(1, MAP_WIDTH-1):
                if self.map_data[y][x] == 1 and (x,y) != (1,1) and (x,y) != self.stairs:
                    cells.append((x,y))
                    
        chests = 1 + (1 if random.random()<0.25 else 0) + (1 if random.random()<0.05 else 0)
        for _ in range(chests):
            if cells:
                cx, cy = random.choice(cells)
                self.map_data[cy][cx] = 3
                cells.remove((cx, cy))
                
        self.has_encountered = False

    def change_state(self, s):
        self.state = s; self.cursor = 0

    def execute_save_data(self):
        d = {
            "floor": self.floor, "map_data": self.map_data, "stairs": self.stairs, "tutorial_done": self.tutorial_done,
            "player": {
                "x": self.player.x, "y": self.player.y, "dx": self.player.dx, "dy": self.player.dy,
                "level": self.player.level, "exp": self.player.exp, "hp": self.player.hp, "max_hp": self.player.max_hp,
                "mp": self.player.mp, "max_mp": self.player.max_mp, "base_atk": self.player.base_atk,
                "base_def": self.player.base_def, "base_agi": self.player.base_agi, "scrap": self.player.scrap,
                "motor": self.player.motor, "cpu": self.player.cpu, "stat_pts": self.player.stat_pts,
                "weapon_lv": self.player.weapon_lv, "gear_lv": self.player.gear_lv, "hp_lv": self.player.hp_lv,
                "mp_lv": self.player.mp_lv, "magic_lv": self.player.magic_lv, "hp_potions": self.player.hp_potions,
                "mp_potions": self.player.mp_potions, "ultimate_cd": self.player.ultimate_cd,
                "spells": self.player.spells, "all_msg": getattr(self.player, 'all_msg', self.msg.copy())
            }
        }
        try:
            with open("save_data.json", "w", encoding="utf-8") as f: json.dump(d, f)
        except: pass

    def load_game(self):
        try:
            with open("save_data.json", "r", encoding="utf-8") as f: d = json.load(f)
            self.floor = d["floor"]; self.map_data = d["map_data"]; self.stairs = tuple(d["stairs"])
            self.tutorial_done = d.get("tutorial_done", False)
            for k, v in d["player"].items(): setattr(self.player, k, v)
            if isinstance(self.player.hp_potions, int): self.player.hp_potions = {"1": self.player.hp_potions, "2":0, "3":0, "4":0, "5":0}
            if isinstance(self.player.mp_potions, int): self.player.mp_potions = {"1": self.player.mp_potions, "2":0, "3":0, "4":0, "5":0}
            return True
        except: return False

    def reset_save_data(self):
        try: os.remove("save_data.json")
        except: pass
        self.__init__()

    def get_virtual_key(self, pos):
        x, y = pos
        if x < 250 and y > 250:
            if y < 420 and 50 < x < 150: return pygame.K_UP
            elif y > 480 and 50 < x < 150: return pygame.K_DOWN
            elif x < 100: return pygame.K_LEFT
            elif x > 100: return pygame.K_RIGHT
        if x > 550 and y > 350:
            if x > 700: return pygame.K_RETURN
            else: return pygame.K_ESCAPE
        return None

    def draw_virtual_pad(self):
        if self.control_mode != "touch" or self.state in ["MODE_SELECT", "SAVE_IN_PROGRESS"]: return
        pad_surf = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        color = (255, 255, 255, 60)
        pygame.draw.rect(pad_surf, color, (70, 380, 60, 60), border_radius=10)
        pygame.draw.rect(pad_surf, color, (70, 500, 60, 60), border_radius=10)
        pygame.draw.rect(pad_surf, color, (10, 440, 60, 60), border_radius=10)
        pygame.draw.rect(pad_surf, color, (130, 440, 60, 60), border_radius=10)
        pygame.draw.polygon(pad_surf, (255,255,255,150), [(100, 390), (85, 420), (115, 420)])
        pygame.draw.polygon(pad_surf, (255,255,255,150), [(100, 550), (85, 520), (115, 520)])
        pygame.draw.polygon(pad_surf, (255,255,255,150), [(20, 470), (50, 455), (50, 485)])
        pygame.draw.polygon(pad_surf, (255,255,255,150), [(180, 470), (150, 455), (150, 485)])
        pygame.draw.circle(pad_surf, color, (750, 480), 55)
        pygame.draw.circle(pad_surf, color, (630, 480), 50)
        pygame.draw.circle(pad_surf, (255,255,255, 150), (750, 480), 20, 3)
        pygame.draw.line(pad_surf, (255,255,255, 150), (615, 465), (645, 495), 4)
        pygame.draw.line(pad_surf, (255,255,255, 150), (615, 495), (645, 465), 4)
        self.screen.blit(pad_surf, (0,0))

    def draw_ui(self):
        # ★ 略語を完全に撤廃し、美しい日本語表記に統一。素早さも確実に表示します！
        pygame.draw.rect(self.screen, DK_GRAY, (0, MAP_PIXEL_H, MAP_PIXEL_W, LOG_H))
        pygame.draw.rect(self.screen, GRAY, (0, MAP_PIXEL_H, MAP_PIXEL_W, LOG_H), 2)
        for i, m in enumerate(self.msg): self.screen.blit(self.font.render(m, True, WHITE), (15, MAP_PIXEL_H+15+i*22))
        
        pygame.draw.rect(self.screen, BLACK, (MAP_PIXEL_W, 0, SIDE_W, HEIGHT))
        pygame.draw.rect(self.screen, GRAY, (MAP_PIXEL_W, 0, SIDE_W, HEIGHT), 2)
        
        px = MAP_PIXEL_W + 15
        p = self.player
        self.screen.blit(self.font_l.render(f"地下 {self.floor} 階", True, YELLOW), (px, 15))
        self.screen.blit(self.font_s.render(f"レベル: {p.level}", True, WHITE), (px, 50))
        
        nx_exp = 10*(p.level**2)+5
        ratio = min(1.0, p.exp/nx_exp)
        pygame.draw.rect(self.screen, DK_GRAY, (px, 75, 210, 8))
        pygame.draw.rect(self.screen, GREEN, (px, 75, 210*ratio, 8))

        def draw_bar(y, label, val, m_val, col):
            self.screen.blit(self.font_s.render(f"{label}: {val} / {m_val}", True, WHITE), (px, y))
            pygame.draw.rect(self.screen, DK_GRAY, (px, y+20, 210, 10))
            if m_val>0: pygame.draw.rect(self.screen, col, (px, y+20, 210*max(0,val)/m_val, 10))

        draw_bar(95, "体力", p.hp, p.max_hp, RED)
        draw_bar(135, "魔力", p.mp, p.max_mp, BLUE)
        
        self.screen.blit(self.font.render(f"攻撃力: {p.atk}", True, WHITE), (px, 185))
        self.screen.blit(self.font.render(f"防御力: {p.defense}", True, WHITE), (px, 215))
        self.screen.blit(self.font.render(f"素早さ: {p.agi}", True, WHITE), (px, 245)) # ★素早さを完全復活
        self.screen.blit(self.font_s.render(f"スクラップ: {p.scrap} 個", True, GREEN), (px, 275))
        self.screen.blit(self.font_s.render(f"モーター:   {p.motor} 個", True, GREEN), (px, 300))
        self.screen.blit(self.font_s.render(f"演算チップ: {p.cpu} 個", True, GREEN), (px, 325))

    async def run(self):
        while True:
            try:
                if self.state == "SAVE_IN_PROGRESS":
                    self.save_timer -= 1
                    if self.save_timer <= 0: 
                        self.execute_save_data(); self.state = "SAVE_COMPLETE"
                        
                for e in pygame.event.get():
                    if e.type == pygame.QUIT: self.execute_save_data(); pygame.quit(); sys.exit()
                    key = None
                    
                    if e.type == pygame.KEYDOWN:
                        self.audio.start_bgm()
                        if self.state == "MODE_SELECT" or self.control_mode == "keyboard": key = e.key
                            
                    elif e.type == pygame.MOUSEBUTTONDOWN:
                        if e.button == 4: key = pygame.K_UP
                        elif e.button == 5: key = pygame.K_DOWN
                        elif e.button == 1:
                            now = pygame.time.get_ticks()
                            if now - getattr(self, 'last_touch_time', 0) < 150: continue
                            self.last_touch_time = now
                            self.audio.start_bgm()
                            if self.state == "MODE_SELECT":
                                if 160 <= e.pos[1] <= 240: self.cursor = 0; key = pygame.K_RETURN
                                elif 250 <= e.pos[1] <= 320: self.cursor = 1; key = pygame.K_RETURN
                            elif self.control_mode == "touch":
                                key = self.get_virtual_key(e.pos)
                    
                    elif e.type == getattr(pygame, 'FINGERMOTION', -1):
                        self.swipe_y_acc += getattr(e, 'dy', 0) * HEIGHT
                        if self.swipe_y_acc > 25: key = pygame.K_DOWN; self.swipe_y_acc = 0
                        elif self.swipe_y_acc < -25: key = pygame.K_UP; self.swipe_y_acc = 0

                    if key is not None:
                        if self.state == "SAVE_IN_PROGRESS": continue
                        elif self.state == "SAVE_COMPLETE":
                            if key in [pygame.K_ESCAPE, pygame.K_e, pygame.K_RETURN, pygame.K_SPACE]:
                                self.audio.play("decide"); self.change_state("MENU_MAIN")
                            continue

                        elif self.state == "MAGIC_LEARNED":
                            if key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE, pygame.K_ESCAPE, pygame.K_e]:
                                self.audio.play("decide")
                                self.new_learned_spells.pop(0)
                                if not self.new_learned_spells: self.change_state("MAP")
                            continue

                        elif self.state == "MODE_SELECT":
                            if key in [pygame.K_UP, pygame.K_DOWN, pygame.K_w, pygame.K_s]: self.cursor = 1-self.cursor
                            elif key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                                self.audio.play("decide")
                                self.control_mode = "touch" if self.cursor==0 else "keyboard"
                                if not self.load_game(): 
                                    self.generate_map()
                                    self.change_state("TUTORIAL")
                                else: 
                                    self.change_state("MAP")
                                    
                        elif self.state == "TUTORIAL":
                            if key in [pygame.K_ESCAPE, pygame.K_e]: 
                                self.audio.play("decide"); self.tutorial_done = True; self.change_state("MAP")
                            elif key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                                self.audio.play("decide")
                                self.tutorial_step += 1
                                if self.tutorial_step >= len(self.tutorial_texts): 
                                    self.tutorial_done = True; self.change_state("MAP")

                        elif self.state == "MENU_INIT":
                            if key in [pygame.K_ESCAPE, pygame.K_e]: self.change_state("MENU_MAIN")
                            elif key in [pygame.K_LEFT, pygame.K_RIGHT, pygame.K_a, pygame.K_d]: self.cursor = 1 - self.cursor
                            elif key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                                self.audio.play("decide")
                                if self.cursor == 0: self.reset_save_data()
                                else: self.change_state("MENU_MAIN")

                        elif key in [pygame.K_ESCAPE, pygame.K_e]:
                            if self.state == "MAP": self.change_state("MENU_MAIN")
                            elif self.state == "MENU_MAIN": self.change_state("MAP")
                            elif self.state in ["MENU_STATUS", "MENU_CRAFT", "MENU_MAGIC", "MENU_GUIDE", "MENU_ITEM", "MENU_LOG"]: 
                                self.change_state("MENU_MAIN")
                            elif self.state in ["BATTLE_LEVELUP", "MENU_LEVELUP"]: 
                                if self.new_learned_spells: self.change_state("MAGIC_LEARNED")
                                else: self.change_state("MAP" if self.state == "BATTLE_LEVELUP" else "MENU_MAIN")
                            elif self.state in ["BATTLE_MAGIC", "BATTLE_ITEM"]: self.change_state("BATTLE_MAIN")

                        elif self.state == "GAMEOVER" and key == pygame.K_c:
                            self.audio.play("decide")
                            self.player.hp = 1; self.player.action_gauge = 0; self.player.active_def = 0
                            self.generate_map()
                            self.player.x, self.player.y = 1, 1
                            self.change_state("MAP")
                            self.add_msg("死の淵から蘇った…！")

                        elif self.state == "MAP":
                            nx, ny = self.player.x, self.player.y
                            moved = False
                            if key in [pygame.K_UP, pygame.K_w]: ny-=1; self.player.dy=-1; self.player.dx=0; moved=True
                            elif key in [pygame.K_DOWN, pygame.K_s]: ny+=1; self.player.dy=1; self.player.dx=0; moved=True
                            elif key in [pygame.K_LEFT, pygame.K_a]: nx-=1; self.player.dx=-1; self.player.dy=0; moved=True
                            elif key in [pygame.K_RIGHT, pygame.K_d]: nx+=1; self.player.dx=1; self.player.dy=0; moved=True
                            elif key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                                tx, ty = self.player.x + self.player.dx, self.player.y + self.player.dy
                                if 0 <= tx < MAP_WIDTH and 0 <= ty < MAP_HEIGHT and self.map_data[ty][tx] == 3:
                                    self.audio.play("decide"); self.map_data[ty][tx] = 1
                                    if random.random() < 0.15: 
                                        self.enemy = Enemy(self.floor, False, True); self.change_state("BATTLE_MAIN")
                                        self.add_msg("宝箱は罠箱だった！戦闘開始！")
                                    else:
                                        self.add_msg("宝箱を開けた！")
                                        self.player.scrap += random.randint(1, 3) + int(self.floor * 0.5)
                                        plv = str(min(5, 1 + (self.floor - 1) // 20))
                                        if random.random() < 0.3: self.player.hp_potions[plv] += 1; self.add_msg(f"体力回復薬 レベル{plv}を手に入れた！")
                                        if random.random() < 0.2: self.player.mp_potions[plv] += 1; self.add_msg(f"魔力回復薬 レベル{plv}を手に入れた！")
                                        self.player.exp += int(10 * self.floor)
                                        lv_flag = False
                                        while self.player.exp >= 10*(self.player.level**2)+5:
                                            self.audio.play("levelup")
                                            spl = self.player.level_up()
                                            if spl: self.new_learned_spells.append(spl)
                                            self.player.stat_pts += 1
                                            self.add_msg("レベルが上がった！ 強化ポイントを獲得！")
                                            lv_flag = True
                                        if lv_flag: self.change_state("BATTLE_LEVELUP")
                                    
                            if moved and 0 <= nx < MAP_WIDTH and 0 <= ny < MAP_HEIGHT and self.map_data[ny][nx] not in [0, 3]:
                                if self.map_data[ny][nx] == 4:
                                    self.audio.play("damage"); self.map_data[ny][nx] = 1
                                    self.player.x, self.player.y = nx, ny; self.player.hp -= 10
                                    self.add_msg("落とし穴だ！ 10 のダメージを受けた！")
                                    if self.player.hp <= 0: self.change_state("GAMEOVER")
                                elif (nx, ny) == self.stairs:
                                    self.player.x, self.player.y = nx, ny
                                    if not self.has_encountered: 
                                        self.has_encountered = True; self.enemy = Enemy(self.floor, False)
                                        self.change_state("BATTLE_MAIN")
                                        self.add_msg("階段に敵が潜んでいた！")
                                    else: 
                                        self.enemy = Enemy(self.floor, True)
                                        self.change_state("BATTLE_MAIN"); self.fighting_boss = True
                                        self.add_msg(f"守護ボス 『{self.enemy.name}』 が出現！")
                                else:
                                    self.player.x, self.player.y = nx, ny
                                    self.player.steps_since_encounter += 1
                                    if self.player.steps_since_encounter >= ENCOUNTER_COOLDOWN_STEPS and random.random() < ENCOUNTER_RATE and self.map_data[ny][nx] not in [4,5]:
                                        self.has_encountered = True; self.enemy = Enemy(self.floor, False)
                                        self.change_state("BATTLE_MAIN"); self.fighting_boss = False
                                        self.add_msg("敵が出現した！戦闘開始！")
                                        self.player.steps_since_encounter = 0

                        elif self.state == "MENU_MAIN":
                            opts = ["アイテムを使う", "ステータス強化", "ステータス確認", "クラフト (装備強化)", "魔法 (フィールド)", "冒険者図鑑", "ログを観覧", "ゲームをセーブする", "セーブデータの初期化"]
                            if key in [pygame.K_UP, pygame.K_DOWN, pygame.K_w, pygame.K_s]: 
                                self.audio.play("cursor")
                                self.cursor = (self.cursor + (1 if key in [pygame.K_DOWN, pygame.K_s] else -1)) % len(opts)
                            elif key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                                self.audio.play("decide")
                                if self.cursor == 8: self.change_state("MENU_INIT")
                                elif self.cursor == 7: self.state = "SAVE_IN_PROGRESS"; self.save_timer = 40
                                else: 
                                    self.change_state(["MENU_ITEM", "MENU_LEVELUP", "MENU_STATUS", "MENU_CRAFT", "MENU_MAGIC", "MENU_GUIDE", "MENU_LOG"][self.cursor])
                                    if self.state == "MENU_ITEM": self.build_item_list()

                        elif self.state == "MENU_LOG":
                            if key in [pygame.K_UP, pygame.K_w]: self.cursor = max(0, self.cursor - 1)
                            elif key in [pygame.K_DOWN, pygame.K_s]: self.cursor = min(max(0, len(self.player.all_msg) - 1), self.cursor + 1)

                        elif self.state == "MENU_GUIDE":
                            opts = ["ストーリー概要", "操作方法と宝箱", "地形とアイテム", "敵の特性とボス", "クラフトと部品", "魔法と極技", "アップデート情報"]
                            if key in [pygame.K_UP, pygame.K_DOWN, pygame.K_w, pygame.K_s]: 
                                self.audio.play("cursor")
                                self.guide_cursor = (self.guide_cursor + (1 if key in [pygame.K_DOWN, pygame.K_s] else -1)) % len(opts)

                        elif self.state in ["MENU_ITEM", "BATTLE_ITEM"]:
                            if key in [pygame.K_UP, pygame.K_DOWN, pygame.K_w, pygame.K_s]: 
                                self.audio.play("cursor")
                                if self.item_opts: self.cursor = (self.cursor + (1 if key in [pygame.K_DOWN, pygame.K_s] else -1)) % len(self.item_opts)
                            elif key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                                if self.item_opts and self.item_map[self.cursor]:
                                    itype, ilv, iheal = self.item_map[self.cursor]
                                    if itype == "hp":
                                        self.player.hp_potions[str(ilv)] -= 1
                                        self.player.hp = min(self.player.max_hp, self.player.hp + iheal)
                                        self.add_msg(f"体力回復薬 レベル{ilv}を使用した！")
                                    else:
                                        self.player.mp_potions[str(ilv)] -= 1
                                        self.player.mp = min(self.player.max_mp, self.player.mp + iheal)
                                        self.add_msg(f"魔力回復薬 レベル{ilv}を使用した！")
                                    self.audio.play("magic")
                                    self.player.action_gauge = 0
                                    if self.state == "BATTLE_ITEM": self.change_state("BATTLE_MAIN")
                                    else: self.build_item_list(); self.cursor = min(self.cursor, max(0, len(self.item_opts)-1))

                        elif self.state == "MENU_CRAFT":
                            costs = []
                            for lv in [self.player.weapon_lv, self.player.gear_lv, self.player.hp_lv, self.player.mp_lv, self.player.magic_lv]: costs.append(lv * 10)
                                
                            if key in [pygame.K_UP, pygame.K_DOWN, pygame.K_w, pygame.K_s]: 
                                self.audio.play("cursor")
                                self.cursor = (self.cursor + (1 if key in [pygame.K_DOWN, pygame.K_s] else -1)) % 5
                            elif key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                                self.audio.play("decide")
                                cost = costs[self.cursor]
                                if self.player.scrap >= cost:
                                    self.player.scrap -= cost
                                    if self.cursor == 0: self.player.weapon_lv += 1; self.add_msg("武器を強化した！")
                                    elif self.cursor == 1: self.player.gear_lv += 1; self.add_msg("防具を調整した！")
                                    elif self.cursor == 2: self.player.hp_lv += 1; self.player.max_hp += 20; self.player.hp += 20; self.add_msg("最大体力を増大させた！")
                                    elif self.cursor == 3: self.player.mp_lv += 1; self.player.max_mp += 10; self.player.mp += 10; self.add_msg("最大魔力を増大させた！")
                                    elif self.cursor == 4: self.player.magic_lv += 1; self.add_msg("魔法の威力を強化した！")
                                else: self.add_msg("スクラップが足りない！")

                        elif self.state in ["MENU_LEVELUP", "BATTLE_LEVELUP"]:
                            if key in [pygame.K_UP, pygame.K_DOWN, pygame.K_w, pygame.K_s]: 
                                self.audio.play("cursor")
                                self.cursor = (self.cursor + (1 if key in [pygame.K_DOWN, pygame.K_s] else -1)) % 5
                            elif key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                                self.audio.play("decide")
                                p = self.player
                                if p.stat_pts > 0:
                                    bonus = p.get_stat_bonus()
                                    if self.cursor == 0: p.max_hp += bonus['hp']; p.hp += bonus['hp']
                                    elif self.cursor == 1: p.max_mp += bonus['mp']; p.mp += bonus['mp']
                                    elif self.cursor == 2: p.base_atk += bonus['atk']
                                    elif self.cursor == 3: p.base_def += bonus['def']
                                    elif self.cursor == 4: p.base_agi += bonus['agi']
                                    p.stat_pts -= 1
                                    self.add_msg("ステータスを強化した！")
                                else: self.add_msg("ポイントが足りない！")

                        elif self.state == "MENU_MAGIC":
                            u = [s for s in self.player.spells if s["type"] in ["heal", "defense"]]
                            if key in [pygame.K_UP, pygame.K_DOWN, pygame.K_w, pygame.K_s]: 
                                self.audio.play("cursor")
                                if u: self.cursor = (self.cursor + (1 if key in [pygame.K_DOWN, pygame.K_s] else -1)) % len(u)
                            elif key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                                if not u: self.add_msg("フィールドで使える魔法がない")
                                else:
                                    s = u[self.cursor]
                                    if self.player.mp >= s["cost"]:
                                        self.audio.play("magic")
                                        self.player.mp -= s["cost"]
                                        pwr = int(s["power"] * (1 + self.player.level * 0.05)) + (self.player.magic_lv - 1) * 10
                                        if s["type"] == "heal": self.player.hp = min(self.player.max_hp, self.player.hp + pwr); self.add_msg(f"体力が {pwr} 回復した！")
                                        elif s["type"] == "defense": self.player.active_def += pwr; self.add_msg("防御力がアップした！")
                                    else: self.add_msg("魔力が足りない！")

                        elif self.state == "BATTLE_MAIN":
                            if self.player.action_gauge >= 1000:
                                req = self.player.max_mp * 9 // 10
                                if self.fighting_boss: opts = ["武器で攻撃する", "魔法を使用する", "アイテムを使う", "力をためる", f"極技 (消費魔力:{req})"]
                                else: opts = ["武器で攻撃する", "魔法を使用する", "アイテムを使う", "力をためる", "戦闘から逃走する"]
                                
                                if key in [pygame.K_UP, pygame.K_w]: 
                                    self.audio.play("cursor"); self.cursor = (self.cursor - 2) % len(opts)
                                elif key in [pygame.K_DOWN, pygame.K_s]: 
                                    self.audio.play("cursor"); self.cursor = (self.cursor + 2) % len(opts)
                                elif key in [pygame.K_LEFT, pygame.K_a]: 
                                    self.audio.play("cursor"); self.cursor = (self.cursor - 1) % len(opts)
                                elif key in [pygame.K_RIGHT, pygame.K_d]: 
                                    self.audio.play("cursor"); self.cursor = (self.cursor + 1) % len(opts)

                                elif key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                                    cmd = opts[self.cursor]
                                    if "武器で攻撃" in cmd:
                                        self.audio.play("attack")
                                        d = max(5, self.player.atk - self.enemy.defense)
                                        if random.random() < 0.15: 
                                            d = int(d * PHI)
                                            self.add_msg("クリティカルヒット！")
                                        self.enemy.hp -= d
                                        self.add_msg(f"{d} のダメージを与えた！")
                                        self.player.charge_count = 0 
                                        self.player.action_gauge = 0
                                        self.cursor = 0
                                    elif "魔法を使用" in cmd: 
                                        self.audio.play("decide"); self.change_state("BATTLE_MAGIC")
                                    elif "アイテム" in cmd: 
                                        self.audio.play("decide"); self.build_item_list(); self.change_state("BATTLE_ITEM")
                                    elif "ためる" in cmd:
                                        if self.player.charge_count < 10:
                                            self.player.charge_count += 1
                                            self.add_msg(f"力をためた！ (現在 {self.player.charge_count} 回)")
                                            self.player.action_gauge = 0
                                        else: self.add_msg("これ以上はためられない！")
                                    elif "極技" in cmd:
                                        if self.player.ultimate_cd > 0: self.add_msg("極技はまだ使えない！")
                                        elif self.player.mp >= req: 
                                            self.player.mp -= req; self.player.ultimate_cd = 5
                                            self.audio.play("magic"); self.enemy.hp = self.enemy.hp // 3
                                            self.add_msg("極技炸裂！ボスの体力を大幅に削った！")
                                            self.player.action_gauge = 0; self.cursor = 0
                                        else: self.add_msg("魔力が足りない！")
                                    elif "逃走" in cmd:
                                        if random.random() < 0.4: self.add_msg("逃走に成功した！"); self.change_state("MAP")
                                        else: self.add_msg("逃走に失敗した！"); self.player.action_gauge = 0
                                            
                                    if self.state != "MAP" and self.enemy.is_boss and self.enemy.hp <= self.enemy.max_hp // 2 and not self.enemy.phase_2: 
                                        self.enemy.phase_2 = True; self.add_msg("ボスが暴走モードに突入した！")
                                        self.enemy.atk = int(self.enemy.atk * 1.5); self.enemy.agi = int(self.enemy.agi * 1.5)

                        elif self.state == "BATTLE_MAGIC":
                            if key in [pygame.K_UP, pygame.K_DOWN, pygame.K_w, pygame.K_s]: 
                                self.audio.play("cursor")
                                self.cursor = (self.cursor + (1 if key in [pygame.K_DOWN, pygame.K_s] else -1)) % len(self.player.spells)
                            elif key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE]:
                                s = self.player.spells[self.cursor]
                                if self.player.mp >= s["cost"]:
                                    self.audio.play("magic")
                                    self.player.mp -= s["cost"]
                                    pwr = int(s["power"] * (1 + self.player.level * 0.05)) + (self.player.magic_lv - 1) * 10
                                    if s["type"] == "heal": self.player.hp = min(self.player.max_hp, self.player.hp + pwr); self.add_msg(f"体力が {pwr} 回復した！")
                                    elif s["type"] == "attack": d = pwr + random.randint(-5, 5); self.enemy.hp -= d; self.add_msg(f"魔法で {d} のダメージ！")
                                    elif s["type"] == "defense": self.player.active_def += pwr; self.add_msg("防御力がアップした！")
                                    self.player.action_gauge = 0; self.change_state("BATTLE_MAIN")
                                else: self.add_msg("魔力が足りない！")

                        elif self.state == "CRAFT_SAFE_AREA":
                            if key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE, pygame.K_ESCAPE, pygame.K_e]: 
                                self.audio.play("decide")
                                self.generate_map()
                                self.change_state("MAP")

                # ==========================================
                # すべての画面描画処理
                # ==========================================
                self.screen.fill(BLACK)
                self.draw_ui()
                
                if self.state not in ["BATTLE_MAIN", "BATTLE_MAGIC", "BATTLE_ITEM", "MODE_SELECT", "TUTORIAL", "MENU_INIT"]:
                    for y in range(MAP_HEIGHT):
                        for x in range(MAP_WIDTH): 
                            tile = ['wall','floor','stairs','chest','hole','spike'][self.map_data[y][x]]
                            self.screen.blit(self.textures[tile], (x*GRID_SIZE, y*GRID_SIZE))
                    px, py = self.player.x * GRID_SIZE, self.player.y * GRID_SIZE
                    self.screen.blit(self.textures['player'], (px, py))
                    pygame.draw.circle(self.screen, RED, (px+20+self.player.dx*15, py+20+self.player.dy*15), 4)

                if self.state == "MODE_SELECT":
                    overlay = pygame.Surface((MAP_PIXEL_W, MAP_PIXEL_H)); overlay.set_alpha(180); overlay.fill(BLACK)
                    self.screen.blit(overlay, (0,0))
                    r = pygame.Rect(MAP_PIXEL_W//2 - 220, MAP_PIXEL_H//2 - 100, 440, 200)
                    pygame.draw.rect(self.screen, DK_GRAY, r); pygame.draw.rect(self.screen, WHITE, r, 3)
                    self.screen.blit(self.font_l.render("操作方法を選択してください", True, WHITE), (r.x + 40, r.y + 20))
                    opts = ["タッチ操作 (モバイル対応)", "キーボード操作 (パソコン)"]
                    for i, o in enumerate(opts):
                        c = YELLOW if i == self.cursor else WHITE
                        pygame.draw.rect(self.screen, GRAY if i == self.cursor else BLACK, (r.x + 20, r.y + 80 + i * 50, 400, 40))
                        self.screen.blit(self.font.render(f"{'▶' if i == self.cursor else ' '} {o}", True, c), (r.x + 60, r.y + 88 + i * 50))
                        
                elif self.state == "TUTORIAL":
                    overlay = pygame.Surface((MAP_PIXEL_W, MAP_PIXEL_H)); overlay.set_alpha(180); overlay.fill(BLACK)
                    self.screen.blit(overlay, (0,0))
                    r = pygame.Rect(MAP_PIXEL_W//2 - 240, MAP_PIXEL_H//2 - 100, 480, 200)
                    pygame.draw.rect(self.screen, DK_GRAY, r); pygame.draw.rect(self.screen, YELLOW, r, 3)
                    self.screen.blit(self.font_l.render("チュートリアル", True, YELLOW), (r.x + 30, r.y + 30))
                    self.screen.blit(self.font.render(self.tutorial_texts[self.tutorial_step], True, WHITE), (r.x + 30, r.y + 80))
                    self.screen.blit(self.font_s.render("Enter/Space/Aボタン: 次へ進む    E/Esc/Bボタン: スキップ", True, GRAY), (r.right - 350, r.bottom - 25))
                    
                elif self.state == "MENU_MAIN":
                    r = pygame.Rect(MAP_PIXEL_W//2 - 180, MAP_PIXEL_H//2 - 175, 360, 350)
                    pygame.draw.rect(self.screen, BLACK, r); pygame.draw.rect(self.screen, WHITE, r, 3)
                    self.screen.blit(self.font_l.render("メインメニュー", True, WHITE), (MAP_PIXEL_W//2 - 80, r.y + 15))
                    opts = ["アイテムを使う", "ステータス強化", "ステータス確認", "クラフト (装備強化)", "魔法 (フィールド)", "冒険者図鑑", "ログを観覧", "ゲームをセーブする", "セーブデータの初期化"]
                    for i, o in enumerate(opts): 
                        self.screen.blit(self.font.render(f"{'▶' if i==self.cursor else ' '} {o}", True, RED if i == 8 and i == self.cursor else (YELLOW if i == self.cursor else WHITE)), (MAP_PIXEL_W//2 - 130, MAP_PIXEL_H//2 - 110 + i*30))
                        
                elif self.state == "MENU_INIT":
                    overlay = pygame.Surface((MAP_PIXEL_W, MAP_PIXEL_H)); overlay.set_alpha(180); overlay.fill(BLACK)
                    self.screen.blit(overlay, (0,0))
                    r = pygame.Rect(MAP_PIXEL_W//2 - 200, MAP_PIXEL_H//2 - 80, 400, 160)
                    pygame.draw.rect(self.screen, DK_GRAY, r); pygame.draw.rect(self.screen, RED, r, 3)
                    self.screen.blit(self.font_l.render("セーブデータを初期化しますか？", True, RED), (r.x + 20, r.y + 30))
                    self.screen.blit(self.font.render("はい", True, YELLOW if self.cursor==0 else WHITE), (r.x + 100, r.y + 100))
                    self.screen.blit(self.font.render("いいえ", True, YELLOW if self.cursor==1 else WHITE), (r.x + 240, r.y + 100))
                    
                elif self.state == "MENU_GUIDE":
                    r = pygame.Rect(20, 20, MAP_PIXEL_W - 40, MAP_PIXEL_H - 40)
                    pygame.draw.rect(self.screen, DK_GRAY, r); pygame.draw.rect(self.screen, CYAN, r, 3)
                    self.screen.blit(self.font_l.render("冒険者図鑑", True, WHITE), (r.x+30, r.y+20))
                    opts = ["ストーリー概要", "操作方法と宝箱", "地形とアイテム", "敵の特性とボス", "クラフトと部品", "魔法と極技", "アップデート情報"]
                    for i, o in enumerate(opts): 
                        self.screen.blit(self.font_s.render(f"{'▶' if i==self.guide_cursor else ' '} {o}", True, YELLOW if i == self.guide_cursor else WHITE), (r.x+20, r.y+65+i*40))
                    texts = [
                        ["相棒である『クロ』が、悪の機械軍団に", "よって地下100階層のダンジョンの最深部", "に囚われてしまった。", "立ち塞がる強力な機械兵たちを打ち倒し、", "大切な相棒を必ず救い出そう！"],
                        ["【移動】 矢印キー または 十字ボタン", "【決定】 Enter または Aボタン", "【メニュー/戻る】 Esc または Bボタン", " ", "マップ上の『宝箱』を調べると部品や", "回復薬を得られるが、まれに強力な罠箱", "『ミミック』が潜んでいることがあるぞ。"],
                        ["【緑の床】 次の階層へ進むための階段。", "【赤のトゲ】 踏んでいる間ダメージ！", "【黒い穴】 落ちると10の固定ダメージ！", " ", "【回復薬】", "地下深くへ進むほど回復薬のレベルが上がり、", "体や魔力の回復量が劇的に増加していくぞ。"],
                        ["【一般機械兵】", "重装・強襲・高速など様々な特性を持つ。", " ", "【階層ボス】 10階層ごとに登場する。", "階層が進むとボスの種類も5段階に変化し、", "強大な力で立ち塞がる。体力が半分を切ると", "『暴走モード』に突入するので要注意だ！"],
                        ["敵を倒して得た『部品』を消費して、", "武器や防具のレベルを上げることができる。", "最初は『スクラップ』だけで強化できるが、", "レベルが上がると『モーター』や", "高度な『演算チップ』が必要になってくる。"],
                        ["レベルが5上がるごとに、強力な魔法を", "新たに習得し、専用の演出が入るぞ。", " ", "【極技 (必殺技)】", "ボス戦でのみ使用可能。最大魔力の9割を", "消費し、ボスの現在体力を3分の1も削る", "超強力な一撃を放つ。"],
                        ["【v3.5 - Web Edition の主な進化】", "・マップを王道で安全な四角い迷路へ完全回帰", "・略称を完全撤廃し美しい日本語に統一！", "・モバイルのタッチ操作対応と大幅な感度向上", "・回復薬のレベル化によるインフレ対応", "・戦略性が増す「ためる」コマンドの追加", "・各画面が重ならない美しいレイアウト"]
                    ][self.guide_cursor]
                    for i, t in enumerate(texts): 
                        self.screen.blit(self.font_s.render(t, True, LT_GRAY), (r.x+200, r.y+65+i*35))
                        
                elif self.state in ["BATTLE_MAIN", "BATTLE_MAGIC", "BATTLE_ITEM"]:
                    pygame.draw.rect(self.screen, DK_GRAY, (0, 0, MAP_PIXEL_W, MAP_PIXEL_H))
                    self.screen.blit(self.font_l.render(f"{self.enemy.name}", True, WHITE), (MAP_PIXEL_W//2-180, MAP_PIXEL_H//2-160))
                    
                    if self.fighting_boss:
                        t = self.textures[f'boss_{self.enemy.boss_tier}_p2'] if self.enemy.phase_2 else self.textures[f'boss_{self.enemy.boss_tier}']
                    else:
                        t = self.textures[f'enemy_{self.enemy.type_str}']
                        
                    self.screen.blit(t, t.get_rect(center=(MAP_PIXEL_W//2, MAP_PIXEL_H//2-50)))
                    
                    hr = self.enemy.hp/self.enemy.max_hp
                    pygame.draw.rect(self.screen, RED, (MAP_PIXEL_W//2-100, MAP_PIXEL_H//2+40, 200, 10))
                    if hr>0: pygame.draw.rect(self.screen, GREEN, (MAP_PIXEL_W//2-100, MAP_PIXEL_H//2+40, 200*hr, 10))
                    self.screen.blit(self.font.render(f"体力: {self.enemy.hp} / {self.enemy.max_hp}", True, WHITE), (MAP_PIXEL_W//2-80, MAP_PIXEL_H//2+55))
                        
                    if self.player.action_gauge >= 1000:
                        cmd_r = pygame.Rect(MAP_PIXEL_W//2-140, MAP_PIXEL_H//2+80, 280, 75)
                        pygame.draw.rect(self.screen, BLACK, cmd_r); pygame.draw.rect(self.screen, WHITE, cmd_r, 2)
                        
                        if self.state == "BATTLE_MAIN":
                            req = self.player.max_mp * 9 // 10
                            if self.fighting_boss: opts = ["武器で攻撃する", "魔法を使用する", "アイテムを使う", "力をためる", f"極技 (消費魔力:{req})"]
                            else: opts = ["武器で攻撃する", "魔法を使用する", "アイテムを使う", "力をためる", "戦闘から逃走する"]
                                
                            for i, o in enumerate(opts): 
                                c = YELLOW if i == self.cursor else WHITE
                                col = i % 2; row = i // 2
                                self.screen.blit(self.font_s.render(f"{'▶' if i==self.cursor else ' '} {o}", True, c), (cmd_r.x+10+col*140, cmd_r.y+10+row*22))
                                
                        elif self.state == "BATTLE_MAGIC":
                            u = self.player.spells
                            max_disp = 3
                            start_idx = max(0, min(self.cursor - 1, len(u) - max_disp))
                            for i in range(min(max_disp, len(u) - start_idx)):
                                idx = start_idx + i
                                s = u[idx]
                                c = YELLOW if idx == self.cursor else WHITE
                                self.screen.blit(self.font.render(f"{'▶' if idx==self.cursor else ' '} {s['name']} (消費魔力:{s['cost']})", True, c), (cmd_r.x+20, cmd_r.y+10+i*22))
                                
                        elif self.state == "BATTLE_ITEM":
                            max_disp = 3
                            start_idx = max(0, min(self.cursor - 1, len(self.item_opts) - max_disp))
                            for i in range(min(max_disp, len(self.item_opts) - start_idx)):
                                idx = start_idx + i
                                c = YELLOW if idx == self.cursor else WHITE
                                self.screen.blit(self.font_s.render(f"{'▶' if idx==self.cursor else ' '} {self.item_opts[idx]}", True, c), (cmd_r.x+15, cmd_r.y+10+i*22))
                                
                elif self.state == "MENU_STATUS":
                    r = pygame.Rect(30, 30, MAP_PIXEL_W-60, MAP_PIXEL_H-60)
                    pygame.draw.rect(self.screen, DK_GRAY, r); pygame.draw.rect(self.screen, GREEN, r, 3)
                    p = self.player; x, y = r.x+30, r.y+20
                    self.screen.blit(self.font_l.render("現在のステータス", True, WHITE), (x, y))
                    self.screen.blit(self.font.render(f"レベル: {p.level}   経験値: {p.exp}", True, WHITE), (x, y+60))
                    self.screen.blit(self.font.render(f"体力: {p.hp} / {p.max_hp}   魔力: {p.mp} / {p.max_mp}", True, WHITE), (x, y+90))
                    self.screen.blit(self.font.render(f"攻撃力: {p.atk}   防御力: {p.defense}   素早さ: {p.agi}", True, WHITE), (x, y+120))
                    self.screen.blit(self.font.render(f"未振り分けの強化ポイント: {p.stat_pts}", True, YELLOW), (x, y+150))
                    self.screen.blit(self.font.render(f"スクラップ: {p.scrap} 個   モーター: {p.motor} 個   チップ: {p.cpu} 個", True, GREEN), (x, y+180))
                    hp_tot = sum(p.hp_potions.values()); mp_tot = sum(p.mp_potions.values())
                    self.screen.blit(self.font.render(f"体力回復薬(合計): {hp_tot}個   魔力回復薬(合計): {mp_tot}個", True, CYAN), (x, y+210))
                    
                elif self.state == "MENU_CRAFT":
                    r = pygame.Rect(20, 20, MAP_PIXEL_W-40, MAP_PIXEL_H-40)
                    pygame.draw.rect(self.screen, DK_GRAY, r); pygame.draw.rect(self.screen, BLUE, r, 3)
                    p = self.player
                    self.screen.blit(self.font_l.render("クラフト (装備の強化)", True, WHITE), (r.x+20, r.y+20))
                    self.screen.blit(self.font_s.render(f"所持部品: スクラップ {p.scrap} / モーター {p.motor} / 演算チップ {p.cpu}", True, GREEN), (r.x+20, r.y+60))
                    
                    names = ["武器の強化", "防具の調整", "最大体力の増大", "最大魔力の増大", "魔法威力の強化"]
                    for i in range(5):
                        lv = [p.weapon_lv, p.gear_lv, p.hp_lv, p.mp_lv, p.magic_lv][i]
                        cost = lv * 10
                        c = YELLOW if i == self.cursor else WHITE
                        can_craft = p.scrap >= cost
                        text = f"{'▶' if i==self.cursor else ' '} {names[i]} (現在レベル {lv})  [必要スクラップ: {cost}個]"
                        self.screen.blit(self.font_s.render(text, True, c if can_craft else GRAY), (r.x+20, r.y+100+i*40))
                        
                elif self.state in ["MENU_LEVELUP", "BATTLE_LEVELUP"]:
                    r = pygame.Rect(30, 30, MAP_PIXEL_W-60, MAP_PIXEL_H-60)
                    pygame.draw.rect(self.screen, DK_GRAY, r); pygame.draw.rect(self.screen, YELLOW, r, 3)
                    self.screen.blit(self.font_l.render(f"ステータス強化 (残りポイント: {self.player.stat_pts})", True, YELLOW), (r.x+30, 40))
                    
                    bonus = self.player.get_stat_bonus()
                    opts = [
                        f"最大体力をアップ (+{bonus['hp']}) -> 変更後: {self.player.max_hp + bonus['hp']}",
                        f"最大魔力をアップ (+{bonus['mp']})  -> 変更後: {self.player.max_mp + bonus['mp']}",
                        f"攻撃力をアップ (+{bonus['atk']})  -> 変更後: {self.player.base_atk + bonus['atk']}",
                        f"防御力をアップ (+{bonus['def']})  -> 変更後: {self.player.base_def + bonus['def']}",
                        f"素早さをアップ (+{bonus['agi']})  -> 変更後: {self.player.base_agi + bonus['agi']}"
                    ]
                    for i, o in enumerate(opts): 
                        self.screen.blit(self.font.render(f"{'▶' if i==self.cursor else ' '} {o}", True, YELLOW if i==self.cursor else WHITE), (r.x+30, 100+i*40))
                        
                elif self.state in ["MENU_MAGIC", "MENU_ITEM"]:
                    r = pygame.Rect(MAP_PIXEL_W//2-200, MAP_PIXEL_H//2-130, 400, 260)
                    pygame.draw.rect(self.screen, BLACK, r); pygame.draw.rect(self.screen, BLUE if self.state=="MENU_MAGIC" else RED, r, 3)
                    self.screen.blit(self.font_l.render("魔法を使用する" if self.state == "MENU_MAGIC" else "アイテムを使用する", True, WHITE), (r.x+30, r.y+20))
                    
                    if self.state == "MENU_MAGIC":
                        u = [s for s in self.player.spells if s["type"] in ["heal", "defense"]]
                        if not u: self.screen.blit(self.font.render("フィールドで使える魔法がありません", True, GRAY), (r.x+30, r.y+70))
                        else:
                            max_disp = 5
                            start_idx = max(0, min(self.cursor - 2, len(u) - max_disp))
                            for i in range(min(max_disp, len(u) - start_idx)):
                                idx = start_idx + i
                                s = u[idx]
                                c = YELLOW if idx == self.cursor else WHITE
                                self.screen.blit(self.font.render(f"{'▶' if idx==self.cursor else ' '} {s['name']} (消費魔力: {s['cost']})", True, c), (r.x+30, r.y+70+i*35))
                    else:
                        if not self.item_opts: self.screen.blit(self.font.render("使えるものがありません", True, GRAY), (r.x+30, r.y+70))
                        else:
                            max_disp = 6
                            start_idx = max(0, min(self.cursor - 2, len(self.item_opts) - max_disp))
                            for i in range(min(max_disp, len(self.item_opts) - start_idx)):
                                idx = start_idx + i
                                c = YELLOW if idx == self.cursor else WHITE
                                self.screen.blit(self.font_s.render(f"{'▶' if idx==self.cursor else ' '} {self.item_opts[idx]}", True, c), (r.x+30, r.y+70+i*28))
                
                elif self.state == "MENU_LOG":
                    r = pygame.Rect(30, 30, MAP_PIXEL_W-60, MAP_PIXEL_H-60)
                    pygame.draw.rect(self.screen, DK_GRAY, r); pygame.draw.rect(self.screen, CYAN, r, 3)
                    self.screen.blit(self.font_l.render("過去のログ (新しい順)", True, WHITE), (r.x+30, r.y+20))
                    max_disp = 8
                    start_idx = max(0, min(self.cursor - 3, len(self.player.all_msg) - max_disp))
                    for i in range(min(max_disp, len(self.player.all_msg) - start_idx)):
                        idx = start_idx + i
                        c = YELLOW if idx == self.cursor else WHITE
                        self.screen.blit(self.font.render(f"{self.player.all_msg[idx]}", True, c), (r.x+30, r.y+70+i*32))
                        
                    sub = self.font_s.render("上下スワイプでスクロール / E・Esc・Bボタンで戻る", True, GRAY)
                    self.screen.blit(sub, (r.x + r.width - sub.get_width() - 20, r.y + r.height - 30))

                elif self.state == "CRAFT_SAFE_AREA":
                    r = pygame.Rect(MAP_PIXEL_W//2 - 180, MAP_PIXEL_H//2 - 50, 360, 100)
                    pygame.draw.rect(self.screen, BLACK, r); pygame.draw.rect(self.screen, GREEN, r, 3)
                    txt = self.font.render("セーフエリア！体力と魔力が全回復した", True, WHITE)
                    self.screen.blit(txt, (r.x + r.width//2 - txt.get_width()//2, r.y + 25))
                    txt_s = self.font_s.render("ボタンを押して進む", True, GRAY)
                    self.screen.blit(txt_s, (r.x + r.width//2 - txt_s.get_width()//2, r.y + 60))
                    
                elif self.state == "GAMEOVER":
                    self.screen.blit(self.font_xl.render("GAME OVER",True,RED), (MAP_PIXEL_W//2-100, MAP_PIXEL_H//2-40))
                    self.screen.blit(self.font.render("Cキー または タッチ でコンティニュー",True,YELLOW), (MAP_PIXEL_W//2-180, MAP_PIXEL_H//2+40))

                elif self.state in ["SAVE_IN_PROGRESS", "SAVE_COMPLETE"]:
                    r = pygame.Rect(MAP_PIXEL_W//2 - 160, MAP_PIXEL_H//2 - 70, 320, 140)
                    pygame.draw.rect(self.screen, DK_GRAY, r); pygame.draw.rect(self.screen, YELLOW, r, 3)
                    if self.state == "SAVE_IN_PROGRESS":
                        text = self.font_l.render("セーブ中...", True, WHITE)
                        self.screen.blit(text, (r.x + r.width//2 - text.get_width()//2, r.y + 55))
                    else:
                        text = self.font_l.render("セーブ完了！", True, GREEN)
                        self.screen.blit(text, (r.x + r.width//2 - text.get_width()//2, r.y + 35))
                        sub_text = self.font_s.render("ボタンで閉じる", True, GRAY)
                        self.screen.blit(sub_text, (r.x + r.width//2 - sub_text.get_width()//2, r.y + 90))

                elif self.state == "MAGIC_LEARNED":
                    r = pygame.Rect(MAP_PIXEL_W//2 - 220, MAP_PIXEL_H//2 - 100, 440, 200)
                    pygame.draw.rect(self.screen, DK_GRAY, r); pygame.draw.rect(self.screen, YELLOW, r, 3)
                    
                    spell_name = self.new_learned_spells[0]
                    spell_data = next((s for s in self.player.spells if s["name"] == spell_name), None)
                    title = self.font_l.render("新しい魔法を覚えた！", True, YELLOW)
                    self.screen.blit(title, (r.x + r.width//2 - title.get_width()//2, r.y + 20))
                    s_name = self.font_l.render(f"『{spell_name}』", True, CYAN)
                    self.screen.blit(s_name, (r.x + r.width//2 - s_name.get_width()//2, r.y + 70))
                    if spell_data:
                        desc = self.font_s.render(spell_data.get("desc", ""), True, WHITE)
                        self.screen.blit(desc, (r.x + r.width//2 - desc.get_width()//2, r.y + 120))
                        
                    msg = self.font_s.render("ボタンを押して閉じる", True, GRAY)
                    self.screen.blit(msg, (r.x + r.width//2 - msg.get_width()//2, r.y + 160))

                # --- 敵と味方のゲージ進行とダメージ計算 ---
                if self.state in ["BATTLE_MAIN", "BATTLE_MAGIC", "BATTLE_ITEM"]:
                    # ★ここで敵の死亡判定を完全復活！
                    if self.enemy.hp <= 0:
                        self.add_msg("敵を打ち倒した！")
                        self.player.exp += self.enemy.exp_yield
                        self.player.scrap += self.enemy.drop_scrap
                        self.player.motor += self.enemy.drop_motor
                        self.player.cpu += self.enemy.drop_cpu
                        
                        plv = str(min(5, 1 + (self.floor - 1) // 20))
                        if random.random() < 0.2: 
                            self.player.hp_potions[plv] += 1
                            self.add_msg(f"体力回復薬 レベル{plv}を手に入れた！")
                        if random.random() < 0.15: 
                            self.player.mp_potions[plv] += 1
                            self.add_msg(f"魔力回復薬 レベル{plv}を手に入れた！")
                            
                        self.player.active_def = 0
                        lv_flag = False
                        while self.player.exp >= 10*(self.player.level**2)+5:
                            self.audio.play("levelup")
                            spl = self.player.level_up()
                            if spl: self.new_learned_spells.append(spl)
                            self.player.stat_pts += 1
                            self.add_msg("レベルが上がった！ 強化ポイントを獲得！")
                            lv_flag = True
                            
                        if self.fighting_boss:
                            self.floor += 1
                            self.generate_map()
                            if self.player.ultimate_cd > 0: self.player.ultimate_cd -= 1
                            if self.floor % 10 == 0: 
                                self.change_state("CRAFT_SAFE_AREA")
                                self.player.hp = self.player.max_hp
                                self.player.mp = self.player.max_mp
                            else: 
                                self.change_state("BATTLE_LEVELUP" if lv_flag else "MAP")
                        else:
                            self.change_state("BATTLE_LEVELUP" if lv_flag else "MAP")
                    
                    # 敵が死んでいなければゲージ進行
                    elif self.player.action_gauge < 1000:
                        self.player.action_gauge += self.player.agi
                        self.enemy.action_gauge += self.enemy.agi
                        if self.enemy.action_gauge >= 1000:
                            dmg = max(1, self.enemy.atk - self.player.defense)
                            self.player.hp -= dmg
                            self.add_msg(f"敵の攻撃！ {dmg} のダメージを受けた！")
                            self.enemy.action_gauge = 0
                            if self.player.hp <= 0: self.change_state("GAMEOVER")

                pygame.display.flip()
            except Exception as e:
                print(f"Error: {e}")
            
            self.clock.tick(FPS)
            await asyncio.sleep(0)

async def main():
    game = Game()
    await game.run()

if __name__ == "__main__":
    asyncio.run(main())
