import asyncio
import pygame
import json
import websockets
import random

# --- Pygbag用：ブラウザでの入力をサポートするためのインポート ---
import platform
if platform.system() == "Emscripten":
    from platform import window

# --- 初期設定 ---
pygame.init()
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("RPG Online")

# 色の定義
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GRAY = (80, 80, 80)
DARK_RED = (200, 0, 0)
BLUE = (0, 0, 150)
YELLOW = (255, 255, 0)
GREEN = (0, 200, 0)

# フォント設定
try:
    font_s = pygame.font.SysFont("msgothic", 18)
    font_m = pygame.font.SysFont("msgothic", 24)
    font_l = pygame.font.SysFont("msgothic", 36)
except:
    font_s = pygame.font.Font(None, 18)
    font_m = pygame.font.Font(None, 24)
    font_l = pygame.font.Font(None, 36)

# --- 図鑑データ ---
ZUKAN_DATA = [
    {"name": "スライム", "HP": 50, "ATK": 5, "DEF": 2, "desc": "森に住む魔物。分裂することもある。"},
    {"name": "ダークナイト", "HP": 250, "ATK": 35, "DEF": 15, "desc": "かつての騎士。防御が非常に高い。"},
    {"name": "シャドウドラゴン", "HP": 1200, "ATK": 80, "DEF": 40, "desc": "伝説の古竜。黒炎を吐く。"}
]

# --- クラス定義 ---
class Player:
    def __init__(self):
        self.name = "NO NAME"
        self.max_hp = 100
        self.hp = 100
        self.atk = 15
        self.def_stat = 5
        self.charge_stacks = 0
        self.floor = 1

class Enemy:
    def __init__(self, index):
        d = ZUKAN_DATA[index]
        self.name = d["name"]
        self.max_hp = d["HP"]
        self.hp = d["HP"]
        self.atk = d["ATK"]
        self.def_stat = d["DEF"]

class RealNetwork:
    def __init__(self):
        self.url = "wss://preseason-march-gender.ngrok-free.dev"
        self.ws = None
        self.my_id = str(pygame.time.get_ticks())

    async def connect(self):
        try:
            self.ws = await websockets.connect(self.url)
        except:
            pass

    async def update(self, p_data):
        if self.ws:
            try:
                await self.ws.send(json.dumps({"type": "update", "id": self.my_id, "data": p_data}))
            except: pass

    async def receive(self):
        if self.ws:
            try:
                m = await asyncio.wait_for(self.ws.recv(), timeout=0.01)
                return json.loads(m)
            except: pass
        return None

# --- UIパーツ：仮想コントローラー ---
class VirtualPad:
    def __init__(self):
        # 十字キー
        self.up = pygame.Rect(100, 420, 50, 50)
        self.down = pygame.Rect(100, 520, 50, 50)
        self.left = pygame.Rect(50, 470, 50, 50)
        self.right = pygame.Rect(150, 470, 50, 50)
        # ボタン
        self.btn_z = pygame.Rect(600, 470, 70, 70) # A/決定
        self.btn_x = pygame.Rect(700, 420, 70, 70) # B/キャンセル
        self.btn_c = pygame.Rect(500, 470, 70, 70) # 特殊アクション

    def draw(self, surface):
        # 透明度のあるボタンを描画
        s = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        color = (255, 255, 255, 80)
        for r, label in [(self.up,"U"),(self.down,"D"),(self.left,"L"),(self.right,"R"),
                         (self.btn_z,"Z"),(self.btn_x,"X"),(self.btn_c,"C")]:
            pygame.draw.rect(s, color, r, border_radius=10)
            txt = font_m.render(label, True, (255, 255, 255, 150))
            s.blit(txt, (r.centerx-10, r.centery-10))
        surface.blit(s, (0,0))

# --- 名前入力関数 ---
def get_user_name_input(current_name):
    if platform.system() == "Emscripten":
        # ブラウザの入力ダイアログを表示
        new_name = window.prompt("ユーザー名を入力してください:", current_name)
        return new_name if new_name else current_name
    return current_name

# --- メイン関数 ---
async def main():
    network = RealNetwork()
    await network.connect()
    v_pad = VirtualPad()
    player = Player()
    enemy = Enemy(1)

    state = "TITLE" # TITLE, BATTLE, ZUKAN, PLAYER_MENU
    menu_x, menu_y = 0, 0
    message = "冒険を始めよう！"
    damage_msg = ""
    popup_timer = 0
    map_timer = 10
    
    clock = pygame.time.Clock()

    while True:
        screen.fill(BLACK)
        touch_detected = False
        mouse_pos = pygame.mouse.get_pos()
        mouse_clicked = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT: return
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_clicked = True
                touch_detected = True
            
            # キーボード操作
            if event.type == pygame.KEYDOWN:
                if state == "TITLE":
                    if event.key == pygame.K_z or event.key == pygame.K_RETURN:
                        if player.name != "NO NAME": state = "BATTLE"
                        else: message = "名前を入力してください！"
                    if event.key == pygame.K_n: # Nキーで名前入力
                        player.name = get_user_name_input(player.name)

                elif state == "BATTLE":
                    if event.key == pygame.K_UP: menu_y = 0
                    elif event.key == pygame.K_DOWN: menu_y = 1
                    elif event.key == pygame.K_LEFT: menu_x = 0
                    elif event.key == pygame.K_RIGHT: menu_x = 1
                    elif event.key == pygame.K_z: # 決定
                        cmd = [["こうげき", "ためる"], ["ずかん", "プレイヤー"]][menu_y][menu_x]
                        if cmd == "こうげき":
                            dmg = max(1, int(player.atk * (1.5**player.charge_stacks)) - enemy.def_stat)
                            enemy.hp = max(0, enemy.hp - dmg)
                            player.charge_stacks = 0
                            damage_msg = f"{dmg} ダメ！"
                            popup_timer = 40
                        elif cmd == "ためる":
                            if player.charge_stacks < 10: player.charge_stacks += 1
                        elif cmd == "ずかん": state = "ZUKAN"
                        elif cmd == "プレイヤー": state = "PLAYER_MENU"

        # --- タッチ/クリック判定 ---
        if mouse_clicked:
            if state == "TITLE":
                if v_pad.btn_z.collidepoint(mouse_pos):
                    if player.name != "NO NAME": state = "BATTLE"
                if v_pad.btn_c.collidepoint(mouse_pos):
                    player.name = get_user_name_input(player.name)
            elif state == "BATTLE":
                if v_pad.up.collidepoint(mouse_pos): menu_y = 0
                if v_pad.down.collidepoint(mouse_pos): menu_y = 1
                if v_pad.left.collidepoint(mouse_pos): menu_x = 0
                if v_pad.right.collidepoint(mouse_pos): menu_x = 1
                if v_pad.btn_z.collidepoint(mouse_pos):
                    # 決定処理（キーボードと同じ）
                    cmd = [["こうげき", "ためる"], ["ずかん", "プレイヤー"]][menu_y][menu_x]
                    if cmd == "こうげき":
                        dmg = max(1, int(player.atk * (1.5**player.charge_stacks)) - enemy.def_stat)
                        enemy.hp = max(0, enemy.hp - dmg)
                        player.charge_stacks = 0
                        damage_msg = f"{dmg} ダメ！"
                        popup_timer = 40
                    elif cmd == "ためる":
                        if player.charge_stacks < 10: player.charge_stacks += 1
                    elif cmd == "ずかん": state = "ZUKAN"
                    elif cmd == "プレイヤー": state = "PLAYER_MENU"
            elif state == "PLAYER_MENU":
                if v_pad.btn_c.collidepoint(mouse_pos): # 名前変更
                    player.name = get_user_name_input(player.name)
                if v_pad.btn_x.collidepoint(mouse_pos): state = "BATTLE"
            elif state == "ZUKAN":
                if v_pad.btn_x.collidepoint(mouse_pos): state = "BATTLE"

        # --- 描画ロジック ---
        if state == "TITLE":
            txt = font_l.render("RPG ONLINE", True, WHITE)
            screen.blit(txt, (WIDTH//2-100, 150))
            name_txt = font_m.render(f"現在の名前: {player.name}", True, YELLOW)
            screen.blit(name_txt, (WIDTH//2-100, 250))
            msg_txt = font_s.render("Z:冒険を始める / C:名前入力", True, WHITE)
            screen.blit(msg_txt, (WIDTH//2-100, 320))
            v_pad.draw(screen)

        elif state == "BATTLE":
            # ステータス表示（重なり防止）
            # 地下階表示は左上
            floor_txt = font_l.render(f"B{player.floor}F", True, WHITE)
            screen.blit(floor_txt, (20, 20))
            
            # ユーザー名は右上（地下階と被らない）
            user_txt = font_m.render(f"USER: {player.name}", True, GREEN)
            screen.blit(user_txt, (WIDTH - 200, 20))

            # マップタイマー
            timer_surface = font_l.render(f"マップ変更まで {int(map_timer)}s", True, DARK_RED)
            for dx, dy in [(-1,-1),(1,-1),(-1,1),(1,1)]: # 極太化
                screen.blit(timer_surface, (WIDTH//2-120+dx, 20+dy))
            screen.blit(timer_surface, (WIDTH//2-120, 20))

            # 敵の描画（体力表示位置を調整してメニューと被らないように）
            screen.blit(font_l.render(enemy.name, True, WHITE), (WIDTH//2-80, 150))
            enemy_hp_txt = font_m.render(f"体力: {enemy.hp} / {enemy.max_hp}", True, WHITE)
            screen.blit(enemy_hp_txt, (WIDTH//2-80, 200))

            if popup_timer > 0:
                screen.blit(font_l.render(damage_msg, True, YELLOW), (WIDTH//2-50, 100))
                popup_timer -= 1

            # 戦闘メニューUI（2カラム）
            pygame.draw.rect(screen, WHITE, (50, 400, 700, 180), 2)
            pygame.draw.line(screen, WHITE, (400, 400), (400, 580), 2)
            
            cmds = [["こうげき", "ためる"], ["ずかん", "プレイヤー"]]
            for y in range(2):
                for x in range(2):
                    color = YELLOW if (x==menu_x and y==menu_y) else WHITE
                    txt = font_m.render(cmds[y][x], True, color)
                    screen.blit(txt, (80 + x*350, 430 + y*70))

            # タッチ用コントローラー（BATTLE中のみ薄く表示）
            v_pad.draw(screen)

        elif state == "PLAYER_MENU":
            pygame.draw.rect(screen, BLUE, (100, 100, 600, 400))
            pygame.draw.rect(screen, WHITE, (100, 100, 600, 400), 3)
            screen.blit(font_l.render("プレイヤー情報", True, WHITE), (280, 130))
            screen.blit(font_m.render(f"名前: {player.name}", True, WHITE), (150, 200))
            screen.blit(font_m.render(f"攻撃力: {player.atk}  防御力: {player.def_stat}", True, WHITE), (150, 250))
            screen.blit(font_m.render("Cボタン: 名前を変更する", True, YELLOW), (150, 350))
            screen.blit(font_m.render("Xボタン: 戻る", True, WHITE), (150, 400))
            v_pad.draw(screen)

        elif state == "ZUKAN":
            pygame.draw.rect(screen, GRAY, (50, 50, 700, 500))
            screen.blit(font_l.render("モンスター図鑑", True, WHITE), (280, 70))
            screen.blit(font_m.render("Xボタンで戻る", True, WHITE), (300, 500))
            v_pad.draw(screen)

        # ネットワーク更新
        await network.update({"name": player.name, "hp": player.hp})
        
        pygame.display.flip()
        await asyncio.sleep(0)
        clock.tick(60)

asyncio.run(main())
